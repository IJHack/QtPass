// SPDX-FileCopyrightText: 2015 Anne Jan Brouwer
// SPDX-License-Identifier: GPL-3.0-or-later
#include "trayicon.h"
#include <QAction>
#include <QApplication>
#include <QMainWindow>
#include <QMenu>

#ifdef QT_DEBUG
#include "debughelper.h"
#endif

/**
 * @brief TrayIcon::TrayIcon use a (system) tray icon with a nice QtPass logo on
 * it (currently) only Quits.
 * @param parent
 */
TrayIcon::TrayIcon(QMainWindow *parent)
    : showAction(nullptr), hideAction(nullptr), minimizeAction(nullptr),
      maximizeAction(nullptr), restoreAction(nullptr), quitAction(nullptr),
      sysTrayIcon(nullptr), trayIconMenu(nullptr), isAllocated(false) {
  parentwin = parent;

  if (QSystemTrayIcon::isSystemTrayAvailable()) {
    createActions();
    createTrayIcon();

    sysTrayIcon->setIcon(
        QIcon::fromTheme("qtpass-tray", QIcon(":/artwork/icon.png")));

    sysTrayIcon->show();

    QObject::connect(sysTrayIcon, &QSystemTrayIcon::activated, this,
                     &TrayIcon::iconActivated);

    isAllocated = true;
  }
#ifdef QT_DEBUG
  // NOLINTNEXTLINE(readability/braces)
  else {
    dbg() << "No tray icon for this OS possibly also not show options?";
  }
#endif
}

/**
 * @brief TrayIcon::setVisible show or hide the icon.
 * @param visible
 */
void TrayIcon::setVisible(bool visible) {
  if (visible) {
    parentwin->show();
  } else {
    parentwin->hide();
  }
}

/**
 * @brief TrayIcon::getIsAllocated return if TrayIcon is allocated
 */
auto TrayIcon::getIsAllocated() -> bool { return isAllocated; }

/**
 * @brief TrayIcon::createActions setup the signals.
 */
void TrayIcon::createActions() {
  showAction = new QAction(tr("&Show"), this);
  connect(showAction, &QAction::triggered, parentwin, &QWidget::show);
  hideAction = new QAction(tr("&Hide"), this);
  connect(hideAction, &QAction::triggered, parentwin, &QWidget::hide);

  minimizeAction = new QAction(tr("Mi&nimize"), this);
  connect(minimizeAction, &QAction::triggered, parentwin,
          &QWidget::showMinimized);
  maximizeAction = new QAction(tr("Ma&ximize"), this);
  connect(maximizeAction, &QAction::triggered, parentwin,
          &QWidget::showMaximized);
  restoreAction = new QAction(tr("&Restore"), this);
  connect(restoreAction, &QAction::triggered, parentwin, &QWidget::showNormal);

  quitAction = new QAction(tr("&Quit"), this);
#if QT_VERSION >= QT_VERSION_CHECK(6, 0, 0)
#pragma GCC diagnostic push
#pragma GCC diagnostic ignored "-Wdeprecated-declarations"
#endif
  connect(quitAction, &QAction::triggered, qApp, &QApplication::quit);
#if QT_VERSION >= QT_VERSION_CHECK(6, 0, 0)
#pragma GCC diagnostic pop
#endif
}

/**
 * @brief TrayIcon::createTrayIcon set up menu.
 */
void TrayIcon::createTrayIcon() {
  trayIconMenu = new QMenu(this);
  trayIconMenu->addAction(showAction);
  trayIconMenu->addAction(hideAction);
  trayIconMenu->addAction(minimizeAction);
  trayIconMenu->addAction(maximizeAction);
  trayIconMenu->addAction(restoreAction);
  trayIconMenu->addSeparator();
  trayIconMenu->addAction(quitAction);

  sysTrayIcon = new QSystemTrayIcon(this);
  sysTrayIcon->setContextMenu(trayIconMenu);
}

/**
 * @brief TrayIcon::showHideParent toggle app visibility.
 */
void TrayIcon::showHideParent() {
  if (parentwin->isVisible()) {
    parentwin->hide();
  } else {
    parentwin->show();
  }
}

/**
 * @brief TrayIcon::iconActivated you clicked on the trayicon.
 * @param reason
 */
void TrayIcon::iconActivated(QSystemTrayIcon::ActivationReason reason) {
  switch (reason) {
  case QSystemTrayIcon::Trigger:
  case QSystemTrayIcon::DoubleClick:
    showHideParent();
    break;
  case QSystemTrayIcon::MiddleClick:
    showMessage("test", "test msg", 1000);
    break;
  default: {
  }
  }
}

/**
 * @brief TrayIcon::showMessage show a systray message for notification.
 * @param title
 * @param msg
 * @param time
 */
void TrayIcon::showMessage(const QString &title, const QString &msg, int time) {
  sysTrayIcon->showMessage(title, msg, QSystemTrayIcon::Information, time);
}
