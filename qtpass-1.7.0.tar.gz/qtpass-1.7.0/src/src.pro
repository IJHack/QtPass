!include(../qtpass.pri) { error("Couldn't find the qtpass.pri file!") }

TEMPLATE   = lib
QT        += core gui
TARGET    = qtpass

CONFIG += c++17 staticlib
CONFIG(release, debug|release):DEFINES += QT_NO_DEBUG_OUTPUT

TRANSLATIONS    +=  ../localization/localization_ar_MA.ts \
                    ../localization/localization_ca_ES.ts \
                    ../localization/localization_cs_CZ.ts \
                    ../localization/localization_da_DK.ts \
                    ../localization/localization_de_DE.ts \
                    ../localization/localization_de_LU.ts \
                    ../localization/localization_el_GR.ts \
                    ../localization/localization_en_GB.ts \
                    ../localization/localization_en_US.ts \
                    ../localization/localization_es_ES.ts \
                    ../localization/localization_es_MX.ts \
                    ../localization/localization_es_EC.ts \
                    ../localization/localization_es_AR.ts \
                    ../localization/localization_es_UY.ts \
                    ../localization/localization_et_EE.ts \
                    ../localization/localization_fr_BE.ts \
                    ../localization/localization_fr_FR.ts \
                    ../localization/localization_fr_LU.ts \
                    ../localization/localization_gl_ES.ts \
                    ../localization/localization_he_IL.ts \
                    ../localization/localization_hu_HU.ts \
                    ../localization/localization_it_IT.ts \
                    ../localization/localization_ko_KR.ts \
                    ../localization/localization_lb_LU.ts \
                    ../localization/localization_nb_NO.ts \
                    ../localization/localization_nl_BE.ts \
                    ../localization/localization_nl_NL.ts \
                    ../localization/localization_fy_NL.ts \
                    ../localization/localization_pl_PL.ts \
                    ../localization/localization_pt_BR.ts \
                    ../localization/localization_pt_PT.ts \
                    ../localization/localization_ru_RU.ts \
                    ../localization/localization_sk_SK.ts \
                    ../localization/localization_sq_AL.ts \
                    ../localization/localization_sv_SE.ts \
                    ../localization/localization_tr_TR.ts \
                    ../localization/localization_zh_CN.ts \
                    ../localization/localization_cy_GB.ts \
                    ../localization/localization_hr_HR.ts \
                    ../localization/localization_af_ZA.ts \
                    ../localization/localization_ro_RO.ts \
                    ../localization/localization_si_LK.ts \
                    ../localization/localization_sr_RS.ts \
                    ../localization/localization_sr_Cyrl.ts \
                    ../localization/localization_ja_JP.ts \
                    ../localization/localization_bg_BG.ts \
                    ../localization/localization_fi_FI.ts \
                    ../localization/localization_uk_UA.ts \
                    ../localization/localization_ta_IN.ts \
                    ../localization/localization_zh_Hant.ts

CONFIG += lrelease embed_translations
QM_FILES_RESOURCE_PREFIX=/localization

SOURCES   += mainwindow.cpp \
             configdialog.cpp \
             storemodel.cpp \
             util.cpp \
             usersdialog.cpp \
             keygendialog.cpp \
             trayicon.cpp \
             passworddialog.cpp \
             qprogressindicator.cpp \
             qpushbuttonwithclipboard.cpp \
             qpushbuttonasqrcode.cpp \
             qpushbuttonshowpassword.cpp \
             qtpasssettings.cpp \
             settingsconstants.cpp \
             pass.cpp \
             gpgkeystate.cpp \
             realpass.cpp \
             imitatepass.cpp \
             executor.cpp \
             simpletransaction.cpp \
             filecontent.cpp \
             qtpass.cpp \
             profileinit.cpp

HEADERS   += mainwindow.h \
             configdialog.h \
             storemodel.h \
             util.h \
             usersdialog.h \
             keygendialog.h \
             trayicon.h \
             passworddialog.h \
             qprogressindicator.h \
             deselectabletreeview.h \
             qpushbuttonwithclipboard.h \
             qpushbuttonasqrcode.h \
             qpushbuttonshowpassword.h \
             qtpasssettings.h \
             enums.h \
             settingsconstants.h \
             pass.h \
             gpgkeystate.h \
             realpass.h \
             imitatepass.h \
             debughelper.h \
             executor.h \
             simpletransaction.h \
             filecontent.h \
             passwordconfiguration.h \
             userinfo.h \
             qtpass.h \
             profileinit.h

FORMS     += mainwindow.ui \
             configdialog.ui \
             usersdialog.ui \
             keygendialog.ui \
             passworddialog.ui

!nosingleapp {
    SOURCES += singleapplication.cpp
    HEADERS += singleapplication.h
}

RESOURCES   += ../resources.qrc
