<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="sk_SK">
<context>
    <name>ConfigDialog</name>
    <message>
        <location filename="../src/configdialog.ui" line="20"/>
        <source>Configuration</source>
        <translation>Konfigurácia</translation>
    </message>
    <message>
        <location filename="../src/configdialog.ui" line="46"/>
        <source>Settings</source>
        <translation>Nastavenie</translation>
    </message>
    <message>
        <location filename="../src/configdialog.ui" line="72"/>
        <source>Clipboard behaviour:</source>
        <translation>Chovanie schránky:</translation>
    </message>
    <message>
        <location filename="../src/configdialog.ui" line="91"/>
        <source>Use primary selection</source>
        <translation>Použiť primárny výber</translation>
    </message>
    <message>
        <location filename="../src/configdialog.ui" line="98"/>
        <source>Autoclear after:</source>
        <translation>Vymazať po:</translation>
    </message>
    <message>
        <location filename="../src/configdialog.ui" line="115"/>
        <location filename="../src/configdialog.ui" line="198"/>
        <source>Seconds</source>
        <translation>sekundách</translation>
    </message>
    <message>
        <source>Password Behaviour:</source>
        <translation type="vanished">Password Behaviour:</translation>
    </message>
    <message>
        <location filename="../src/configdialog.ui" line="147"/>
        <source>Content panel behaviour:</source>
        <translation>Chovanie panelu obsahu:</translation>
    </message>
    <message>
        <location filename="../src/configdialog.ui" line="159"/>
        <source>Hide content</source>
        <translation>Skryť obsah</translation>
    </message>
    <message>
        <location filename="../src/configdialog.ui" line="166"/>
        <source>Hide password</source>
        <translation>Skryť heslo</translation>
    </message>
    <message>
        <location filename="../src/configdialog.ui" line="175"/>
        <source>Autoclear panel after:</source>
        <translation>Vymazať panel po:</translation>
    </message>
    <message>
        <location filename="../src/configdialog.ui" line="224"/>
        <source>Use a monospace font</source>
        <translation>Použite monopriestorový font</translation>
    </message>
    <message>
        <location filename="../src/configdialog.ui" line="231"/>
        <source>Display the files content as-is</source>
        <translation>Zobrazenie obsahu súborov ako-is</translation>
    </message>
    <message>
        <location filename="../src/configdialog.ui" line="238"/>
        <source>No line wrapping</source>
        <translation>Nezalamovať riadky</translation>
    </message>
    <message>
        <location filename="../src/configdialog.ui" line="270"/>
        <source>Password Generation:</source>
        <translation>Generovanie hesiel:</translation>
    </message>
    <message>
        <location filename="../src/configdialog.ui" line="282"/>
        <source>Password Length:</source>
        <translation>Dĺžka hesla:</translation>
    </message>
    <message>
        <location filename="../src/configdialog.ui" line="316"/>
        <source>Characters</source>
        <translation>znakov</translation>
    </message>
    <message>
        <location filename="../src/configdialog.ui" line="344"/>
        <source>Use characters:</source>
        <translation>Použiť znakov:</translation>
    </message>
    <message>
        <location filename="../src/configdialog.ui" line="362"/>
        <source>Select character set for password generation</source>
        <translation>Vyberte znakovú sadu pre generovanie hesla</translation>
    </message>
    <message>
        <location filename="../src/configdialog.ui" line="366"/>
        <source>All Characters</source>
        <translation>Všetky znaky</translation>
    </message>
    <message>
        <location filename="../src/configdialog.ui" line="371"/>
        <source>Alphabetical</source>
        <translation>Abecedné</translation>
    </message>
    <message>
        <location filename="../src/configdialog.ui" line="376"/>
        <source>Alphanumerical</source>
        <translation>Afanumerické</translation>
    </message>
    <message>
        <location filename="../src/configdialog.ui" line="381"/>
        <source>Custom</source>
        <translation>Vlastné</translation>
    </message>
    <message>
        <location filename="../src/configdialog.ui" line="419"/>
        <source>ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789</source>
        <translation>ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789</translation>
    </message>
    <message>
        <location filename="../src/configdialog.ui" line="453"/>
        <source>Include special symbols</source>
        <translation>Používať špeciálne znaky</translation>
    </message>
    <message>
        <location filename="../src/configdialog.ui" line="592"/>
        <source>Enable content search (pass grep)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/configdialog.ui" line="595"/>
        <source>Allow searching inside password file contents. Requires decrypting every file and can be slow on large stores.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/configdialog.ui" line="769"/>
        <source>Generate</source>
        <translation>Generovať</translation>
    </message>
    <message>
        <location filename="../src/configdialog.ui" line="772"/>
        <source>Generate GPG key pair</source>
        <translation>Generovať pár GPG kľúčov</translation>
    </message>
    <message>
        <location filename="../src/configdialog.ui" line="945"/>
        <source>Profile name, used to identify this configuration profile</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/configdialog.ui" line="953"/>
        <source>Path to the password store directory</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/configdialog.ui" line="958"/>
        <source>Signing Key</source>
        <translation>Podpisový kľúč</translation>
    </message>
    <message>
        <location filename="../src/configdialog.ui" line="961"/>
        <source>Optional: GPG key to sign .gpg-id files for integrity verification. Leave empty unless you need to protect the user list from tampering.</source>
        <translation>Voliteľné: Kľúč GPG na podpísanie súborov .gpg-id pre overenie integrity. Toto pole ponechajte prázdne, ak nepotrebujete chrániť zoznam používateľov pred modifikáciou.</translation>
    </message>
    <message>
        <location filename="../src/configdialog.ui" line="1001"/>
        <source>Current path</source>
        <translation>Aktuálna cesta</translation>
    </message>
    <message>
        <source>Use pwgen</source>
        <translation type="vanished">Use pwgen</translation>
    </message>
    <message>
        <location filename="../src/configdialog.ui" line="443"/>
        <source>Exclude capital letters</source>
        <translation>Nepoužívať VEĽKÉ písmená</translation>
    </message>
    <message>
        <source>Include special symbols </source>
        <translation type="vanished">Include special symbols </translation>
    </message>
    <message>
        <location filename="../src/configdialog.ui" line="460"/>
        <source>Generate easy to memorize but less secure passwords</source>
        <translation>Generovať zapamätateľné menej bezpečné heslá</translation>
    </message>
    <message>
        <location filename="../src/configdialog.ui" line="467"/>
        <source>Exclude numbers</source>
        <translation>Nepoužívať čísla</translation>
    </message>
    <message>
        <location filename="../src/configdialog.ui" line="486"/>
        <source>Git:</source>
        <translation>Git:</translation>
    </message>
    <message>
        <source>Use git</source>
        <translation type="vanished">Use git</translation>
    </message>
    <message>
        <location filename="../src/configdialog.ui" line="512"/>
        <source>Automatically add .gpg-id files</source>
        <translation>Automaticky pridať .gpg-id súbory</translation>
    </message>
    <message>
        <location filename="../src/configdialog.ui" line="519"/>
        <source>Automatically push</source>
        <translation>Automaticky odosielať</translation>
    </message>
    <message>
        <location filename="../src/configdialog.ui" line="526"/>
        <source>Automatically pull</source>
        <translation>Automaticky sťahovať</translation>
    </message>
    <message>
        <location filename="../src/configdialog.ui" line="558"/>
        <source>Extensions:</source>
        <translation>Rozšírenia:</translation>
    </message>
    <message>
        <source>Use pass otp extension</source>
        <translation type="vanished">Use pass otp extension</translation>
    </message>
    <message>
        <location filename="../src/configdialog.ui" line="617"/>
        <source>System:</source>
        <translation>Systém:</translation>
    </message>
    <message>
        <location filename="../src/configdialog.ui" line="629"/>
        <source>Use TrayIcon</source>
        <translation>Zobraziť ikonu</translation>
    </message>
    <message>
        <location filename="../src/configdialog.ui" line="636"/>
        <source>Start minimized</source>
        <translation>Spustiť minimalizovane</translation>
    </message>
    <message>
        <location filename="../src/configdialog.ui" line="643"/>
        <source>Hide on close</source>
        <translation>Skryť pri zatvorení</translation>
    </message>
    <message>
        <location filename="../src/configdialog.ui" line="650"/>
        <source>Always on top</source>
        <translation>Vždy navrchu</translation>
    </message>
    <message>
        <location filename="../src/configdialog.ui" line="675"/>
        <source>Programs</source>
        <translation>Programy</translation>
    </message>
    <message>
        <location filename="../src/configdialog.ui" line="693"/>
        <source>Select password storage program:</source>
        <translation>Vybrať program správy hesiel:</translation>
    </message>
    <message>
        <source>Nati&amp;ve git/gpg</source>
        <translation type="vanished">Nati&amp;ve git/gpg</translation>
    </message>
    <message>
        <location filename="../src/configdialog.ui" line="709"/>
        <source>&amp;Use pass</source>
        <translation>Po&amp;užiť pass</translation>
    </message>
    <message>
        <location filename="../src/configdialog.ui" line="733"/>
        <source>Native</source>
        <translation>Východzie</translation>
    </message>
    <message>
        <source>git</source>
        <translation type="vanished">git</translation>
    </message>
    <message>
        <source>...</source>
        <translation type="vanished">...</translation>
    </message>
    <message>
        <source>gpg</source>
        <translation type="vanished">gpg</translation>
    </message>
    <message>
        <source>pwgen</source>
        <translation type="vanished">pwgen</translation>
    </message>
    <message>
        <location filename="../src/configdialog.ui" line="809"/>
        <source>Pass</source>
        <translation>Pass</translation>
    </message>
    <message>
        <location filename="../src/configdialog.ui" line="820"/>
        <source>pass</source>
        <translation>pass</translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;a href=&quot;https://www.passwordstore.org/&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0000ff;&quot;&gt;www.passwordstore.org&lt;/span&gt;&lt;/a&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="vanished">&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;a href=&quot;https://www.passwordstore.org/&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0000ff;&quot;&gt;www.passwordstore.org&lt;/span&gt;&lt;/a&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../src/configdialog.ui" line="893"/>
        <source>Profiles</source>
        <translation>Profily</translation>
    </message>
    <message>
        <location filename="../src/configdialog.ui" line="942"/>
        <source>Name</source>
        <translation>Meno</translation>
    </message>
    <message>
        <location filename="../src/configdialog.ui" line="950"/>
        <source>Path</source>
        <translation>Cesta</translation>
    </message>
    <message>
        <location filename="../src/configdialog.ui" line="971"/>
        <source>Add</source>
        <translation>Pridať</translation>
    </message>
    <message>
        <location filename="../src/configdialog.ui" line="986"/>
        <source>Delete</source>
        <translation>Zmazať</translation>
    </message>
    <message>
        <source>Current password-store</source>
        <translation type="vanished">Current password-store</translation>
    </message>
    <message>
        <location filename="../src/configdialog.ui" line="1021"/>
        <source>Template</source>
        <translation>Šablóna</translation>
    </message>
    <message>
        <source>Templates add extra fields in the password generation dialogue and in the password view.</source>
        <translation type="vanished">Templates add extra fields in the password generation dialogue and in the password view.</translation>
    </message>
    <message>
        <location filename="../src/configdialog.ui" line="1051"/>
        <source>Use template</source>
        <translation>Použiť šablonu</translation>
    </message>
    <message>
        <location filename="../src/configdialog.ui" line="1058"/>
        <source>Show all lines beginning with a word followed by a colon as fields in password fields, not only the listed ones</source>
        <translation>Zobraziť všetky riadky začínajúce slovom nasledované bodkočiarkou ako pole v položkách hesla, nie len vypísané</translation>
    </message>
    <message>
        <location filename="../src/configdialog.ui" line="1061"/>
        <source>Show all fields templated</source>
        <translation>Zobraziť všetky polia v šablóne</translation>
    </message>
    <message>
        <source>login
url
email</source>
        <translation type="vanished">login
url
email</translation>
    </message>
    <message>
        <location filename="../src/configdialog.ui" line="1088"/>
        <source>&lt;a href=&quot;https://QtPass.org/&quot;&gt;QtPass&lt;/a&gt; version </source>
        <translation>&lt;a href=&quot;https://QtPass.org/&quot;&gt;QtPass&lt;/a&gt; verzia </translation>
    </message>
    <message>
        <location filename="../src/configdialog.cpp" line="124"/>
        <source>No Clipboard</source>
        <translation>Bez schránky</translation>
    </message>
    <message>
        <location filename="../src/configdialog.cpp" line="125"/>
        <source>Always copy to clipboard</source>
        <translation>Vždy skopírovať do schránky</translation>
    </message>
    <message>
        <location filename="../src/configdialog.cpp" line="126"/>
        <source>On-demand copy to clipboard</source>
        <translation>Na vyžiadanie skopírovať do schránky</translation>
    </message>
    <message>
        <location filename="../src/configdialog.cpp" line="207"/>
        <location filename="../src/configdialog.cpp" line="223"/>
        <source>This field is required</source>
        <translation>Toto políčko je povinné</translation>
    </message>
    <message>
        <location filename="../src/configdialog.cpp" line="653"/>
        <source>Select recipients for %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/configdialog.cpp" line="671"/>
        <source>New Profile</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/configdialog.cpp" line="703"/>
        <source>No profile selected</source>
        <translation>Nebol vybraný profil</translation>
    </message>
    <message>
        <location filename="../src/configdialog.cpp" line="704"/>
        <source>No profile selected to delete</source>
        <translation>Nebol vybraný profil pre zmazanie</translation>
    </message>
    <message>
        <location filename="../src/configdialog.cpp" line="803"/>
        <source>GnuPG not found</source>
        <translation>GnuPG nenájdené</translation>
    </message>
    <message>
        <location filename="../src/configdialog.cpp" line="817"/>
        <source>Please install GnuPG on your system.&lt;br&gt;Install &lt;strong&gt;gpg&lt;/strong&gt; using your favorite package manager&lt;br&gt;or &lt;a href=&quot;https://www.gnupg.org/download/#sec-1-2&quot;&gt;download&lt;/a&gt; it from GnuPG.org</source>
        <translation>Nainštalujte prosím GnuPG na svoj systém.&lt;br&gt;Nainštalujte &lt;strong&gt;gpg&lt;/strong&gt; použitím uprednostňovaného správcau balíkov&lt;br&gt;alebo ho &lt;a href=&quot;https://www.gnupg.org/download/#sec-1-2&quot;&gt;stiahnite&lt;/a&gt; z GnuPG.org</translation>
    </message>
    <message>
        <location filename="../src/configdialog.cpp" line="871"/>
        <source>Create password-store?</source>
        <translation>Vytvoriť úložisko hesiel?</translation>
    </message>
    <message>
        <location filename="../src/configdialog.cpp" line="872"/>
        <source>Would you like to create a password-store at %1?</source>
        <translation>Chcete vytvoriť úložisko hesiel v %1?</translation>
    </message>
    <message>
        <location filename="../src/configdialog.cpp" line="877"/>
        <source>Error</source>
        <translation>Chyba</translation>
    </message>
    <message>
        <location filename="../src/configdialog.cpp" line="878"/>
        <source>Failed to create password-store at: %1</source>
        <translation>Nepodarilo sa vytvoriť úložisko hesiel na adrese: %1</translation>
    </message>
    <message>
        <location filename="../src/configdialog.cpp" line="909"/>
        <source>Password store not initialised</source>
        <translation>Úložisko hesiel nie je vytvorené</translation>
    </message>
    <message>
        <location filename="../src/configdialog.cpp" line="910"/>
        <source>The folder %1 doesn&apos;t seem to be a password store or is not yet initialised.</source>
        <translation>Adresár %1 nevyzerá ako úložisko hesiel, alebo ešte nebol vytvorený.</translation>
    </message>
    <message>
        <location filename="../src/configdialog.ui" line="839"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;a href=&quot;https://www.passwordstore.org/&quot;&gt;&lt;span style=&quot; text-decoration: underline;&quot;&gt;www.passwordstore.org&lt;/span&gt;&lt;/a&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;a href=&quot;https://www.passwordstore.org/&quot;&gt;&lt;span style=&quot; text-decoration: underline;&quot;&gt;www.passwordstore.org&lt;/span&gt;&lt;/a&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../src/configdialog.ui" line="870"/>
        <source>Autodetect</source>
        <translation>Automaticky</translation>
    </message>
    <message>
        <location filename="../src/configdialog.cpp" line="68"/>
        <source>System tray is not available</source>
        <translation>Systémová lišta nie je k dispozícii</translation>
    </message>
    <message>
        <location filename="../src/configdialog.cpp" line="93"/>
        <source>Pass OTP extension needs to be installed</source>
        <translation>Je potrebné nainštalovať rozšírenie OTP pass</translation>
    </message>
    <message>
        <location filename="../src/configdialog.cpp" line="98"/>
        <source>qrencode needs to be installed</source>
        <translation>je potrebné nainštalovať nástroj qrencode</translation>
    </message>
    <message>
        <location filename="../src/configdialog.cpp" line="806"/>
        <source>Please install GnuPG on your system.&lt;br&gt;Install &lt;strong&gt;Ubuntu&lt;/strong&gt; from the Microsoft Store to get it.&lt;br&gt;If you already did so, make sure you started it once and&lt;br&gt;click &quot;Autodetect&quot; in the next dialog.</source>
        <translation>Nainštalujte si prosím do svojho systému GnuPG. &lt;br&gt; Nainštalujte si z obchodu Microsoft Store &lt;strong&gt; Ubuntu &lt;/strong&gt;. Pokud ste tak už urobili, uistite sa, že ste ho raz spustili a &lt;br&gt; kliknite na „Automaticky“ v ďaľšom okne.</translation>
    </message>
    <message>
        <location filename="../src/configdialog.cpp" line="811"/>
        <source>Please install GnuPG on your system.&lt;br&gt;Install &lt;strong&gt;Ubuntu&lt;/strong&gt; from the Microsoft Store&lt;br&gt;or &lt;a href=&quot;https://www.gnupg.org/download/#sec-1-2&quot;&gt;download&lt;/a&gt; it from GnuPG.org</source>
        <translation>Nainštalujte prosím do svojho systému GnuPG. &lt;br&gt; Nainštalujte &lt;strong&gt; Ubuntu &lt;/strong&gt; z Microsoft Store &lt;br&gt; alebo &lt;a href = &quot;https://www.gnupg.org/download/#sec-1-2 &quot;&gt; si ho stiahnite z &lt;/a&gt; z GnuPG.org</translation>
    </message>
    <message>
        <location filename="../src/configdialog.ui" line="436"/>
        <source>Use PWGen</source>
        <translation>Použiť PWGen</translation>
    </message>
    <message>
        <location filename="../src/configdialog.ui" line="498"/>
        <source>Use Git</source>
        <translation>Použiť Git</translation>
    </message>
    <message>
        <location filename="../src/configdialog.ui" line="567"/>
        <source>Use QRencode</source>
        <translation>Použiť QRencode</translation>
    </message>
    <message>
        <location filename="../src/configdialog.ui" line="581"/>
        <source>Use pass-otp extension</source>
        <translation>Použiť rozšírenie pass-otp</translation>
    </message>
    <message>
        <location filename="../src/configdialog.ui" line="702"/>
        <source>Nati&amp;ve Git/GPG</source>
        <translation>Natí&amp;vny Git/GPG</translation>
    </message>
    <message>
        <location filename="../src/configdialog.ui" line="739"/>
        <source>Git</source>
        <translation>Git</translation>
    </message>
    <message>
        <location filename="../src/configdialog.ui" line="749"/>
        <location filename="../src/configdialog.ui" line="756"/>
        <location filename="../src/configdialog.ui" line="799"/>
        <location filename="../src/configdialog.ui" line="830"/>
        <location filename="../src/configdialog.ui" line="1008"/>
        <source>…</source>
        <translation>…</translation>
    </message>
    <message>
        <location filename="../src/configdialog.ui" line="779"/>
        <source>GPG</source>
        <translation>GPG</translation>
    </message>
    <message>
        <location filename="../src/configdialog.ui" line="792"/>
        <source>PWGen</source>
        <translation>PWGen</translation>
    </message>
    <message>
        <location filename="../src/configdialog.ui" line="1042"/>
        <source>Templates add extra fields in the password generation dialogue, and in the password view.</source>
        <translation>Šablóny pridávajú ďalšie pole v dialógu pre generovanie hesiel a zobrazení hesla.</translation>
    </message>
    <message>
        <location filename="../src/configdialog.ui" line="1073"/>
        <source>login
URL
e-mail</source>
        <translation>login
URL
e-mail</translation>
    </message>
</context>
<context>
    <name>ImitatePass</name>
    <message>
        <location filename="../src/imitatepass.cpp" line="141"/>
        <location filename="../src/imitatepass.cpp" line="319"/>
        <location filename="../src/imitatepass.cpp" line="505"/>
        <source>Check .gpgid file signature!</source>
        <translation>Skontrolujte .gpgid podpis súborov!</translation>
    </message>
    <message>
        <location filename="../src/imitatepass.cpp" line="142"/>
        <location filename="../src/imitatepass.cpp" line="320"/>
        <location filename="../src/imitatepass.cpp" line="506"/>
        <source>Signature for %1 is invalid.</source>
        <translation>Podpis pre %1 je neplatný.</translation>
    </message>
    <message>
        <location filename="../src/imitatepass.cpp" line="149"/>
        <location filename="../src/imitatepass.cpp" line="598"/>
        <source>Can not edit</source>
        <translation>Nie je možné upravovať</translation>
    </message>
    <message>
        <location filename="../src/imitatepass.cpp" line="150"/>
        <location filename="../src/imitatepass.cpp" line="599"/>
        <source>Could not read encryption key to use, .gpg-id file missing or invalid.</source>
        <translation>Nemôžem načítať šifrovací kľúč, .gpg-id súbor chýba alebo je neplatný.</translation>
    </message>
    <message>
        <location filename="../src/imitatepass.cpp" line="314"/>
        <source>GPG signing failed!</source>
        <translation>GPG podpis zlyhal!</translation>
    </message>
    <message>
        <location filename="../src/imitatepass.cpp" line="315"/>
        <source>Failed to sign %1.</source>
        <translation>Nepodarilo sa podpísať %1.</translation>
    </message>
    <message>
        <location filename="../src/imitatepass.cpp" line="382"/>
        <source>No signing key!</source>
        <translation>Žiadny podpisový kľúč!</translation>
    </message>
    <message>
        <location filename="../src/imitatepass.cpp" line="383"/>
        <source>None of the secret signing keys is available.
You will not be able to change the user list!</source>
        <translation>Nie je k dispozícii žiadne z tajných podpisovacích kľúčov.
Nebudete môcť zmeniť zoznam užívateľov!</translation>
    </message>
    <message>
        <location filename="../src/imitatepass.cpp" line="260"/>
        <source>Cannot update</source>
        <translation>Nie je možné aktualizovať</translation>
    </message>
    <message>
        <location filename="../src/imitatepass.cpp" line="261"/>
        <source>Failed to open .gpg-id for writing.</source>
        <translation>Zlyhalo otvorenie .gpg-id pre zápis.</translation>
    </message>
    <message>
        <location filename="../src/imitatepass.cpp" line="274"/>
        <source>Check selected users!</source>
        <translation>Skontrolujte vybraných používateľov!</translation>
    </message>
    <message>
        <location filename="../src/imitatepass.cpp" line="275"/>
        <source>None of the selected keys have a secret key available.
You will not be able to decrypt any newly added passwords!</source>
        <translation>Pre žiadny z vybraných kľúčov nie je dostupný tajný kľúč.
Nebudete môcť dešifrovať žiadne novo pridané heslá!</translation>
    </message>
    <message>
        <location filename="../src/imitatepass.cpp" line="662"/>
        <location filename="../src/imitatepass.cpp" line="769"/>
        <source>Re-encryption failed</source>
        <translation>Rešifrovanie zlyhalo</translation>
    </message>
    <message>
        <location filename="../src/imitatepass.cpp" line="663"/>
        <source>Failed to replace %1. Original has been restored.</source>
        <translation>Nedokázalo sa nahradit %1. Pôvodný obsah bol obnovený.</translation>
    </message>
    <message>
        <location filename="../src/imitatepass.cpp" line="692"/>
        <source>Creating backup commit</source>
        <translation>Vytváranie zálohového commitu</translation>
    </message>
    <message>
        <location filename="../src/imitatepass.cpp" line="698"/>
        <location filename="../src/imitatepass.cpp" line="706"/>
        <source>Backup commit failed</source>
        <translation>Záložné komitovanie zlyhalo</translation>
    </message>
    <message>
        <location filename="../src/imitatepass.cpp" line="699"/>
        <source>Could not inspect git status. Re-encryption was aborted.</source>
        <translation>Nedalo sa overiť stav Gitu. Re-šifrovanie bolo zrušené.</translation>
    </message>
    <message>
        <location filename="../src/imitatepass.cpp" line="707"/>
        <source>Re-encryption was aborted because a git backup could not be created.</source>
        <translation>Re-šifrovanie bolo zrušené, pretože nemožno vytvoriť Gitovu zálohu.</translation>
    </message>
    <message>
        <location filename="../src/imitatepass.cpp" line="729"/>
        <source>Re-encrypting from folder %1</source>
        <translation>Zašifrovávam z adresára %1</translation>
    </message>
    <message>
        <location filename="../src/imitatepass.cpp" line="732"/>
        <location filename="../src/imitatepass.cpp" line="787"/>
        <source>Updating password-store</source>
        <translation>Aktualizácia úložiska hesiel</translation>
    </message>
    <message>
        <location filename="../src/imitatepass.cpp" line="757"/>
        <source>GPG ID verification failed</source>
        <translation>Overenie GPG ID zlyhala</translation>
    </message>
    <message>
        <location filename="../src/imitatepass.cpp" line="758"/>
        <source>Could not verify .gpg-id for directory.</source>
        <translation>Nedalo sa overiť .gpg-id pre priečinok.</translation>
    </message>
    <message>
        <location filename="../src/imitatepass.cpp" line="770"/>
        <source>Failed to re-encrypt %1</source>
        <translation>Nedalo sa re-šifrovať %1</translation>
    </message>
    <message>
        <location filename="../src/imitatepass.cpp" line="776"/>
        <source>Re-encryption completed: %1 succeeded, %2 failed</source>
        <translation>Prešifrovanie dokončené: %1 úspešných, %2 zlyhalo</translation>
    </message>
    <message>
        <location filename="../src/imitatepass.cpp" line="782"/>
        <source>Re-encryption completed: %1 files re-encrypted</source>
        <translation>Prešifrovanie dokončené: %1 súborov prešifrovaných</translation>
    </message>
</context>
<context>
    <name>KeygenDialog</name>
    <message>
        <location filename="../src/keygendialog.ui" line="14"/>
        <source>Generate GnuPG keypair</source>
        <translation>Generovať GnuPG kľúče</translation>
    </message>
    <message>
        <location filename="../src/keygendialog.ui" line="42"/>
        <source>Generate a new key pair</source>
        <translation>Generovať nový pár kľúčov</translation>
    </message>
    <message>
        <location filename="../src/keygendialog.ui" line="155"/>
        <source>Passphrase</source>
        <translation>Bezpečnostné heslo</translation>
    </message>
    <message>
        <location filename="../src/keygendialog.ui" line="91"/>
        <source>Email</source>
        <translation>Email</translation>
    </message>
    <message>
        <location filename="../src/keygendialog.ui" line="123"/>
        <source>Name</source>
        <translation>Meno</translation>
    </message>
    <message>
        <location filename="../src/keygendialog.ui" line="200"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;There is no limit on the length of a passphrase, and it should be carefully chosen. From the perspective of security, the passphrase to unlock the private key is one of the weakest points in GnuPG (and other public-key encryption systems as well) since it is the only protection you have if another individual gets your private key. &lt;br/&gt;Ideally, the passphrase should not use words from a dictionary and should mix the case of alphabetic characters as well as use non-alphabetic characters.&lt;br/&gt;A good passphrase is crucial to the secure use of GnuPG.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Dĺžka bezpečnostného hesla nie je nijako obmedzená a malo by byť zvolené s rozvahou. Z bezpečnostného pohľadu je heslo odomykajúce privátny kľúč jedným z najslabších bodov v GnuPG (a iných šifrovacích systémov na podobnom princípe) pretože je jedinou ochranou v prípade, že se dalšia osoba zmocní privátneho kľúča. &lt;br/&gt;Ideálne by bezpečnostné heslo nemalo obsahovať slovníkové heslá a naopak malo používať mix veľkých a malých znakov abecedy a dalšie špeciálne znaky.&lt;br/&gt;Dobré heslo je zásadné pre bezpečné používanie GnuPG.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../src/keygendialog.ui" line="210"/>
        <source>Repeat pass</source>
        <translation>Opakujte priechod</translation>
    </message>
    <message>
        <location filename="../src/keygendialog.ui" line="227"/>
        <source>Expert</source>
        <translation>Expert</translation>
    </message>
    <message>
        <location filename="../src/keygendialog.ui" line="246"/>
        <source>Template contents will be set based on GPG version.</source>
        <translation>Obsah šablóny bude založený na verzii GPG.</translation>
    </message>
    <message>
        <source>#           QtPass GPG key generator
#
#      first test version please comment
#
%echo Generating a default key
Key-Type: RSA
Subkey-Type: RSA
Name-Real:
Name-Comment: QtPass
Name-Email:
Expire-Date: 0
%no-protection
# Do a commit here, so that we can later print &quot;done&quot; :-)
%commit
%echo done</source>
        <translation type="vanished"># QtPass GPG kľúčový generátor
#
# prvá verzia testu prosím komentár
#
%echo Vytvorenie predvoleného kľúča
Key-Type: RSA
Subkey-Type: RSA
Meno-Real:
Meno-Koment: QtPass
Meno-E-mail:
Uplynie-Date: 0
%no-ochrana
# Urobte tu, aby sme mohli neskôr tlačiť &quot;done&quot; :-)
%com
%echo hotové</translation>
    </message>
    <message>
        <source>#           QtPass GPG key generator
#
#      first test version please comment
#
%echo Generating a default key
Key-Type: default
Subkey-Type: default
Name-Real:
Name-Comment: QtPass
Name-Email:
Expire-Date: 0
%no-protection
# Do a commit here, so that we can later print &quot;done&quot; :-)
%commit
%echo done</source>
        <translation type="vanished">#           QtPass GPG key generator
#
#      first test version please comment
#
%echo Generating a default key
Key-Type: default
Subkey-Type: default
Name-Real:
Name-Comment: QtPass
Name-Email:
Expire-Date: 0
%no-protection
# Do a commit here, so that we can later print &quot;done&quot; :-)
%commit
%echo done</translation>
    </message>
    <message>
        <location filename="../src/keygendialog.ui" line="259"/>
        <source>For expert options check out the &lt;a href=&quot;https://www.gnupg.org/documentation/manuals/gnupg/Unattended-GPG-key-generation.html&quot;&gt;GnuPG manual&lt;/a&gt;</source>
        <translation>Expertné nastavenia môžete nájisť v &lt;a href=&quot;https://www.gnupg.org/documentation/manuals/gnupg/Unattended-GPG-key-generation.html&quot;&gt;GnuPG manuále&lt;/a&gt;</translation>
    </message>
    <message>
        <location filename="../src/keygendialog.cpp" line="168"/>
        <source>Invalid name</source>
        <translation>Neplatné meno</translation>
    </message>
    <message>
        <location filename="../src/keygendialog.cpp" line="169"/>
        <source>Name must be at least 5 characters long.</source>
        <translation>Meno musí mať najmenej päť znakov.</translation>
    </message>
    <message>
        <location filename="../src/keygendialog.cpp" line="180"/>
        <source>Invalid email</source>
        <translation>Neplatný email</translation>
    </message>
    <message>
        <location filename="../src/keygendialog.cpp" line="181"/>
        <source>The email address you typed is not a valid email address.</source>
        <translation>E-mailová adresa, ktorú ste zadali, nie je platná e-mailová adresa.</translation>
    </message>
    <message>
        <location filename="../src/keygendialog.cpp" line="196"/>
        <source>This operation can take some minutes.&lt;br /&gt;We need to generate a lot of random bytes. It is a good idea to perform some other action (type on the keyboard, move the mouse, utilize the disks) during the prime generation; this gives the random number generator a better chance to gain enough entropy.</source>
        <translation>Táto operácia môže zabrať niekoľko minút.&lt;br /&gt;Je potrebné vygenerovať množstvo náhodných dát. Pre urýchlenie môžete pomôcť (písaním na klávesnici, pohybovaním myšou, zapisovaním na disk) s ich generovaním; toto pomôže generátoru náhodných čísel zvýšiť šancu na získanie dostatočnej entropie.</translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../src/mainwindow.ui" line="14"/>
        <source>QtPass</source>
        <translation>QtPass</translation>
    </message>
    <message>
        <source>Add</source>
        <translation type="vanished">Add</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="398"/>
        <location filename="../src/mainwindow.ui" line="401"/>
        <location filename="../src/mainwindow.cpp" line="1199"/>
        <source>Edit</source>
        <translation>Upraviť</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="406"/>
        <location filename="../src/mainwindow.ui" line="409"/>
        <location filename="../src/mainwindow.cpp" line="1213"/>
        <source>Delete</source>
        <translation>Zmazať</translation>
    </message>
    <message>
        <source>git push</source>
        <translation type="vanished">git push</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="425"/>
        <source>Push</source>
        <translation>Odoslať</translation>
    </message>
    <message>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Cantarell&apos;; font-size:11pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;Helvetica Neue,Helvetica,Segoe UI,Arial,freesans,sans-serif&apos;; font-size:13pt; font-weight:600; color:#333333;&quot;&gt;QtPass&lt;/span&gt;&lt;span style=&quot; font-family:&apos;Helvetica Neue,Helvetica,Segoe UI,Arial,freesans,sans-serif&apos;; font-size:13pt; color:#333333;&quot;&gt; is a GUI for &lt;/span&gt;&lt;a href=&quot;https://www.passwordstore.org/&quot;&gt;&lt;span style=&quot; font-family:&apos;Helvetica Neue,Helvetica,Segoe UI,Arial,freesans,sans-serif&apos;; font-size:13pt; text-decoration: underline; color:#4183c4; background-color:transparent;&quot;&gt;pass&lt;/span&gt;&lt;/a&gt;&lt;span style=&quot; font-family:&apos;Helvetica Neue,Helvetica,Segoe UI,Arial,freesans,sans-serif&apos;; font-size:13pt; color:#333333;&quot;&gt;, the standard unix password manager.&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;Helvetica Neue,Helvetica,Segoe UI,Arial,freesans,sans-serif&apos;; font-size:13pt; color:#333333;&quot;&gt;&lt;br /&gt;Please report any &lt;/span&gt;&lt;a href=&quot;https://github.com/IJHack/qtpass/issues&quot;&gt;&lt;span style=&quot; font-family:&apos;Helvetica Neue,Helvetica,Segoe UI,Arial,freesans,sans-serif&apos;; font-size:13pt; text-decoration: underline; color:#4183c4;&quot;&gt;issues&lt;/span&gt;&lt;/a&gt;&lt;span style=&quot; font-family:&apos;Helvetica Neue,Helvetica,Segoe UI,Arial,freesans,sans-serif&apos;; font-size:13pt; color:#333333;&quot;&gt; you might have with this software.&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;a href=&quot;https://qtpass.org/&quot;&gt;&lt;span style=&quot; font-family:&apos;Helvetica Neue,Helvetica,Segoe UI,Arial,freesans,sans-serif&apos;; font-size:13pt; text-decoration: underline; color:#4183c4; background-color:transparent;&quot;&gt;Documentation&lt;/span&gt;&lt;/a&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;a href=&quot;https://github.com/IJHack/qtpass&quot;&gt;&lt;span style=&quot; font-family:&apos;Noto Sans&apos;; font-size:12pt; text-decoration: underline; color:#4183c4;&quot;&gt;SourceCode&lt;/span&gt;&lt;/a&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="vanished">&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Cantarell&apos;; font-size:11pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;Helvetica Neue,Helvetica,Segoe UI,Arial,freesans,sans-serif&apos;; font-size:13pt; font-weight:600; color:#333333;&quot;&gt;QtPass&lt;/span&gt;&lt;span style=&quot; font-family:&apos;Helvetica Neue,Helvetica,Segoe UI,Arial,freesans,sans-serif&apos;; font-size:13pt; color:#333333;&quot;&gt; is a GUI for &lt;/span&gt;&lt;a href=&quot;https://www.passwordstore.org/&quot;&gt;&lt;span style=&quot; font-family:&apos;Helvetica Neue,Helvetica,Segoe UI,Arial,freesans,sans-serif&apos;; font-size:13pt; text-decoration: underline; color:#4183c4; background-color:transparent;&quot;&gt;pass&lt;/span&gt;&lt;/a&gt;&lt;span style=&quot; font-family:&apos;Helvetica Neue,Helvetica,Segoe UI,Arial,freesans,sans-serif&apos;; font-size:13pt; color:#333333;&quot;&gt;, the standard unix password manager.&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;Helvetica Neue,Helvetica,Segoe UI,Arial,freesans,sans-serif&apos;; font-size:13pt; color:#333333;&quot;&gt;&lt;br /&gt;Please report any &lt;/span&gt;&lt;a href=&quot;https://github.com/IJHack/qtpass/issues&quot;&gt;&lt;span style=&quot; font-family:&apos;Helvetica Neue,Helvetica,Segoe UI,Arial,freesans,sans-serif&apos;; font-size:13pt; text-decoration: underline; color:#4183c4;&quot;&gt;issues&lt;/span&gt;&lt;/a&gt;&lt;span style=&quot; font-family:&apos;Helvetica Neue,Helvetica,Segoe UI,Arial,freesans,sans-serif&apos;; font-size:13pt; color:#333333;&quot;&gt; you might have with this software.&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;a href=&quot;https://qtpass.org/&quot;&gt;&lt;span style=&quot; font-family:&apos;Helvetica Neue,Helvetica,Segoe UI,Arial,freesans,sans-serif&apos;; font-size:13pt; text-decoration: underline; color:#4183c4; background-color:transparent;&quot;&gt;Documentation&lt;/span&gt;&lt;/a&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;a href=&quot;https://github.com/IJHack/qtpass&quot;&gt;&lt;span style=&quot; font-family:&apos;Noto Sans&apos;; font-size:12pt; text-decoration: underline; color:#4183c4;&quot;&gt;SourceCode&lt;/span&gt;&lt;/a&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="385"/>
        <source>Ctrl+N</source>
        <translation>Ctrl+N</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="414"/>
        <source>OTP</source>
        <translation>OTP</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="417"/>
        <source>Generate OTP and copy to clipboard</source>
        <translation>Generovať OTP a kopírovať do schránky</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="420"/>
        <source>Ctrl+G</source>
        <translation>Ctrl+G</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="428"/>
        <source>Git push</source>
        <translation>Git push</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="436"/>
        <source>Git pull</source>
        <translation>Git pull</translation>
    </message>
    <message>
        <source>git pull</source>
        <translation type="vanished">git pull</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="433"/>
        <source>Update</source>
        <translation>Stiahnuť</translation>
    </message>
    <message>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;.SF NS Text&apos;; font-size:13pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt; &lt;span style=&quot; font-family:&apos;Lato&apos;;&quot;&gt;QtPass&lt;/span&gt; is a GUI for &lt;a href=&quot;https://www.passwordstore.org/&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0000ff;&quot;&gt;pass&lt;/span&gt;&lt;/a&gt;, the standard unix password manager.&lt;br /&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Please report any &lt;a href=&quot;https://github.com/IJHack/qtpass/issues&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0000ff;&quot;&gt;issues&lt;/span&gt;&lt;/a&gt; you might have with this software.&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;a href=&quot;https://qtpass.org/&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0000ff;&quot;&gt;Documentation&lt;/span&gt;&lt;/a&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;a href=&quot;https://github.com/IJHack/qtpass&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0000ff;&quot;&gt;SourceCode&lt;/span&gt;&lt;/a&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="vanished">&lt;!DOCTYPE HTML&gt;&lt;html&gt;&lt;head&gt; &lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot;/&gt; &lt;style type=&quot;text/css&quot;&gt; p, li { white-space: pre-wrap; } &lt;/style&gt;&lt;/head&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot;font-family: Lato;&quot;&gt;QtPass&lt;/span&gt; is a GUI for &lt;a href=&quot;https://www.passwordstore.org/&quot;&gt;pass&lt;/a&gt;, the standard unix password manager.&lt;br/&gt;&lt;/p&gt;&lt;p&gt;Please report any &lt;a href=&quot;https://github.com/IJHack/qtpass/issues&quot;&gt;issues&lt;/a&gt; you might have with this software.&lt;/p&gt;&lt;p&gt;&lt;a href=&quot;https://qtpass.org/&quot;&gt;Documentation&lt;/a&gt;&lt;/p&gt;&lt;p&gt;&lt;a href=&quot;https://github.com/IJHack/qtpass&quot;&gt;SourceCode&lt;/a&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="444"/>
        <source>Manage who can read password in folder</source>
        <translation>Správa oprávnení čítať dáta v adresári</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="441"/>
        <location filename="../src/mainwindow.cpp" line="1193"/>
        <source>Users</source>
        <translation>Uživatelia</translation>
    </message>
    <message>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;.SF NS Text&apos;; font-size:13pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;Lato&apos;;&quot;&gt;QtPass&lt;/span&gt; is a GUI for &lt;a href=&quot;https://www.passwordstore.org/&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0000ff;&quot;&gt;pass&lt;/span&gt;&lt;/a&gt;, the standard unix password manager.&lt;br /&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Please report any &lt;a href=&quot;https://github.com/IJHack/qtpass/issues&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0000ff;&quot;&gt;issues&lt;/span&gt;&lt;/a&gt; you might have with this software.&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;a href=&quot;https://qtpass.org/&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0000ff;&quot;&gt;Documentation&lt;/span&gt;&lt;/a&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;a href=&quot;https://github.com/IJHack/qtpass&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0000ff;&quot;&gt;SourceCode&lt;/span&gt;&lt;/a&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="vanished">&lt;!DOCTYPE HTML&gt;&lt;html&gt;&lt;head&gt; &lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot;/&gt; &lt;style type=&quot;text/css&quot;&gt; p, li { white-space: pre-wrap; } &lt;/style&gt;&lt;/head&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot;font-family: Lato;&quot;&gt;QtPass&lt;/span&gt; is a GUI for &lt;a href=&quot;https://www.passwordstore.org/&quot;&gt;pass&lt;/a&gt;, the standard unix password manager.&lt;br/&gt;&lt;/p&gt;&lt;p&gt;Please report any &lt;a href=&quot;https://github.com/IJHack/qtpass/issues&quot;&gt;issues&lt;/a&gt; you might have with this software.&lt;/p&gt;&lt;p&gt;&lt;a href=&quot;https://qtpass.org/&quot;&gt;Documentation&lt;/a&gt;&lt;/p&gt;&lt;p&gt;&lt;a href=&quot;https://github.com/IJHack/qtpass&quot;&gt;SourceCode&lt;/a&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="452"/>
        <source>Configuration</source>
        <translation>Konfigurácia</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="449"/>
        <source>Config</source>
        <translation>Nastavenia</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="68"/>
        <source>Select profile</source>
        <translation>Vybrať profil</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="127"/>
        <source>Search inside password content (pass grep)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="130"/>
        <source>⌕</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="133"/>
        <source>Content search toggle</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="136"/>
        <source>Toggle content search mode to search inside password files</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="146"/>
        <source>Case-insensitive search</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="149"/>
        <source>Aa</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="152"/>
        <source>Case-insensitive toggle</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="155"/>
        <source>Toggle case-insensitive content search</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="211"/>
        <source>Results</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="263"/>
        <source>Welcome to QtPass</source>
        <translation>Vitajte v QtPass</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="120"/>
        <location filename="../src/mainwindow.cpp" line="536"/>
        <location filename="../src/mainwindow.cpp" line="719"/>
        <source>Search Password</source>
        <translation>Hľadať heslo</translation>
    </message>
    <message>
        <source>qtpass</source>
        <translation type="vanished">qtpass</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="202"/>
        <source>Welcome to QtPass %1</source>
        <translation>Vitajte v QtPass %1</translation>
    </message>
    <message>
        <source>Add Password</source>
        <translation type="vanished">Add Password</translation>
    </message>
    <message>
        <source>Add Folder</source>
        <translation type="vanished">Add Folder</translation>
    </message>
    <message>
        <source>Failed to connect WebDAV:
</source>
        <translation type="vanished">Failed to connect WebDAV:
</translation>
    </message>
    <message>
        <source>QtPass WebDAV password</source>
        <translation type="vanished">QtPass WebDAV password</translation>
    </message>
    <message>
        <source>Enter password to connect to WebDAV:</source>
        <translation type="vanished">Enter password to connect to WebDAV:</translation>
    </message>
    <message>
        <source>fusedav exited unexpectedly
</source>
        <translation type="vanished">fusedav exited unexpectedly
</translation>
    </message>
    <message>
        <source>Failed to start fusedav to connect WebDAV:
</source>
        <translation type="vanished">Failed to start fusedav to connect WebDAV:
</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="340"/>
        <location filename="../src/mainwindow.cpp" line="353"/>
        <source>Updating password-store</source>
        <translation>Aktualizácia úložiska hesiel</translation>
    </message>
    <message>
        <source>Can not edit</source>
        <translation type="vanished">Can not edit</translation>
    </message>
    <message>
        <source>Selected password file does not exist, not able to edit</source>
        <translation type="vanished">Selected password file does not exist, not able to edit</translation>
    </message>
    <message>
        <source>Password hidden</source>
        <translation type="vanished">Password hidden</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="461"/>
        <location filename="../src/mainwindow.cpp" line="760"/>
        <source>Content hidden</source>
        <translation>Skrytý obsah</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="465"/>
        <location filename="../src/mainwindow.cpp" line="1432"/>
        <source>Password</source>
        <translation>Heslo</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="502"/>
        <source>OTP Code</source>
        <translation>Kód OTP</translation>
    </message>
    <message>
        <source>Clipboard cleared</source>
        <translation type="vanished">Clipboard cleared</translation>
    </message>
    <message>
        <source>Clipboard not cleared</source>
        <translation type="vanished">Clipboard not cleared</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="540"/>
        <source>Password and Content hidden</source>
        <translation>Skryté heslo aj obsah</translation>
    </message>
    <message>
        <source>QProcess::FailedToStart</source>
        <translation type="vanished">QProcess::FailedToStart</translation>
    </message>
    <message>
        <source>QProcess::Crashed</source>
        <translation type="vanished">QProcess::Crashed</translation>
    </message>
    <message>
        <source>QProcess::Timedout</source>
        <translation type="vanished">QProcess::Timedout</translation>
    </message>
    <message>
        <source>QProcess::ReadError</source>
        <translation type="vanished">QProcess::ReadError</translation>
    </message>
    <message>
        <source>QProcess::WriteError</source>
        <translation type="vanished">QProcess::WriteError</translation>
    </message>
    <message>
        <source>QProcess::UnknownError</source>
        <translation type="vanished">QProcess::UnknownError</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="620"/>
        <source>Looking for: %1</source>
        <translation>Vyhľadávanie: %1</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="856"/>
        <location filename="../src/mainwindow.cpp" line="1258"/>
        <source>New file</source>
        <translation>Nový súbor</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="857"/>
        <source>New password file: 
(Will be placed in %1 )</source>
        <translation>Nový súbor s heslom: 
(Bude uložený do %1 )</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="894"/>
        <source> and the whole content?</source>
        <translation> a celý obsah?</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="904"/>
        <source> and the whole content? &lt;br&gt;&lt;strong&gt;Attention: there are unexpected files in the given folder, check them before continue.&lt;/strong&gt;</source>
        <translation> a celý obsah? &lt;br&gt; &lt;strong&gt; Pozor: v danom adresári sú neočakávané súbory. Než budete pokračovať, skontrolujte ich. &lt;/strong&gt;</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="914"/>
        <source>Are you sure you want to delete %1%2?</source>
        <translation>Naozaj chcete zmazať %1%2?</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="913"/>
        <source>Delete password?</source>
        <translation>Zmazať heslo?</translation>
    </message>
    <message>
        <source>Are you sure you want to delete %1?</source>
        <translation type="vanished">Are you sure you want to delete %1?</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="913"/>
        <source>Delete folder?</source>
        <translation>Zmazať adresár?</translation>
    </message>
    <message>
        <source> and whole content</source>
        <translation type="vanished"> and whole content</translation>
    </message>
    <message>
        <source>Can not get key list</source>
        <translation type="vanished">Can not get key list</translation>
    </message>
    <message>
        <source>Unable to get list of available gpg keys</source>
        <translation type="vanished">Unable to get list of available gpg keys</translation>
    </message>
    <message>
        <source>Key not found in keyring</source>
        <translation type="vanished">Key not found in keyring</translation>
    </message>
    <message>
        <source>Generating GPG key pair</source>
        <translation type="vanished">Generating GPG key pair</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1062"/>
        <source>Profile changed to %1</source>
        <translation>Profil zmenený na %1</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1190"/>
        <source>Open folder with file manager</source>
        <translation>Otvoriť adresár pomocou Správcu súborov</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="390"/>
        <location filename="../src/mainwindow.ui" line="393"/>
        <location filename="../src/mainwindow.cpp" line="1191"/>
        <source>Add folder</source>
        <translation>Pridať adresár</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="379"/>
        <location filename="../src/mainwindow.ui" line="382"/>
        <location filename="../src/mainwindow.cpp" line="1192"/>
        <source>Add password</source>
        <translation>Pridať heslo</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1259"/>
        <source>New Folder: 
(Will be placed in %1 )</source>
        <translation>Nový adresár: 
(Bude umiestnený do %1 )</translation>
    </message>
    <message>
        <source>Copied to clipboard</source>
        <translation type="vanished">copied to clipboard</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="504"/>
        <source>OTP code copied to clipboard</source>
        <translation>Kód OTP skopírovaný do schránky</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="506"/>
        <source>No OTP code found in this password entry</source>
        <translation>V tomto hesle sa nenašiel žiadny kód OTP</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="670"/>
        <source>Searching…</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="701"/>
        <source>Search content (regex)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="747"/>
        <source>No matches found.</source>
        <translation type="unfinished"></translation>
    </message>
    <message numerus="yes">
        <location filename="../src/mainwindow.cpp" line="770"/>
        <source>Found %n match(es) in %1 entr(ies).</source>
        <translation type="unfinished">
            <numerusform></numerusform>
            <numerusform></numerusform>
            <numerusform></numerusform>
        </translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="934"/>
        <source>No password selected for OTP generation</source>
        <translation>Nie je vybrané žiadne heslo na generovanie OTP</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1205"/>
        <source>Rename folder</source>
        <translation>Premenovať zložku</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1209"/>
        <source>Rename password</source>
        <translation>Premenovať heslo</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1218"/>
        <source>Re-encrypt</source>
        <translation>Znovu šifrovať</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1269"/>
        <location filename="../src/mainwindow.cpp" line="1278"/>
        <location filename="../src/mainwindow.cpp" line="1487"/>
        <source>Error</source>
        <translation>Chyba</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1270"/>
        <source>Failed to create folder: %1</source>
        <translation>Nepodarilo sa vytvoriť priečinok: %1</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1279"/>
        <source>Failed to create .gpg-id file in: %1</source>
        <translation>Nepodarilo sa vytvoriť .gpg-id súbor v: %1</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1301"/>
        <location filename="../src/mainwindow.cpp" line="1337"/>
        <source>Rename file</source>
        <translation>Premenovať súbor</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1301"/>
        <source>Rename Folder To: </source>
        <translation>Premenovať adresár na: </translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1337"/>
        <source>Rename File To: </source>
        <translation>Premenovať súbor na: </translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1488"/>
        <source>Directory does not exist: %1</source>
        <translation>Adresár neexistuje: %1</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1493"/>
        <source>Re-encrypt passwords</source>
        <translation>Znovu zašifrovať heslá</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1494"/>
        <source>Re-encrypt all passwords in %1?

This will re-encrypt ALL password files in this folder using the current recipients defined in .gpg-id.

This may rewrite many files and cannot be undone easily.

Continue?</source>
        <translation>Znovu šifrovať všetky heslá v %1?

To bude znovu šifrovať všetky heslá súbory v tomto priečinku pomocou súčasných príjemcov definované v .gpg-id.

To môže prepísať veľa súborov a nemôže byť ľahko neporušený.

Pokračovať?</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="322"/>
        <source>&lt;p&gt;QtPass is a GUI for &lt;a href=&quot;https://www.passwordstore.org/&quot;&gt;pass&lt;/a&gt;, the standard unix password manager.&lt;/p&gt;
&lt;p&gt;Please report any &lt;a href=&quot;https://github.com/IJHack/qtpass/issues&quot;&gt;issues&lt;/a&gt; you might have with this software.&lt;/p&gt;
&lt;p&gt;&lt;a href=&quot;https://qtpass.org/&quot;&gt;Documentation&lt;/a&gt;&lt;/p&gt;
&lt;p&gt;&lt;a href=&quot;https://github.com/IJHack/qtpass&quot;&gt;SourceCode&lt;/a&gt;&lt;/p&gt;</source>
        <translation>&lt;p&gt;QtPass je uživateľské rozhranie pre &lt;a href=&quot;https://www.passwordstore.org/&quot;&gt;pass&lt;/a&gt;, štandardný správca unixových hesiel.&lt;/p&gt;
&lt;p&gt;Nahláste prosím všetky &lt;a href=&quot;https://github.com/IJHack/qtpass/issues&quot;&gt;problémy&lt;/a&gt;, ktoré by ste mohli mať s týmto softwarom.&lt;/p&gt;
&lt;p&gt;&lt;a href=&quot;https://qtpass.org/&quot;&gt;Dokumentácia&lt;/a&gt;&lt;/p&gt;
&lt;p&gt;&lt;a href=&quot;https://github.com/IJHack/qtpass&quot;&gt;Zdrojový kód&lt;/a&gt;&lt;/p&gt;</translation>
    </message>
</context>
<context>
    <name>Pass</name>
    <message>
        <location filename="../src/pass.cpp" line="142"/>
        <source>Invalid password length</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/pass.cpp" line="143"/>
        <source>Can&apos;t generate password with zero length.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/pass.cpp" line="186"/>
        <source>No characters chosen</source>
        <translation>Žiadne znaky neboli vybrané</translation>
    </message>
    <message>
        <location filename="../src/pass.cpp" line="187"/>
        <source>Can&apos;t generate password, there are no characters to choose from set in the configuration!</source>
        <translation>Nie je možné generovať heslo, v nastaveniach nebola vybraná skladba znakov pre heslo!</translation>
    </message>
    <message>
        <location filename="../src/pass.cpp" line="514"/>
        <location filename="../src/pass.cpp" line="533"/>
        <source>Encryption failed: GPG key has expired. Please renew or replace it.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/pass.cpp" line="519"/>
        <location filename="../src/pass.cpp" line="538"/>
        <source>Encryption failed: GPG key has been revoked.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/pass.cpp" line="523"/>
        <location filename="../src/pass.cpp" line="543"/>
        <source>Encryption failed: recipient GPG key not found or invalid. Check that the key ID in .gpg-id is correct and imported.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/pass.cpp" line="527"/>
        <location filename="../src/pass.cpp" line="547"/>
        <source>Encryption failed. Check that your GPG key is valid.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>PasswordDialog</name>
    <message>
        <location filename="../src/passworddialog.ui" line="14"/>
        <location filename="../src/passworddialog.ui" line="65"/>
        <source>Password</source>
        <translation>Heslo</translation>
    </message>
    <message>
        <location filename="../src/passworddialog.ui" line="75"/>
        <source>Generate</source>
        <translation>Generovať</translation>
    </message>
    <message>
        <location filename="../src/passworddialog.ui" line="86"/>
        <source>Show password</source>
        <translation>Zobraziť heslo</translation>
    </message>
    <message>
        <location filename="../src/passworddialog.ui" line="106"/>
        <source>Character Set:</source>
        <translation>Nastavenie znakov:</translation>
    </message>
    <message>
        <location filename="../src/passworddialog.ui" line="114"/>
        <source>All Characters</source>
        <translation>Všetky znaky</translation>
    </message>
    <message>
        <location filename="../src/passworddialog.ui" line="119"/>
        <source>Alphabetical</source>
        <translation>Abecedné</translation>
    </message>
    <message>
        <location filename="../src/passworddialog.ui" line="124"/>
        <source>Alphanumerical</source>
        <translation>Alfanumerické</translation>
    </message>
    <message>
        <location filename="../src/passworddialog.ui" line="129"/>
        <source>Custom</source>
        <translation>Vlastné</translation>
    </message>
    <message>
        <location filename="../src/passworddialog.ui" line="143"/>
        <source>Length:</source>
        <translation>Dĺžka:</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../main/main.cpp" line="155"/>
        <location filename="../main/main.cpp" line="159"/>
        <source>LTR</source>
        <translation>LTR</translation>
    </message>
</context>
<context>
    <name>QtPass</name>
    <message>
        <location filename="../src/qtpass.cpp" line="160"/>
        <source>Generating GPG key pair</source>
        <translation>Generovanie páru GPG kľúčov</translation>
    </message>
    <message>
        <location filename="../src/qtpass.cpp" line="223"/>
        <source>Failed to connect WebDAV:
</source>
        <translation>Zlyhalo pripojenie k WebDAV:
</translation>
    </message>
    <message>
        <location filename="../src/qtpass.cpp" line="240"/>
        <source>QtPass WebDAV password</source>
        <translation>Heslo k QtPass WebDAV</translation>
    </message>
    <message>
        <location filename="../src/qtpass.cpp" line="241"/>
        <source>Enter password to connect to WebDAV:</source>
        <translation>Vložte heslo pre pripojenie k WebDAV:</translation>
    </message>
    <message>
        <location filename="../src/qtpass.cpp" line="258"/>
        <source>fusedav exited unexpectedly
</source>
        <translation>fusedav neočakávane skončil
</translation>
    </message>
    <message>
        <location filename="../src/qtpass.cpp" line="262"/>
        <source>Failed to start fusedav to connect WebDAV:
</source>
        <translation>Zlyhalo spustenie fusedav pre pripojenie k WebDAV:
</translation>
    </message>
    <message>
        <location filename="../src/qtpass.cpp" line="275"/>
        <source>QProcess::FailedToStart</source>
        <translation>QProcess::FailedToStart</translation>
    </message>
    <message>
        <location filename="../src/qtpass.cpp" line="278"/>
        <source>QProcess::Crashed</source>
        <translation>QProcess::Crashed</translation>
    </message>
    <message>
        <location filename="../src/qtpass.cpp" line="281"/>
        <source>QProcess::Timedout</source>
        <translation>QProcess::Timedout</translation>
    </message>
    <message>
        <location filename="../src/qtpass.cpp" line="284"/>
        <source>QProcess::ReadError</source>
        <translation>QProcess::ReadError</translation>
    </message>
    <message>
        <location filename="../src/qtpass.cpp" line="287"/>
        <source>QProcess::WriteError</source>
        <translation>QProcess::WriteError</translation>
    </message>
    <message>
        <location filename="../src/qtpass.cpp" line="290"/>
        <source>QProcess::UnknownError</source>
        <translation>QProcess::UnknownError</translation>
    </message>
    <message>
        <location filename="../src/qtpass.cpp" line="306"/>
        <source>GPG key pair generation failed</source>
        <translation>Generovanie páru GPG kľúčov zlyhalo</translation>
    </message>
    <message>
        <location filename="../src/qtpass.cpp" line="380"/>
        <source>GPG key pair generated successfully</source>
        <translation>Generovanie páru GPG kľúčov bolo úspešné</translation>
    </message>
    <message>
        <location filename="../src/qtpass.cpp" line="465"/>
        <source>Clipboard cleared</source>
        <translation>Schránka vymazaná</translation>
    </message>
    <message>
        <location filename="../src/qtpass.cpp" line="467"/>
        <source>Clipboard not cleared</source>
        <translation>Schránka nevymazaná</translation>
    </message>
    <message>
        <location filename="../src/qtpass.cpp" line="512"/>
        <source>Copied to clipboard</source>
        <translation>skopírovať do schránky</translation>
    </message>
</context>
<context>
    <name>StoreModel</name>
    <message>
        <source>force overwrite?</source>
        <translation type="vanished">Vynútiť prepísanie?</translation>
    </message>
    <message>
        <location filename="../src/storemodel.cpp" line="411"/>
        <source>Force overwrite?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/storemodel.cpp" line="412"/>
        <source>overwrite %1 with %2?</source>
        <translation>prepísať %1 pomocou %2?</translation>
    </message>
</context>
<context>
    <name>TrayIcon</name>
    <message>
        <location filename="../src/trayicon.cpp" line="67"/>
        <source>&amp;Show</source>
        <translation>Z&amp;obraziť</translation>
    </message>
    <message>
        <location filename="../src/trayicon.cpp" line="69"/>
        <source>&amp;Hide</source>
        <translation>&amp;Skryť</translation>
    </message>
    <message>
        <location filename="../src/trayicon.cpp" line="72"/>
        <source>Mi&amp;nimize</source>
        <translation>Mi&amp;nimalizovať</translation>
    </message>
    <message>
        <location filename="../src/trayicon.cpp" line="75"/>
        <source>Ma&amp;ximize</source>
        <translation>Ma&amp;ximalizovať</translation>
    </message>
    <message>
        <location filename="../src/trayicon.cpp" line="78"/>
        <source>&amp;Restore</source>
        <translation>Obno&amp;viť</translation>
    </message>
    <message>
        <location filename="../src/trayicon.cpp" line="81"/>
        <source>&amp;Quit</source>
        <translation>Ukonči&amp;ť</translation>
    </message>
</context>
<context>
    <name>UsersDialog</name>
    <message>
        <location filename="../src/usersdialog.ui" line="20"/>
        <source>Read access users</source>
        <translation>Uživatelia s právami na čítanie</translation>
    </message>
    <message>
        <location filename="../src/usersdialog.ui" line="45"/>
        <source>Select which users should be able to decrypt passwords stored in this folder.
Note: Existing files will not be modified, and retain the old permissions until you edit them.
Blue entries have a secret key available, select one of these to be able to decrypt.
Black entries have an encryption key available and it is trusted, select one of these to allow other people to decrypt.
Red entries are not valid, you will not be able to encrypt to these.</source>
        <translation>Vyberte, ktorí používatelia by mali byť schopní dešifrovať heslá uložené v tomto priečinku.
Poznámka: Existujúce súbory nebudú upravené a zachovajú si staré oprávnenia, kým ich neupravíte.
Modré položky majú dostupný tajný kľúč, vyberte jednu z nich, aby ste mohli dešifrovať.
Čierne položky majú dostupný šifrovací kľúč a sú dôveryhodné, vyberte jednu z nich, aby mohli dešifrovať aj ostatní.
Červené položky nie sú platné, nebudete môcť na ne šifrovať.</translation>
    </message>
    <message>
        <source>Select which users should be able to decrypt passwords stored in this folder.
Note: Existing files will not be modified, and retain the old permissions until you edit them.
Blue entries have a secret key available, select one of these to be able to decrypt.
Red entries are not valid, you will not be able to encrypt to these.</source>
        <translation type="vanished">Vyberte, ktorí uživatelia majú byť schopní dešifrovať heslá uložené v tomto adresáre.
Poznámka: Existujúce súbory nebudú zmenené a staré oprávnenie ostanú zachované, pokiaľ ich neupravíte.
Modré záznamy majú k dispozícii tajný kľúč. Vyberte jeden z nich, ktorý chcete dešifrovať.
Červené položky nie sú platné, nebudete ich môcť zašifrovať.</translation>
    </message>
    <message>
        <location filename="../src/usersdialog.ui" line="70"/>
        <source>Search for users</source>
        <translation>Hľadať uživateľov</translation>
    </message>
    <message>
        <source>Select which users should be able to decrypt passwords stored in this folder.
Note: Existing files will not be modified and retain the old permissions until you edit them.
Blue entries have a secret key available, select one of these to be able to decrypt.
Red entries are not valid, you will not be able to encrypt to these.</source>
        <translation type="vanished">Select which users should be able to decrypt passwords stored in this folder.
Note: Existing files will not be modified and retain the old permissions until you edit them.
Blue entries have a secret key available, select one of these to be able to decrypt.
Red entries are not valid, you will not be able to encrypt to these.</translation>
    </message>
    <message>
        <source>Search Users</source>
        <translation type="vanished">Search Users</translation>
    </message>
    <message>
        <location filename="../src/usersdialog.ui" line="77"/>
        <source>Show unusable keys</source>
        <translation>Zobraziť nepoužiteľné kľúče</translation>
    </message>
    <message>
        <source>Can not get key list</source>
        <translation type="vanished">Can not get key list</translation>
    </message>
    <message>
        <source>Unable to get list of available gpg keys</source>
        <translation type="vanished">Unable to get list of available gpg keys</translation>
    </message>
    <message>
        <location filename="../src/usersdialog.cpp" line="71"/>
        <source>Keylist missing</source>
        <translation>Chýba zoznam kľúčov</translation>
    </message>
    <message>
        <location filename="../src/usersdialog.cpp" line="72"/>
        <source>Could not fetch list of available GPG keys</source>
        <translation>Nemôžem načítať zoznam dostupných kľúčov GPG</translation>
    </message>
    <message>
        <location filename="../src/usersdialog.cpp" line="148"/>
        <source>Key not found in keyring</source>
        <translation>Kľúč nebol nájdený v kľúčenke</translation>
    </message>
    <message>
        <location filename="../src/usersdialog.cpp" line="301"/>
        <source>created</source>
        <translation>vytvorené</translation>
    </message>
    <message>
        <location filename="../src/usersdialog.cpp" line="305"/>
        <source>expires</source>
        <translation>vyprší</translation>
    </message>
    <message>
        <location filename="../src/usersdialog.cpp" line="328"/>
        <source>[INVALID] </source>
        <translation>[NEPLATNÉ] </translation>
    </message>
    <message>
        <location filename="../src/usersdialog.cpp" line="331"/>
        <source>[EXPIRED] </source>
        <translation>[EXPIROVANÉ] </translation>
    </message>
    <message>
        <location filename="../src/usersdialog.cpp" line="335"/>
        <source>[PARTIAL] </source>
        <translation>[ČÁSTOVÝ] </translation>
    </message>
</context>
</TS>
