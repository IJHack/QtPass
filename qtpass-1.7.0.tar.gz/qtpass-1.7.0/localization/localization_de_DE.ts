<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="de_DE">
<context>
    <name>ConfigDialog</name>
    <message>
        <location filename="../src/configdialog.ui" line="20"/>
        <source>Configuration</source>
        <translation>Einstellungen</translation>
    </message>
    <message>
        <source>gpg</source>
        <translation type="vanished">gpg</translation>
    </message>
    <message>
        <source>git</source>
        <translation type="vanished">git</translation>
    </message>
    <message>
        <location filename="../src/configdialog.ui" line="809"/>
        <source>Pass</source>
        <translation>pass</translation>
    </message>
    <message>
        <source>...</source>
        <translation type="vanished">...</translation>
    </message>
    <message>
        <location filename="../src/configdialog.ui" line="733"/>
        <source>Native</source>
        <translation>Nativ</translation>
    </message>
    <message>
        <location filename="../src/configdialog.ui" line="709"/>
        <source>&amp;Use pass</source>
        <translation>&amp;pass verwenden</translation>
    </message>
    <message>
        <location filename="../src/configdialog.ui" line="512"/>
        <source>Automatically add .gpg-id files</source>
        <translation>.gpg-id Dateien automatisch hinzufügen</translation>
    </message>
    <message>
        <location filename="../src/configdialog.ui" line="115"/>
        <location filename="../src/configdialog.ui" line="198"/>
        <source>Seconds</source>
        <translation>Sekunden</translation>
    </message>
    <message>
        <location filename="../src/configdialog.ui" line="72"/>
        <source>Clipboard behaviour:</source>
        <translation>Verhalten der Zwischenablage:</translation>
    </message>
    <message>
        <location filename="../src/configdialog.ui" line="98"/>
        <source>Autoclear after:</source>
        <translation>Zwischenablage löschen nach:</translation>
    </message>
    <message>
        <source>Password Behaviour:</source>
        <translation type="vanished">Passwort Anzeige:</translation>
    </message>
    <message>
        <location filename="../src/configdialog.ui" line="166"/>
        <source>Hide password</source>
        <translation>Kennwort ausblenden</translation>
    </message>
    <message>
        <location filename="../src/configdialog.ui" line="175"/>
        <source>Autoclear panel after:</source>
        <translation>Anzeigezeit:</translation>
    </message>
    <message>
        <location filename="../src/configdialog.ui" line="224"/>
        <source>Use a monospace font</source>
        <translation>Nichtproportionale Schriftart verwenden</translation>
    </message>
    <message>
        <location filename="../src/configdialog.ui" line="231"/>
        <source>Display the files content as-is</source>
        <translation>Den Inhalt der Dateien so anzeigen, wie er ist</translation>
    </message>
    <message>
        <location filename="../src/configdialog.ui" line="238"/>
        <source>No line wrapping</source>
        <translation>Kein Zeilenumbruch</translation>
    </message>
    <message>
        <location filename="../src/configdialog.ui" line="270"/>
        <source>Password Generation:</source>
        <translatorcomment>Erzeugung würde auch funktionieren</translatorcomment>
        <translation>Passwortgenerierung:</translation>
    </message>
    <message>
        <location filename="../src/configdialog.ui" line="282"/>
        <source>Password Length:</source>
        <translation>Passwortlänge:</translation>
    </message>
    <message>
        <location filename="../src/configdialog.ui" line="344"/>
        <source>Use characters:</source>
        <translation>Verfügbare Zeichen:</translation>
    </message>
    <message>
        <location filename="../src/configdialog.ui" line="362"/>
        <source>Select character set for password generation</source>
        <translation>Zeichensatz für Kennwortgenerator auswählen</translation>
    </message>
    <message>
        <location filename="../src/configdialog.ui" line="366"/>
        <source>All Characters</source>
        <translation>Alle Zeichen</translation>
    </message>
    <message>
        <location filename="../src/configdialog.ui" line="371"/>
        <source>Alphabetical</source>
        <translation>Alphabetisch</translation>
    </message>
    <message>
        <location filename="../src/configdialog.ui" line="376"/>
        <source>Alphanumerical</source>
        <translation>Alphanumerisch</translation>
    </message>
    <message>
        <location filename="../src/configdialog.ui" line="381"/>
        <source>Custom</source>
        <translation>Eigene</translation>
    </message>
    <message>
        <location filename="../src/configdialog.ui" line="443"/>
        <source>Exclude capital letters</source>
        <translation>Großbuchstaben ausschließen</translation>
    </message>
    <message>
        <location filename="../src/configdialog.ui" line="453"/>
        <source>Include special symbols</source>
        <translation>Spezielle Symbole einschließen</translation>
    </message>
    <message>
        <location filename="../src/configdialog.ui" line="460"/>
        <source>Generate easy to memorize but less secure passwords</source>
        <translation>Generiere einfach zu merkende, aber unsichere Kennwörter</translation>
    </message>
    <message>
        <location filename="../src/configdialog.ui" line="467"/>
        <source>Exclude numbers</source>
        <translation>Zahlen ausschließen</translation>
    </message>
    <message>
        <location filename="../src/configdialog.ui" line="486"/>
        <source>Git:</source>
        <translation>Git:</translation>
    </message>
    <message>
        <location filename="../src/configdialog.ui" line="558"/>
        <source>Extensions:</source>
        <translation>Erweiterungen:</translation>
    </message>
    <message>
        <source>Use pass otp extension</source>
        <translation type="vanished">Verwenden Sie die Pass-OTP-Erweiterung</translation>
    </message>
    <message>
        <location filename="../src/configdialog.ui" line="617"/>
        <source>System:</source>
        <translation>System:</translation>
    </message>
    <message>
        <location filename="../src/configdialog.ui" line="693"/>
        <source>Select password storage program:</source>
        <translation>Zu verwendende Programme auswählen:</translation>
    </message>
    <message>
        <source>Nati&amp;ve git/gpg</source>
        <translation type="vanished">Selbst installieres &amp;git/gpg</translation>
    </message>
    <message>
        <location filename="../src/configdialog.ui" line="820"/>
        <source>pass</source>
        <translation>pass</translation>
    </message>
    <message>
        <location filename="../src/configdialog.ui" line="1001"/>
        <source>Current path</source>
        <translation>Aktueller Pfad</translation>
    </message>
    <message>
        <location filename="../src/configdialog.ui" line="1088"/>
        <source>&lt;a href=&quot;https://QtPass.org/&quot;&gt;QtPass&lt;/a&gt; version </source>
        <translation>&lt;a href=&quot;https://QtPass.org/&quot;&gt;QtPass&lt;/a&gt; Version </translation>
    </message>
    <message>
        <location filename="../src/configdialog.ui" line="650"/>
        <source>Always on top</source>
        <translation>Immer im Vordergrund</translation>
    </message>
    <message>
        <source>login
url
email</source>
        <translation type="vanished">login
url
email</translation>
    </message>
    <message>
        <location filename="../src/configdialog.ui" line="675"/>
        <source>Programs</source>
        <translation>Programme</translation>
    </message>
    <message>
        <source>pwgen</source>
        <translation type="vanished">pwgen</translation>
    </message>
    <message>
        <location filename="../src/configdialog.ui" line="46"/>
        <source>Settings</source>
        <translation>Einstellungen</translation>
    </message>
    <message>
        <location filename="../src/configdialog.ui" line="316"/>
        <source>Characters</source>
        <translation>Zeichen</translation>
    </message>
    <message>
        <source>Use pwgen</source>
        <translation type="vanished">pwgen verwenden</translation>
    </message>
    <message>
        <location filename="../src/configdialog.ui" line="629"/>
        <source>Use TrayIcon</source>
        <translation>Im System Tray anzeigen</translation>
    </message>
    <message>
        <location filename="../src/configdialog.ui" line="643"/>
        <source>Hide on close</source>
        <translation>Nur minimieren nicht beenden</translation>
    </message>
    <message>
        <location filename="../src/configdialog.ui" line="519"/>
        <source>Automatically push</source>
        <translation>Automatisches &quot;Push&quot;</translation>
    </message>
    <message>
        <location filename="../src/configdialog.ui" line="526"/>
        <source>Automatically pull</source>
        <translation>Automatisches &quot;Pull&quot;</translation>
    </message>
    <message>
        <source>Use git</source>
        <translation type="vanished">Git verwenden</translation>
    </message>
    <message>
        <source>Include special symbols </source>
        <translation type="vanished">Sonderzeichen zulassen </translation>
    </message>
    <message>
        <location filename="../src/configdialog.ui" line="419"/>
        <source>ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789</source>
        <translation>ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789</translation>
    </message>
    <message>
        <location filename="../src/configdialog.ui" line="91"/>
        <source>Use primary selection</source>
        <translation>Verwenden Sie die primäre Auswahl</translation>
    </message>
    <message>
        <location filename="../src/configdialog.ui" line="147"/>
        <source>Content panel behaviour:</source>
        <translation>Verhalten des Inhaltsbereichs:</translation>
    </message>
    <message>
        <location filename="../src/configdialog.ui" line="636"/>
        <source>Start minimized</source>
        <translation>Minimiert starten</translation>
    </message>
    <message>
        <location filename="../src/configdialog.ui" line="893"/>
        <source>Profiles</source>
        <translation>Profile</translation>
    </message>
    <message>
        <location filename="../src/configdialog.ui" line="942"/>
        <source>Name</source>
        <translation>Name</translation>
    </message>
    <message>
        <location filename="../src/configdialog.ui" line="950"/>
        <source>Path</source>
        <translation>Pfad</translation>
    </message>
    <message>
        <location filename="../src/configdialog.ui" line="971"/>
        <source>Add</source>
        <translation>Hinzufügen</translation>
    </message>
    <message>
        <source>Current password-store</source>
        <translation type="vanished">aktueller Passwort Speicher</translation>
    </message>
    <message>
        <location filename="../src/configdialog.ui" line="1021"/>
        <source>Template</source>
        <translation>Templates</translation>
    </message>
    <message>
        <source>Templates add extra fields in the password generation dialogue and in the password view.</source>
        <translation type="vanished">Ein Template macht weitere Felder bei der Passwort Generierung und Anzeige verfügbar.</translation>
    </message>
    <message>
        <location filename="../src/configdialog.ui" line="1051"/>
        <source>Use template</source>
        <translation>Templates verwenden</translation>
    </message>
    <message>
        <location filename="../src/configdialog.ui" line="1058"/>
        <source>Show all lines beginning with a word followed by a colon as fields in password fields, not only the listed ones</source>
        <translation>Alle Zeilen, die mit einem Wort gefolgt von einem Doppelpunkt anfangen, als Template Element behandeln</translation>
    </message>
    <message>
        <location filename="../src/configdialog.ui" line="1061"/>
        <source>Show all fields templated</source>
        <translation>Alle Felder als Template benutzen</translation>
    </message>
    <message>
        <location filename="../src/configdialog.ui" line="986"/>
        <source>Delete</source>
        <translation>Löschen</translation>
    </message>
    <message>
        <location filename="../src/configdialog.ui" line="159"/>
        <source>Hide content</source>
        <translation>Inhalt ausblenden</translation>
    </message>
    <message>
        <location filename="../src/configdialog.cpp" line="803"/>
        <source>GnuPG not found</source>
        <translation>GnuPG nicht gefunden</translation>
    </message>
    <message>
        <location filename="../src/configdialog.cpp" line="817"/>
        <source>Please install GnuPG on your system.&lt;br&gt;Install &lt;strong&gt;gpg&lt;/strong&gt; using your favorite package manager&lt;br&gt;or &lt;a href=&quot;https://www.gnupg.org/download/#sec-1-2&quot;&gt;download&lt;/a&gt; it from GnuPG.org</source>
        <translation>GnuPG ist nicht installiert. &lt;br&gt;Installiere &lt;strong&gt;gpg&lt;/strong&gt; mit deinem favoriten Paket Manager&lt;br&gt;oder von GnuPG.org &lt;a href=&quot;https://www.gnupg.org/download/#sec-1-2&quot;&gt;herunterladen&lt;/a&gt;</translation>
    </message>
    <message>
        <location filename="../src/configdialog.cpp" line="871"/>
        <source>Create password-store?</source>
        <translation>Kennwortspeicher erstellen?</translation>
    </message>
    <message>
        <location filename="../src/configdialog.cpp" line="872"/>
        <source>Would you like to create a password-store at %1?</source>
        <translation>Soll ein Kennwortspeicher in %1 erstellt werden?</translation>
    </message>
    <message>
        <location filename="../src/configdialog.cpp" line="877"/>
        <source>Error</source>
        <translation>Fehler</translation>
    </message>
    <message>
        <location filename="../src/configdialog.cpp" line="878"/>
        <source>Failed to create password-store at: %1</source>
        <translation>Fehler beim Erstellen des Passwortspeichers unter: %1</translation>
    </message>
    <message>
        <location filename="../src/configdialog.cpp" line="909"/>
        <source>Password store not initialised</source>
        <translation>Kennwortspeicher nicht initialisiert</translation>
    </message>
    <message>
        <location filename="../src/configdialog.cpp" line="910"/>
        <source>The folder %1 doesn&apos;t seem to be a password store or is not yet initialised.</source>
        <translation>Ordner %1 ist kein Kennwortspeicher oder wurde noch nicht initialisiert.</translation>
    </message>
    <message>
        <location filename="../src/configdialog.cpp" line="703"/>
        <source>No profile selected</source>
        <translation>Kein Profil ausgewählt</translation>
    </message>
    <message>
        <location filename="../src/configdialog.cpp" line="124"/>
        <source>No Clipboard</source>
        <translation>Keine Zwischenablage</translation>
    </message>
    <message>
        <location filename="../src/configdialog.cpp" line="125"/>
        <source>Always copy to clipboard</source>
        <translation>Immer in Zwischenablage kopieren</translation>
    </message>
    <message>
        <location filename="../src/configdialog.cpp" line="126"/>
        <source>On-demand copy to clipboard</source>
        <translation>Bei Bedarf in Zwischenablage kopieren</translation>
    </message>
    <message>
        <location filename="../src/configdialog.cpp" line="207"/>
        <location filename="../src/configdialog.cpp" line="223"/>
        <source>This field is required</source>
        <translation>Dieses Feld ist erforderlich</translation>
    </message>
    <message>
        <location filename="../src/configdialog.cpp" line="653"/>
        <source>Select recipients for %1</source>
        <translation>Empfänger für %1 auswählen</translation>
    </message>
    <message>
        <location filename="../src/configdialog.cpp" line="671"/>
        <source>New Profile</source>
        <translation>Neues Profil</translation>
    </message>
    <message>
        <location filename="../src/configdialog.cpp" line="704"/>
        <source>No profile selected to delete</source>
        <translation>Kein Profil zum Löschen ausgewählt</translation>
    </message>
    <message>
        <source>Use qrencode</source>
        <translation type="vanished">Qrencode verwenden</translation>
    </message>
    <message>
        <location filename="../src/configdialog.ui" line="839"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;a href=&quot;https://www.passwordstore.org/&quot;&gt;&lt;span style=&quot; text-decoration: underline;&quot;&gt;www.passwordstore.org&lt;/span&gt;&lt;/a&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;a href=&quot;https://www.passwordstore.org/&quot;&gt;&lt;span style=&quot; text-decoration: underline;&quot;&gt;www.passwordstore.org&lt;/span&gt;&lt;/a&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../src/configdialog.ui" line="870"/>
        <source>Autodetect</source>
        <translation>Automatisch erkennen</translation>
    </message>
    <message>
        <location filename="../src/configdialog.cpp" line="68"/>
        <source>System tray is not available</source>
        <translation>System-tray ist nicht verfügbar</translation>
    </message>
    <message>
        <location filename="../src/configdialog.cpp" line="93"/>
        <source>Pass OTP extension needs to be installed</source>
        <translation>Pass OTP-Erweiterung muss installiert werden</translation>
    </message>
    <message>
        <location filename="../src/configdialog.cpp" line="98"/>
        <source>qrencode needs to be installed</source>
        <translation>qrencode muss installiert werden</translation>
    </message>
    <message>
        <location filename="../src/configdialog.cpp" line="806"/>
        <source>Please install GnuPG on your system.&lt;br&gt;Install &lt;strong&gt;Ubuntu&lt;/strong&gt; from the Microsoft Store to get it.&lt;br&gt;If you already did so, make sure you started it once and&lt;br&gt;click &quot;Autodetect&quot; in the next dialog.</source>
        <translation>Bitte installieren Sie GnuPG auf Ihrem System. &lt;br&gt;Installieren Sie &lt;strong&gt;Ubuntu&lt;/strong&gt; aus dem Microsoft Store, um es zu erhalten. &lt;br&gt;Wenn Sie dies bereits getan haben, stellen Sie sicher, dass Sie es einmal gestartet haben&lt;br&gt;, und klicken Sie im nächsten Dialog auf &quot;Autodetect&quot;.</translation>
    </message>
    <message>
        <location filename="../src/configdialog.cpp" line="811"/>
        <source>Please install GnuPG on your system.&lt;br&gt;Install &lt;strong&gt;Ubuntu&lt;/strong&gt; from the Microsoft Store&lt;br&gt;or &lt;a href=&quot;https://www.gnupg.org/download/#sec-1-2&quot;&gt;download&lt;/a&gt; it from GnuPG.org</source>
        <translation>Bitte installieren Sie GnuPG auf Ihrem System. &lt;br&gt;Installieren Sie &lt;strong&gt;Ubuntu&lt;/strong&gt; aus dem Microsoft Store&lt;br&gt;oder &lt;a href=&quot;https://www.gnupg.org/download/#sec-1-2&quot;&gt;laden&lt;/a&gt; es von GnuPG.org herunter</translation>
    </message>
    <message>
        <location filename="../src/configdialog.ui" line="436"/>
        <source>Use PWGen</source>
        <translation>PWGen verwenden</translation>
    </message>
    <message>
        <location filename="../src/configdialog.ui" line="498"/>
        <source>Use Git</source>
        <translation>Git verwenden</translation>
    </message>
    <message>
        <location filename="../src/configdialog.ui" line="567"/>
        <source>Use QRencode</source>
        <translation>QRencode verwenden</translation>
    </message>
    <message>
        <location filename="../src/configdialog.ui" line="581"/>
        <source>Use pass-otp extension</source>
        <translation>pass-otp Erweiterung verwenden</translation>
    </message>
    <message>
        <location filename="../src/configdialog.ui" line="592"/>
        <source>Enable content search (pass grep)</source>
        <translation>Inhaltssuche aktivieren (pass grep)</translation>
    </message>
    <message>
        <location filename="../src/configdialog.ui" line="595"/>
        <source>Allow searching inside password file contents. Requires decrypting every file and can be slow on large stores.</source>
        <translation>Lassen Sie die Suche innerhalb der Passwortdatei Inhalte. Erfordert die Entschlüsselung jeder Datei und kann auf großen Geschäften langsam sein.</translation>
    </message>
    <message>
        <location filename="../src/configdialog.ui" line="702"/>
        <source>Nati&amp;ve Git/GPG</source>
        <translation>Selbst installieres Git/GPG</translation>
    </message>
    <message>
        <location filename="../src/configdialog.ui" line="739"/>
        <source>Git</source>
        <translation>Git</translation>
    </message>
    <message>
        <location filename="../src/configdialog.ui" line="749"/>
        <location filename="../src/configdialog.ui" line="756"/>
        <location filename="../src/configdialog.ui" line="799"/>
        <location filename="../src/configdialog.ui" line="830"/>
        <location filename="../src/configdialog.ui" line="1008"/>
        <source>…</source>
        <translation>…</translation>
    </message>
    <message>
        <location filename="../src/configdialog.ui" line="769"/>
        <source>Generate</source>
        <translation>Generieren</translation>
    </message>
    <message>
        <location filename="../src/configdialog.ui" line="772"/>
        <source>Generate GPG key pair</source>
        <translation>GPG-Schlüsselpaar generieren</translation>
    </message>
    <message>
        <location filename="../src/configdialog.ui" line="779"/>
        <source>GPG</source>
        <translation>GPG</translation>
    </message>
    <message>
        <location filename="../src/configdialog.ui" line="792"/>
        <source>PWGen</source>
        <translation>PWGen</translation>
    </message>
    <message>
        <location filename="../src/configdialog.ui" line="945"/>
        <source>Profile name, used to identify this configuration profile</source>
        <translation>Profilname, verwendet, um dieses Konfigurationsprofil zu identifizieren</translation>
    </message>
    <message>
        <location filename="../src/configdialog.ui" line="953"/>
        <source>Path to the password store directory</source>
        <translation>Pfad zum Passwortspeicherverzeichnis</translation>
    </message>
    <message>
        <location filename="../src/configdialog.ui" line="958"/>
        <source>Signing Key</source>
        <translation>Signierschlüssel</translation>
    </message>
    <message>
        <location filename="../src/configdialog.ui" line="961"/>
        <source>Optional: GPG key to sign .gpg-id files for integrity verification. Leave empty unless you need to protect the user list from tampering.</source>
        <translation>Optional: GPG-Schlüssel zum Signieren von .gpg-id-Dateien zur Integritätsprüfung. Lassen Sie dieses Feld leer, es sei denn, Sie müssen die Benutzerliste vor Manipulation schützen.</translation>
    </message>
    <message>
        <location filename="../src/configdialog.ui" line="1042"/>
        <source>Templates add extra fields in the password generation dialogue, and in the password view.</source>
        <translation>Vorlagen fügen zusätzliche Felder im Dialog zur Kennwortgenerierung und in der Kennwortansicht hinzu.</translation>
    </message>
    <message>
        <location filename="../src/configdialog.ui" line="1073"/>
        <source>login
URL
e-mail</source>
        <translation>login
URL
e-mail</translation>
    </message>
</context>
<context>
    <name>ImitatePass</name>
    <message>
        <location filename="../src/imitatepass.cpp" line="141"/>
        <location filename="../src/imitatepass.cpp" line="319"/>
        <location filename="../src/imitatepass.cpp" line="505"/>
        <source>Check .gpgid file signature!</source>
        <translation>Überprüfen Sie die .gpgid Dateisignatur!</translation>
    </message>
    <message>
        <location filename="../src/imitatepass.cpp" line="142"/>
        <location filename="../src/imitatepass.cpp" line="320"/>
        <location filename="../src/imitatepass.cpp" line="506"/>
        <source>Signature for %1 is invalid.</source>
        <translation>Unterschrift für %1 ist ungültig.</translation>
    </message>
    <message>
        <location filename="../src/imitatepass.cpp" line="149"/>
        <location filename="../src/imitatepass.cpp" line="598"/>
        <source>Can not edit</source>
        <translation>Ändern nicht möglich</translation>
    </message>
    <message>
        <location filename="../src/imitatepass.cpp" line="150"/>
        <location filename="../src/imitatepass.cpp" line="599"/>
        <source>Could not read encryption key to use, .gpg-id file missing or invalid.</source>
        <translation>Schlüssel nicht lesbar, .gpg-id Datei fehlt oder ist ungültig.</translation>
    </message>
    <message>
        <location filename="../src/imitatepass.cpp" line="314"/>
        <source>GPG signing failed!</source>
        <translation>GPG-Signierung fehlgeschlagen!</translation>
    </message>
    <message>
        <location filename="../src/imitatepass.cpp" line="315"/>
        <source>Failed to sign %1.</source>
        <translation>Signieren von %1 fehlgeschlagen.</translation>
    </message>
    <message>
        <location filename="../src/imitatepass.cpp" line="382"/>
        <source>No signing key!</source>
        <translation>Kein Signaturschlüssel!</translation>
    </message>
    <message>
        <location filename="../src/imitatepass.cpp" line="383"/>
        <source>None of the secret signing keys is available.
You will not be able to change the user list!</source>
        <translation>Keiner der geheimen Signierschlüssel ist verfügbar.
Sie können die Benutzerliste nicht ändern!</translation>
    </message>
    <message>
        <location filename="../src/imitatepass.cpp" line="260"/>
        <source>Cannot update</source>
        <translation>Update nicht möglich</translation>
    </message>
    <message>
        <location filename="../src/imitatepass.cpp" line="261"/>
        <source>Failed to open .gpg-id for writing.</source>
        <translation>Schreibzugriff auf .gpg-id fehlgeschlagen.</translation>
    </message>
    <message>
        <location filename="../src/imitatepass.cpp" line="274"/>
        <source>Check selected users!</source>
        <translation>Ausgewählte Benutzer prüfen!</translation>
    </message>
    <message>
        <location filename="../src/imitatepass.cpp" line="275"/>
        <source>None of the selected keys have a secret key available.
You will not be able to decrypt any newly added passwords!</source>
        <translation>Der Partnerschlüssel der selektierten Schlüssel fehlt.
Hiermit können keine neu hinzugefügefügten Kennwörter entschlüsselt werden!</translation>
    </message>
    <message>
        <location filename="../src/imitatepass.cpp" line="662"/>
        <location filename="../src/imitatepass.cpp" line="769"/>
        <source>Re-encryption failed</source>
        <translation>Die erneute Verschlüsselung ist fehlgeschlagen</translation>
    </message>
    <message>
        <location filename="../src/imitatepass.cpp" line="663"/>
        <source>Failed to replace %1. Original has been restored.</source>
        <translation>%1 konnte nicht ersetzt werden. Das Original wurde wiederhergestellt.</translation>
    </message>
    <message>
        <location filename="../src/imitatepass.cpp" line="692"/>
        <source>Creating backup commit</source>
        <translation>Erstellung eines Backup-Commits</translation>
    </message>
    <message>
        <location filename="../src/imitatepass.cpp" line="698"/>
        <location filename="../src/imitatepass.cpp" line="706"/>
        <source>Backup commit failed</source>
        <translation>Backup-Commit fehlgeschlagen</translation>
    </message>
    <message>
        <location filename="../src/imitatepass.cpp" line="699"/>
        <source>Could not inspect git status. Re-encryption was aborted.</source>
        <translation>Der Git-Status konnte nicht überprüft werden. Die erneute Verschlüsselung wurde abgebrochen.</translation>
    </message>
    <message>
        <location filename="../src/imitatepass.cpp" line="707"/>
        <source>Re-encryption was aborted because a git backup could not be created.</source>
        <translation>Die erneute Verschlüsselung wurde abgebrochen, da kein Git-Backup erstellt werden konnte.</translation>
    </message>
    <message>
        <location filename="../src/imitatepass.cpp" line="729"/>
        <source>Re-encrypting from folder %1</source>
        <translation>Neu-Verschlüsselung aus Ordner %1</translation>
    </message>
    <message>
        <location filename="../src/imitatepass.cpp" line="732"/>
        <location filename="../src/imitatepass.cpp" line="787"/>
        <source>Updating password-store</source>
        <translation>Kennwortspeicher wird aktualisiert</translation>
    </message>
    <message>
        <location filename="../src/imitatepass.cpp" line="757"/>
        <source>GPG ID verification failed</source>
        <translation>GPG-ID-Verifizierung fehlgeschlagen</translation>
    </message>
    <message>
        <location filename="../src/imitatepass.cpp" line="758"/>
        <source>Could not verify .gpg-id for directory.</source>
        <translation>Die .gpg-id für das Verzeichnis konnte nicht verifiziert werden.</translation>
    </message>
    <message>
        <location filename="../src/imitatepass.cpp" line="770"/>
        <source>Failed to re-encrypt %1</source>
        <translation>Fehler beim erneuten Verschlüsseln von %1</translation>
    </message>
    <message>
        <location filename="../src/imitatepass.cpp" line="776"/>
        <source>Re-encryption completed: %1 succeeded, %2 failed</source>
        <translation>Neuverschlüsselung abgeschlossen: %1 erfolgreich, %2 fehlgeschlagen</translation>
    </message>
    <message>
        <location filename="../src/imitatepass.cpp" line="782"/>
        <source>Re-encryption completed: %1 files re-encrypted</source>
        <translation>Neuverschlüsselung abgeschlossen: %1 Dateien neu verschlüsselt</translation>
    </message>
</context>
<context>
    <name>KeygenDialog</name>
    <message>
        <location filename="../src/keygendialog.ui" line="14"/>
        <source>Generate GnuPG keypair</source>
        <translation>GnuPG Schlüssel-Paar generieren</translation>
    </message>
    <message>
        <location filename="../src/keygendialog.ui" line="42"/>
        <source>Generate a new key pair</source>
        <translation>Neues Schlüssel-Paar generieren</translation>
    </message>
    <message>
        <location filename="../src/keygendialog.ui" line="155"/>
        <source>Passphrase</source>
        <translation>Passphrase</translation>
    </message>
    <message>
        <location filename="../src/keygendialog.ui" line="91"/>
        <source>Email</source>
        <translation>E-Mail</translation>
    </message>
    <message>
        <location filename="../src/keygendialog.ui" line="123"/>
        <source>Name</source>
        <translation>Name</translation>
    </message>
    <message>
        <location filename="../src/keygendialog.ui" line="200"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;There is no limit on the length of a passphrase, and it should be carefully chosen. From the perspective of security, the passphrase to unlock the private key is one of the weakest points in GnuPG (and other public-key encryption systems as well) since it is the only protection you have if another individual gets your private key. &lt;br/&gt;Ideally, the passphrase should not use words from a dictionary and should mix the case of alphabetic characters as well as use non-alphabetic characters.&lt;br/&gt;A good passphrase is crucial to the secure use of GnuPG.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head /&gt;&lt;body&gt;&lt;p&gt;Es gibt keine Begrenzung für die Länge einer Passphrase und sie sollte sorgfältig ausgewählt werden. Aus der Sicht der Sicherheit, ist die Passphrase zum Entsperren des privaten Schlüssels einer der schwächsten Punkte in GnuPG (und anderen Public-Key-Verschlüsselungssystemen), da es der einzige Schutz, den Sie haben, wenn eine andere Person Ihren privaten Schlüssel bekommt. &lt;br/&gt; Idealerweise sollte die Passphrase nicht Wörter aus einem Wörterbuch sondern aus Klein- und Großbuchstaben sowie aus nicht-alphabetischen Zeichen bestehen. &lt;br/&gt; Eine gute Passphrase ist entscheidend für die sichere Nutzung von GnuPG. &lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../src/keygendialog.ui" line="210"/>
        <source>Repeat pass</source>
        <translation>Wiederhole Passphrase</translation>
    </message>
    <message>
        <location filename="../src/keygendialog.ui" line="227"/>
        <source>Expert</source>
        <translation>Experte</translation>
    </message>
    <message>
        <location filename="../src/keygendialog.ui" line="246"/>
        <source>Template contents will be set based on GPG version.</source>
        <translation>Der Inhalt der Vorlage wird anhand der GPG-Version festgelegt.</translation>
    </message>
    <message>
        <source>#           QtPass GPG key generator
#
#      first test version please comment
#
%echo Generating a default key
Key-Type: RSA
Subkey-Type: RSA
Name-Real:
Name-Comment: QtPass
Name-Email:
Expire-Date: 0
%no-protection
# Do a commit here, so that we can later print &quot;done&quot; :-)
%commit
%echo done</source>
        <translation type="vanished">#           QtPass GPG key generator
#
#      first test version please comment
#
%echo Generating a default key
Key-Type: RSA
Subkey-Type: RSA
Name-Real:
Name-Comment: QtPass
Name-Email:
Expire-Date: 0
%no-protection
# Do a commit here, so that we can later print &quot;done&quot; :-)
%commit
%echo done</translation>
    </message>
    <message>
        <location filename="../src/keygendialog.ui" line="259"/>
        <source>For expert options check out the &lt;a href=&quot;https://www.gnupg.org/documentation/manuals/gnupg/Unattended-GPG-key-generation.html&quot;&gt;GnuPG manual&lt;/a&gt;</source>
        <translation>Einstellungen für Fortgeschrittene zu finden unter &lt;a href=&quot;https://www.gnupg.org/documentation/manuals/gnupg/Unattended-GPG-key-generation.html&quot;&gt;GnuPG manual&lt;/a&gt;</translation>
    </message>
    <message>
        <location filename="../src/keygendialog.cpp" line="168"/>
        <source>Invalid name</source>
        <translation>Ungültiger Name</translation>
    </message>
    <message>
        <location filename="../src/keygendialog.cpp" line="169"/>
        <source>Name must be at least 5 characters long.</source>
        <translation>Name muss mindestens 5 Zeichen lang sein.</translation>
    </message>
    <message>
        <location filename="../src/keygendialog.cpp" line="180"/>
        <source>Invalid email</source>
        <translation>Ungültige E-Mail</translation>
    </message>
    <message>
        <location filename="../src/keygendialog.cpp" line="181"/>
        <source>The email address you typed is not a valid email address.</source>
        <translation>Die eingegebene E-Mail-Adresse ist keine gültige E-Mail-Adresse.</translation>
    </message>
    <message>
        <location filename="../src/keygendialog.cpp" line="196"/>
        <source>This operation can take some minutes.&lt;br /&gt;We need to generate a lot of random bytes. It is a good idea to perform some other action (type on the keyboard, move the mouse, utilize the disks) during the prime generation; this gives the random number generator a better chance to gain enough entropy.</source>
        <translatorcomment>Google translate FTW</translatorcomment>
        <translation>Dieser Vorgang kann einige Minuten dauern.&lt;br /&gt;Wir müssen eine Menge zufälliger Bytes erzeugen. Es ist hilfreich, während der Primzahlerzeugung andere Aktionen durchzuführen (auf der Tastatur tippen, die Maus bewegen, die Festplatten verwenden); dies gibt dem Zufallszahlengenerator eine bessere Chance, genügend Entropie zu entwicklen.</translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../src/mainwindow.ui" line="14"/>
        <source>QtPass</source>
        <translation>QtPass</translation>
    </message>
    <message>
        <source>Add</source>
        <translation type="vanished">Hinzufügen</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="398"/>
        <location filename="../src/mainwindow.ui" line="401"/>
        <location filename="../src/mainwindow.cpp" line="1199"/>
        <source>Edit</source>
        <translation>Bearbeiten</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="406"/>
        <location filename="../src/mainwindow.ui" line="409"/>
        <location filename="../src/mainwindow.cpp" line="1213"/>
        <source>Delete</source>
        <translation>Löschen</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="425"/>
        <source>Push</source>
        <translation>Hochladen (push)</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="417"/>
        <source>Generate OTP and copy to clipboard</source>
        <translation>Generiere OTP und kopiere in die Zwischenablage</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="127"/>
        <source>Search inside password content (pass grep)</source>
        <translation>Suche innerhalb von Passwort Inhalt (pass grep)</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="130"/>
        <source>⌕</source>
        <translation>⌕</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="133"/>
        <source>Content search toggle</source>
        <translation>Inhaltssuche Umschalter</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="136"/>
        <source>Toggle content search mode to search inside password files</source>
        <translation>Aktivieren Sie den Inhaltssuchmodus, um auch in Passwortdateien zu suchen</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="146"/>
        <source>Case-insensitive search</source>
        <translation>Groß-/Kleinschreibung nicht beachten</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="149"/>
        <source>Aa</source>
        <translation>Aa</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="152"/>
        <source>Case-insensitive toggle</source>
        <translation>Groß-/Kleinschreibung nicht beachten schalten</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="155"/>
        <source>Toggle case-insensitive content search</source>
        <translation>Groß-/Kleinschreibung ignorierende Inhaltssuche umschalten</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="211"/>
        <source>Results</source>
        <translation>Ergebnisse</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="428"/>
        <source>Git push</source>
        <translation>Git push</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="433"/>
        <source>Update</source>
        <translation>Aktualisieren</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="436"/>
        <source>Git pull</source>
        <translation>Git pull</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="444"/>
        <source>Manage who can read password in folder</source>
        <translation>Bestimmen wer Kennwörter im Ordner lesen kann</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="441"/>
        <location filename="../src/mainwindow.cpp" line="1193"/>
        <source>Users</source>
        <translation>Benutzer</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="452"/>
        <source>Configuration</source>
        <translation>Einstellungen</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="449"/>
        <source>Config</source>
        <translation>Einstellungen</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="68"/>
        <source>Select profile</source>
        <translation>Profil auswählen</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="263"/>
        <source>Welcome to QtPass</source>
        <translation>Willkommen bei QtPass</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="120"/>
        <location filename="../src/mainwindow.cpp" line="536"/>
        <location filename="../src/mainwindow.cpp" line="719"/>
        <source>Search Password</source>
        <translation>Kennwort suchen</translation>
    </message>
    <message>
        <source>qtpass</source>
        <translation type="vanished">qtpass</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="340"/>
        <location filename="../src/mainwindow.cpp" line="353"/>
        <source>Updating password-store</source>
        <translation>Kennwortspeicher aktualisieren</translation>
    </message>
    <message>
        <source>Clipboard cleared</source>
        <translation type="vanished">Zwischenablage gelöscht</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="914"/>
        <source>Are you sure you want to delete %1%2?</source>
        <translation>Sind Sie sicher, dass Sie %1%2 löschen möchten?</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="934"/>
        <source>No password selected for OTP generation</source>
        <translation>Für die OTP-Generierung wurde kein Passwort ausgewählt</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1190"/>
        <source>Open folder with file manager</source>
        <translation>Öffnen Sie den Ordner mit dem Dateimanager</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1259"/>
        <source>New Folder: 
(Will be placed in %1 )</source>
        <translation>Neuer Ordner:
(Wird in %1 platziert werden)</translation>
    </message>
    <message>
        <source>Failed to connect WebDAV:
</source>
        <translation type="vanished">Verbindung zu WebDAV fehlgeschlagen:</translation>
    </message>
    <message>
        <source>Add Password</source>
        <translation type="vanished">Passwort Hinzufügen</translation>
    </message>
    <message>
        <source>Add Folder</source>
        <translation type="vanished">Ordner Hinzufügen</translation>
    </message>
    <message>
        <source>QtPass WebDAV password</source>
        <translation type="vanished">QtPass WebDAV Passwort</translation>
    </message>
    <message>
        <source>Enter password to connect to WebDAV:</source>
        <translation type="vanished">Passwort für WebDAV eingeben:</translation>
    </message>
    <message>
        <source>fusedav exited unexpectedly
</source>
        <translation type="vanished">Unerwarteter Abbruch durch fusedav</translation>
    </message>
    <message>
        <source>Failed to start fusedav to connect WebDAV:
</source>
        <translation type="vanished">fusedav konnte nicht gestartet werden, WebDav Verbindung fehlgeschlagen:</translation>
    </message>
    <message>
        <source>Password hidden</source>
        <translation type="vanished">Passwort ausgeblendet</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="461"/>
        <location filename="../src/mainwindow.cpp" line="760"/>
        <source>Content hidden</source>
        <translation>Inhalt ausgeblendet</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="465"/>
        <location filename="../src/mainwindow.cpp" line="1432"/>
        <source>Password</source>
        <translation>Kennwort</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="502"/>
        <source>OTP Code</source>
        <translation>OTP-Code</translation>
    </message>
    <message>
        <source>Clipboard not cleared</source>
        <translation type="vanished">Zwischenablage nicht geleert</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="540"/>
        <source>Password and Content hidden</source>
        <translation>Kennwort und Inhalt ausgeblendet</translation>
    </message>
    <message>
        <source>QProcess::FailedToStart</source>
        <translation type="vanished">QProcess::FailedToStart</translation>
    </message>
    <message>
        <source>QProcess::Crashed</source>
        <translation type="vanished">QProcess::Crashed</translation>
    </message>
    <message>
        <source>QProcess::Timedout</source>
        <translation type="vanished">QProcess::Timedout</translation>
    </message>
    <message>
        <source>QProcess::ReadError</source>
        <translation type="vanished">QProcess::ReadError</translation>
    </message>
    <message>
        <source>QProcess::WriteError</source>
        <translation type="vanished">QProcess::WriteError</translation>
    </message>
    <message>
        <source>QProcess::UnknownError</source>
        <translation type="vanished">QProcess::UnknownError</translation>
    </message>
    <message>
        <source> and whole content</source>
        <translation type="vanished"> und einhalt</translation>
    </message>
    <message>
        <source>Copied to clipboard</source>
        <translation type="vanished">in Zwischenablage kopiert</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="390"/>
        <location filename="../src/mainwindow.ui" line="393"/>
        <location filename="../src/mainwindow.cpp" line="1191"/>
        <source>Add folder</source>
        <translation>Ordner hinzufügen</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="379"/>
        <location filename="../src/mainwindow.ui" line="382"/>
        <location filename="../src/mainwindow.cpp" line="1192"/>
        <source>Add password</source>
        <translation>Kennwort hinzufügen</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="202"/>
        <source>Welcome to QtPass %1</source>
        <translation>Willkommen bei QtPass %1</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="504"/>
        <source>OTP code copied to clipboard</source>
        <translation>OTP-Code in die Zwischenablage kopiert</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="506"/>
        <source>No OTP code found in this password entry</source>
        <translation>In diesem Passworteintrag wurde kein OTP-Code gefunden</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="620"/>
        <source>Looking for: %1</source>
        <translation>Suche nach: %1</translation>
    </message>
    <message>
        <source>Can not edit</source>
        <translation type="vanished">Ändern nicht möglich</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="856"/>
        <location filename="../src/mainwindow.cpp" line="1258"/>
        <source>New file</source>
        <translation>Neue Datei</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="913"/>
        <source>Delete password?</source>
        <translation>Kennwort löschen?</translation>
    </message>
    <message>
        <source>Are you sure you want to delete %1?</source>
        <translation type="vanished">Sind Sie sicher, dass Sie %1 löschen wollen?</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="913"/>
        <source>Delete folder?</source>
        <translation>Ordner löschen?</translation>
    </message>
    <message>
        <source>Selected password file does not exist, not able to edit</source>
        <translation type="vanished">Gewählte Passwort-Datei existiert nicht, Änderung nicht möglich</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="857"/>
        <source>New password file: 
(Will be placed in %1 )</source>
        <translation>Neue Kennwortdatei:
(Wird in %1 platziert werden)</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="894"/>
        <source> and the whole content?</source>
        <translation> und der ganze Inhalt?</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="904"/>
        <source> and the whole content? &lt;br&gt;&lt;strong&gt;Attention: there are unexpected files in the given folder, check them before continue.&lt;/strong&gt;</source>
        <translation> und der gesamte Inhalt? &lt;br&gt;&lt;strong&gt;Achtung: Im angegebenen Ordner befinden sich Dateien, überprüfen Sie diese, bevor Sie fortfahren.&lt;/strong&gt;</translation>
    </message>
    <message>
        <source>Can not get key list</source>
        <translation type="vanished">Schlüssel-Liste nicht gefunden</translation>
    </message>
    <message>
        <source>Unable to get list of available gpg keys</source>
        <translation type="vanished">gpg Schlüssel-Liste konnte nicht gefunden werden</translation>
    </message>
    <message>
        <source>Key not found in keyring</source>
        <translation type="vanished">Schlüssel nicht in Keyring gefunden</translation>
    </message>
    <message>
        <source>Generating GPG key pair</source>
        <translation type="vanished">GPG Schlüssel-Paar wird generiert</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1062"/>
        <source>Profile changed to %1</source>
        <translation>Profil geändert zu %1</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="385"/>
        <source>Ctrl+N</source>
        <translation>Strg+N</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="414"/>
        <source>OTP</source>
        <translation>OTP</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="420"/>
        <source>Ctrl+G</source>
        <translation>Strg+G</translation>
    </message>
    <message>
        <source>git push</source>
        <translation type="vanished">git push</translation>
    </message>
    <message>
        <source>git pull</source>
        <translation type="vanished">git pull</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="670"/>
        <source>Searching…</source>
        <translation>Wird gesucht …</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="701"/>
        <source>Search content (regex)</source>
        <translation>Suchinhalte (regulärer Ausdruck)</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="747"/>
        <source>No matches found.</source>
        <translation>Keine Treffer gefunden.</translation>
    </message>
    <message numerus="yes">
        <location filename="../src/mainwindow.cpp" line="770"/>
        <source>Found %n match(es) in %1 entr(ies).</source>
        <translation>
            <numerusform>%n Treffer in %1 Eintrag gefunden.</numerusform>
            <numerusform>%n Treffer in %1 Einträgen gefunden.</numerusform>
        </translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1205"/>
        <source>Rename folder</source>
        <translation>Ordner umbenennen</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1209"/>
        <source>Rename password</source>
        <translation>Kennwort umbenennen</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1218"/>
        <source>Re-encrypt</source>
        <translation>Erneut verschlüsseln</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1269"/>
        <location filename="../src/mainwindow.cpp" line="1278"/>
        <location filename="../src/mainwindow.cpp" line="1487"/>
        <source>Error</source>
        <translation>Fehler</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1270"/>
        <source>Failed to create folder: %1</source>
        <translation>Ordner konnte nicht erstellt werden: %1</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1279"/>
        <source>Failed to create .gpg-id file in: %1</source>
        <translation>Fehler beim Erstellen der .gpg-id-Datei in: %1</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1301"/>
        <location filename="../src/mainwindow.cpp" line="1337"/>
        <source>Rename file</source>
        <translation>Datei umbenennen</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1301"/>
        <source>Rename Folder To: </source>
        <translation>Ordner umbenennen in: </translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1337"/>
        <source>Rename File To: </source>
        <translation>Datei umbenennen in: </translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1488"/>
        <source>Directory does not exist: %1</source>
        <translation>Verzeichnis existiert nicht: %1</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1493"/>
        <source>Re-encrypt passwords</source>
        <translation>Passwörter neu verschlüsseln</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1494"/>
        <source>Re-encrypt all passwords in %1?

This will re-encrypt ALL password files in this folder using the current recipients defined in .gpg-id.

This may rewrite many files and cannot be undone easily.

Continue?</source>
        <translation>Alle Passwörter in %1 neu verschlüsseln?

Dadurch werden ALLE Passwortdateien in diesem Ordner mit den in der Datei .gpg-id definierten Empfängern neu verschlüsselt.

Dies kann dazu führen, dass viele Dateien überschrieben werden und lässt sich nicht ohne Weiteres rückgängig machen.

Fortfahren?</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="322"/>
        <source>&lt;p&gt;QtPass is a GUI for &lt;a href=&quot;https://www.passwordstore.org/&quot;&gt;pass&lt;/a&gt;, the standard unix password manager.&lt;/p&gt;
&lt;p&gt;Please report any &lt;a href=&quot;https://github.com/IJHack/qtpass/issues&quot;&gt;issues&lt;/a&gt; you might have with this software.&lt;/p&gt;
&lt;p&gt;&lt;a href=&quot;https://qtpass.org/&quot;&gt;Documentation&lt;/a&gt;&lt;/p&gt;
&lt;p&gt;&lt;a href=&quot;https://github.com/IJHack/qtpass&quot;&gt;SourceCode&lt;/a&gt;&lt;/p&gt;</source>
        <translation>&lt;p&gt;QtPass ist eine GUI für &lt;a href=&quot;https://www.passwordstore.org/&quot;&gt;pass&lt;/a&gt;, den Standard Unix Kennwortmanager.&lt;/p&gt;
&lt;p&gt;Bitte melden Sie alle &lt;a href=&quot;https://github.com/IJHack/qtpass/issues&quot;&gt;Probleme&lt;/a&gt;, die Sie mit dieser Software haben könnten.&lt;/p&gt;
&lt;p&gt;&lt;a href=&quot;https://qtpass.org/&quot;&gt;Dokumentation&lt;/a&gt;&lt;/p&gt;
&lt;p&gt;&lt;a href=&quot;https://github.com/IJHack/qtpass&quot;&gt;Quellcode&lt;/a&gt;&lt;/p&gt;</translation>
    </message>
</context>
<context>
    <name>Pass</name>
    <message>
        <location filename="../src/pass.cpp" line="142"/>
        <source>Invalid password length</source>
        <translation>Ungültige Passwortlänge</translation>
    </message>
    <message>
        <location filename="../src/pass.cpp" line="143"/>
        <source>Can&apos;t generate password with zero length.</source>
        <translation>Es kann kein Passwort mit der Länge Null generiert werden.</translation>
    </message>
    <message>
        <location filename="../src/pass.cpp" line="186"/>
        <source>No characters chosen</source>
        <translation>Keine Zeichen ausgewählt</translation>
    </message>
    <message>
        <location filename="../src/pass.cpp" line="187"/>
        <source>Can&apos;t generate password, there are no characters to choose from set in the configuration!</source>
        <translation>Kennwortgenerierung nicht möglich: Keine Zeichen zur Generierung ausgewählt!</translation>
    </message>
    <message>
        <location filename="../src/pass.cpp" line="514"/>
        <location filename="../src/pass.cpp" line="533"/>
        <source>Encryption failed: GPG key has expired. Please renew or replace it.</source>
        <translation>Verschlüsselung fehlgeschlagen: Der GPG-Schlüssel ist abgelaufen. Bitte erneuern oder ersetzen Sie ihn.</translation>
    </message>
    <message>
        <location filename="../src/pass.cpp" line="519"/>
        <location filename="../src/pass.cpp" line="538"/>
        <source>Encryption failed: GPG key has been revoked.</source>
        <translation>Verschlüsselung versagt: GPG-Schlüssel wurde aufgehoben.</translation>
    </message>
    <message>
        <location filename="../src/pass.cpp" line="523"/>
        <location filename="../src/pass.cpp" line="543"/>
        <source>Encryption failed: recipient GPG key not found or invalid. Check that the key ID in .gpg-id is correct and imported.</source>
        <translation>Verschlüsselung versagt: Empfänger GPG-Schlüssel nicht gefunden oder ungültig. Überprüfen Sie, ob die Schlüssel-ID in .gpg-id korrekt und importiert ist.</translation>
    </message>
    <message>
        <location filename="../src/pass.cpp" line="527"/>
        <location filename="../src/pass.cpp" line="547"/>
        <source>Encryption failed. Check that your GPG key is valid.</source>
        <translation>Verschlüsselung versagt. Überprüfen Sie, ob Ihr GPG-Schlüssel gültig ist.</translation>
    </message>
</context>
<context>
    <name>PasswordDialog</name>
    <message>
        <location filename="../src/passworddialog.ui" line="14"/>
        <location filename="../src/passworddialog.ui" line="65"/>
        <source>Password</source>
        <translation>Kennwort</translation>
    </message>
    <message>
        <location filename="../src/passworddialog.ui" line="75"/>
        <source>Generate</source>
        <translation>Generieren</translation>
    </message>
    <message>
        <location filename="../src/passworddialog.ui" line="86"/>
        <source>Show password</source>
        <translation>Kennwort anzeigen</translation>
    </message>
    <message>
        <location filename="../src/passworddialog.ui" line="106"/>
        <source>Character Set:</source>
        <translation>Zeichensatz:</translation>
    </message>
    <message>
        <location filename="../src/passworddialog.ui" line="114"/>
        <source>All Characters</source>
        <translation>Alle Zeichen</translation>
    </message>
    <message>
        <location filename="../src/passworddialog.ui" line="119"/>
        <source>Alphabetical</source>
        <translation>Alphabetisch</translation>
    </message>
    <message>
        <location filename="../src/passworddialog.ui" line="124"/>
        <source>Alphanumerical</source>
        <translation>Alphanumerisch</translation>
    </message>
    <message>
        <location filename="../src/passworddialog.ui" line="129"/>
        <source>Custom</source>
        <translation>Eigene</translation>
    </message>
    <message>
        <location filename="../src/passworddialog.ui" line="143"/>
        <source>Length:</source>
        <translation>Länge:</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../main/main.cpp" line="155"/>
        <location filename="../main/main.cpp" line="159"/>
        <source>LTR</source>
        <translation>LTR</translation>
    </message>
</context>
<context>
    <name>QtPass</name>
    <message>
        <location filename="../src/qtpass.cpp" line="160"/>
        <source>Generating GPG key pair</source>
        <translation>GPG Schlüssel-Paar wird generiert</translation>
    </message>
    <message>
        <location filename="../src/qtpass.cpp" line="223"/>
        <source>Failed to connect WebDAV:
</source>
        <translation>Verbindung zu WebDAV fehlgeschlagen:
</translation>
    </message>
    <message>
        <location filename="../src/qtpass.cpp" line="240"/>
        <source>QtPass WebDAV password</source>
        <translation>Kennwort für QtPass-WebDAV</translation>
    </message>
    <message>
        <location filename="../src/qtpass.cpp" line="241"/>
        <source>Enter password to connect to WebDAV:</source>
        <translation>Kennwort für WebDAV eingeben:</translation>
    </message>
    <message>
        <location filename="../src/qtpass.cpp" line="258"/>
        <source>fusedav exited unexpectedly
</source>
        <translation>Unerwarteter Abbruch durch fusedav
</translation>
    </message>
    <message>
        <location filename="../src/qtpass.cpp" line="262"/>
        <source>Failed to start fusedav to connect WebDAV:
</source>
        <translation>fusedav konnte nicht gestartet werden, WebDav Verbindung fehlgeschlagen:
</translation>
    </message>
    <message>
        <location filename="../src/qtpass.cpp" line="275"/>
        <source>QProcess::FailedToStart</source>
        <translation>QProcess::FailedToStart</translation>
    </message>
    <message>
        <location filename="../src/qtpass.cpp" line="278"/>
        <source>QProcess::Crashed</source>
        <translation>QProcess::Crashed</translation>
    </message>
    <message>
        <location filename="../src/qtpass.cpp" line="281"/>
        <source>QProcess::Timedout</source>
        <translation>QProcess::Timedout</translation>
    </message>
    <message>
        <location filename="../src/qtpass.cpp" line="284"/>
        <source>QProcess::ReadError</source>
        <translation>QProcess::ReadError</translation>
    </message>
    <message>
        <location filename="../src/qtpass.cpp" line="287"/>
        <source>QProcess::WriteError</source>
        <translation>QProcess::WriteError</translation>
    </message>
    <message>
        <location filename="../src/qtpass.cpp" line="290"/>
        <source>QProcess::UnknownError</source>
        <translation>QProcess::UnknownError</translation>
    </message>
    <message>
        <location filename="../src/qtpass.cpp" line="306"/>
        <source>GPG key pair generation failed</source>
        <translation>Die Generierung des GPG-Schlüsselpaares ist fehlgeschlagen</translation>
    </message>
    <message>
        <location filename="../src/qtpass.cpp" line="380"/>
        <source>GPG key pair generated successfully</source>
        <translation>GPG-Schlüsselpaar erfolgreich generiert</translation>
    </message>
    <message>
        <location filename="../src/qtpass.cpp" line="465"/>
        <source>Clipboard cleared</source>
        <translation>Zwischenablage gelöscht</translation>
    </message>
    <message>
        <location filename="../src/qtpass.cpp" line="467"/>
        <source>Clipboard not cleared</source>
        <translation>Zwischenablage nicht geleert</translation>
    </message>
    <message>
        <location filename="../src/qtpass.cpp" line="512"/>
        <source>Copied to clipboard</source>
        <translation>in Zwischenablage kopiert</translation>
    </message>
</context>
<context>
    <name>StoreModel</name>
    <message>
        <source>force overwrite?</source>
        <translation type="vanished">Überschreiben erzwingen?</translation>
    </message>
    <message>
        <location filename="../src/storemodel.cpp" line="411"/>
        <source>Force overwrite?</source>
        <translation>Überschreiben erzwingen?</translation>
    </message>
    <message>
        <location filename="../src/storemodel.cpp" line="412"/>
        <source>overwrite %1 with %2?</source>
        <translation>Überschreiben %1 mit %2?</translation>
    </message>
</context>
<context>
    <name>TrayIcon</name>
    <message>
        <location filename="../src/trayicon.cpp" line="67"/>
        <source>&amp;Show</source>
        <translation>&amp;Anzeigen</translation>
    </message>
    <message>
        <location filename="../src/trayicon.cpp" line="69"/>
        <source>&amp;Hide</source>
        <translation>&amp;Verstecken</translation>
    </message>
    <message>
        <location filename="../src/trayicon.cpp" line="72"/>
        <source>Mi&amp;nimize</source>
        <translation>M&amp;inimieren</translation>
    </message>
    <message>
        <location filename="../src/trayicon.cpp" line="75"/>
        <source>Ma&amp;ximize</source>
        <translation>M&amp;aximieren</translation>
    </message>
    <message>
        <location filename="../src/trayicon.cpp" line="78"/>
        <source>&amp;Restore</source>
        <translation>&amp;Wiederherstellen</translation>
    </message>
    <message>
        <location filename="../src/trayicon.cpp" line="81"/>
        <source>&amp;Quit</source>
        <translation>&amp;Schließen</translation>
    </message>
</context>
<context>
    <name>UsersDialog</name>
    <message>
        <location filename="../src/usersdialog.ui" line="20"/>
        <source>Read access users</source>
        <translation>Benutzer mit Lese-Zugriff</translation>
    </message>
    <message>
        <location filename="../src/usersdialog.ui" line="45"/>
        <source>Select which users should be able to decrypt passwords stored in this folder.
Note: Existing files will not be modified, and retain the old permissions until you edit them.
Blue entries have a secret key available, select one of these to be able to decrypt.
Black entries have an encryption key available and it is trusted, select one of these to allow other people to decrypt.
Red entries are not valid, you will not be able to encrypt to these.</source>
        <translation>Wählen Sie aus, welche Benutzer die in diesem Ordner gespeicherten Passwörter entschlüsseln dürfen.
Hinweis: Vorhandene Dateien bleiben unverändert und behalten ihre alten Berechtigungen, bis Sie sie bearbeiten.
Blaue Einträge enthalten einen geheimen Schlüssel. Wählen Sie einen dieser Einträge aus, um die Entschlüsselung zu ermöglichen.
Schwarze Einträge enthalten einen vertrauenswürdigen Verschlüsselungsschlüssel. Wählen Sie einen dieser Einträge aus, um anderen Benutzern die Entschlüsselung zu erlauben.
Rote Einträge sind ungültig; Sie können mit diesen Einträgen keine Passwörter verschlüsseln.</translation>
    </message>
    <message>
        <source>Select which users should be able to decrypt passwords stored in this folder.
Note: Existing files will not be modified, and retain the old permissions until you edit them.
Blue entries have a secret key available, select one of these to be able to decrypt.
Red entries are not valid, you will not be able to encrypt to these.</source>
        <translation type="vanished">Wählen Sie aus, welche Benutzer die in diesem Ordner gespeicherten Kennwörter entschlüsseln können sollen.
Hinweis: Vorhandene Dateien werden nicht geändert und behalten die alten Berechtigungen bei, bis Sie sie bearbeiten.
Blaue Einträge haben einen geheimen Schlüssel zur Verfügung, wählen Sie einen aus, um ihn zu entschlüsseln.
Rote Einträge sind ungültig, Sie können diese nicht verschlüsseln.</translation>
    </message>
    <message>
        <location filename="../src/usersdialog.ui" line="70"/>
        <source>Search for users</source>
        <translation>Suche nach Benutzern</translation>
    </message>
    <message>
        <source>Select which users should be able to decrypt passwords stored in this folder.
Note: Existing files will not be modified and retain the old permissions until you edit them.
Blue entries have a secret key available, select one of these to be able to decrypt.
Red entries are not valid, you will not be able to encrypt to these.</source>
        <translation type="vanished">Hier die Benutzer eintragen denen Entschlüsselungszugriff für Passwörter in diesem Ordner gewährt werden soll.
Hinweis: Nachträglich hinzugefügte Nutzer müssen durch erneutes editieren des Passwort Speichers aktualisiert werden.
Die blauen Einträgen verfügen über einen gültigen Schlüssel. Zum entschlüsseln auswählen.
Die roten Einträge sind ungültig / abgelaufen und für Entschlüsselung nicht wählbar.</translation>
    </message>
    <message>
        <source>Search Users</source>
        <translation type="vanished">Benutzer suchen</translation>
    </message>
    <message>
        <location filename="../src/usersdialog.ui" line="77"/>
        <source>Show unusable keys</source>
        <translation>unbrauchbare Schlüssel anzeigen</translation>
    </message>
    <message>
        <source>Can not get key list</source>
        <translation type="vanished">Schlüssel-Liste nicht gefunden</translation>
    </message>
    <message>
        <source>Unable to get list of available gpg keys</source>
        <translation type="vanished">gpg Schlüssel-Liste konnte nicht gefunden werden</translation>
    </message>
    <message>
        <location filename="../src/usersdialog.cpp" line="71"/>
        <source>Keylist missing</source>
        <translation>Schlüsselliste fehlt</translation>
    </message>
    <message>
        <location filename="../src/usersdialog.cpp" line="72"/>
        <source>Could not fetch list of available GPG keys</source>
        <translation>Liste der verfügbaren GPG-Schlüssel konnte nicht abgerufen werden</translation>
    </message>
    <message>
        <location filename="../src/usersdialog.cpp" line="148"/>
        <source>Key not found in keyring</source>
        <translation>Schlüssel nicht in Keyring gefunden</translation>
    </message>
    <message>
        <location filename="../src/usersdialog.cpp" line="301"/>
        <source>created</source>
        <translation>erstellt</translation>
    </message>
    <message>
        <location filename="../src/usersdialog.cpp" line="305"/>
        <source>expires</source>
        <translation>gültig bis</translation>
    </message>
    <message>
        <location filename="../src/usersdialog.cpp" line="328"/>
        <source>[INVALID] </source>
        <translation>[UNGÜLTIG] </translation>
    </message>
    <message>
        <location filename="../src/usersdialog.cpp" line="331"/>
        <source>[EXPIRED] </source>
        <translation>[ABGELAUFEN] </translation>
    </message>
    <message>
        <location filename="../src/usersdialog.cpp" line="335"/>
        <source>[PARTIAL] </source>
        <translation>[TEILWEISE] </translation>
    </message>
</context>
</TS>
