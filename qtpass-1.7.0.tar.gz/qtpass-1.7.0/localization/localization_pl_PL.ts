<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="pl_PL">
<context>
    <name>ConfigDialog</name>
    <message>
        <location filename="../src/configdialog.ui" line="20"/>
        <source>Configuration</source>
        <translation>Konfiguracja</translation>
    </message>
    <message>
        <location filename="../src/configdialog.ui" line="46"/>
        <source>Settings</source>
        <translation>Opcje</translation>
    </message>
    <message>
        <location filename="../src/configdialog.ui" line="72"/>
        <source>Clipboard behaviour:</source>
        <translation>Zachowanie schowka:</translation>
    </message>
    <message>
        <location filename="../src/configdialog.ui" line="91"/>
        <source>Use primary selection</source>
        <translation>Użyj wyboru podstawowego</translation>
    </message>
    <message>
        <location filename="../src/configdialog.ui" line="98"/>
        <source>Autoclear after:</source>
        <translation>Automatyczne czyszczenie po:</translation>
    </message>
    <message>
        <location filename="../src/configdialog.ui" line="115"/>
        <location filename="../src/configdialog.ui" line="198"/>
        <source>Seconds</source>
        <translation>Sekundy</translation>
    </message>
    <message>
        <location filename="../src/configdialog.ui" line="147"/>
        <source>Content panel behaviour:</source>
        <translation>Zachowanie panelu zawartości:</translation>
    </message>
    <message>
        <location filename="../src/configdialog.ui" line="159"/>
        <source>Hide content</source>
        <translation>Schowaj zawartość</translation>
    </message>
    <message>
        <location filename="../src/configdialog.ui" line="166"/>
        <source>Hide password</source>
        <translation>Ukryj hasło</translation>
    </message>
    <message>
        <location filename="../src/configdialog.ui" line="175"/>
        <source>Autoclear panel after:</source>
        <translation>Automatycznie wyczyść panel po:</translation>
    </message>
    <message>
        <location filename="../src/configdialog.ui" line="270"/>
        <source>Password Generation:</source>
        <translation>Generowanie hasła:</translation>
    </message>
    <message>
        <location filename="../src/configdialog.ui" line="282"/>
        <source>Password Length:</source>
        <translation>Długość hasła:</translation>
    </message>
    <message>
        <location filename="../src/configdialog.ui" line="316"/>
        <source>Characters</source>
        <translation>Znaki</translation>
    </message>
    <message>
        <location filename="../src/configdialog.ui" line="344"/>
        <source>Use characters:</source>
        <translation>Użyj znaków:</translation>
    </message>
    <message>
        <location filename="../src/configdialog.ui" line="362"/>
        <source>Select character set for password generation</source>
        <translation>Wybierz zestaw znaków do generowania hasła</translation>
    </message>
    <message>
        <location filename="../src/configdialog.ui" line="366"/>
        <source>All Characters</source>
        <translation>Wszystkie znaki</translation>
    </message>
    <message>
        <location filename="../src/configdialog.ui" line="371"/>
        <source>Alphabetical</source>
        <translation>Alfabetycznie</translation>
    </message>
    <message>
        <location filename="../src/configdialog.ui" line="376"/>
        <source>Alphanumerical</source>
        <translation>Alfanumerycznie</translation>
    </message>
    <message>
        <location filename="../src/configdialog.ui" line="381"/>
        <source>Custom</source>
        <translation>Niestandardowe</translation>
    </message>
    <message>
        <location filename="../src/configdialog.ui" line="419"/>
        <source>ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789</source>
        <translation>ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789</translation>
    </message>
    <message>
        <location filename="../src/configdialog.ui" line="453"/>
        <source>Include special symbols</source>
        <translation>Uwzględnij symbole specjalne</translation>
    </message>
    <message>
        <location filename="../src/configdialog.ui" line="1001"/>
        <source>Current path</source>
        <translation>Obecna ścieżka</translation>
    </message>
    <message>
        <location filename="../src/configdialog.ui" line="443"/>
        <source>Exclude capital letters</source>
        <translation>Wyklucz wielkie litery</translation>
    </message>
    <message>
        <location filename="../src/configdialog.ui" line="224"/>
        <source>Use a monospace font</source>
        <translation>Użyj czcionki o stałej szerokości znaków</translation>
    </message>
    <message>
        <location filename="../src/configdialog.ui" line="231"/>
        <source>Display the files content as-is</source>
        <translation>Wyświetl zawartość pliku</translation>
    </message>
    <message>
        <location filename="../src/configdialog.ui" line="238"/>
        <source>No line wrapping</source>
        <translation>Nie zawijaj linii</translation>
    </message>
    <message>
        <location filename="../src/configdialog.ui" line="460"/>
        <source>Generate easy to memorize but less secure passwords</source>
        <translation>Generuj łatwe do zapamiętania, lecz mniej bezpieczne hasła</translation>
    </message>
    <message>
        <location filename="../src/configdialog.ui" line="467"/>
        <source>Exclude numbers</source>
        <translation>Z wyłączeniem liczb</translation>
    </message>
    <message>
        <location filename="../src/configdialog.ui" line="486"/>
        <source>Git:</source>
        <translation>Git:</translation>
    </message>
    <message>
        <location filename="../src/configdialog.ui" line="512"/>
        <source>Automatically add .gpg-id files</source>
        <translation>Automatycznie dodaj pliki .gpg-id</translation>
    </message>
    <message>
        <location filename="../src/configdialog.ui" line="519"/>
        <source>Automatically push</source>
        <translation>Automatyczne „push”</translation>
    </message>
    <message>
        <location filename="../src/configdialog.ui" line="526"/>
        <source>Automatically pull</source>
        <translation>Automatyczne „pull”</translation>
    </message>
    <message>
        <location filename="../src/configdialog.ui" line="558"/>
        <source>Extensions:</source>
        <translation>Rozszerzenia:</translation>
    </message>
    <message>
        <location filename="../src/configdialog.ui" line="592"/>
        <source>Enable content search (pass grep)</source>
        <translation>Włącz wyszukiwanie zawartości (pass grep)</translation>
    </message>
    <message>
        <location filename="../src/configdialog.ui" line="595"/>
        <source>Allow searching inside password file contents. Requires decrypting every file and can be slow on large stores.</source>
        <translation>Zezwalaj na przeszukiwanie zawartości plików z hasłami. Wymaga odszyfrowania każdego pliku i może być powolne w przypadku dużych baz danych.</translation>
    </message>
    <message>
        <location filename="../src/configdialog.ui" line="617"/>
        <source>System:</source>
        <translation>System:</translation>
    </message>
    <message>
        <location filename="../src/configdialog.ui" line="629"/>
        <source>Use TrayIcon</source>
        <translation>Użyj ikony w zasobniku systemowym</translation>
    </message>
    <message>
        <location filename="../src/configdialog.ui" line="636"/>
        <source>Start minimized</source>
        <translation>Uruchom zminimalizowany</translation>
    </message>
    <message>
        <location filename="../src/configdialog.ui" line="643"/>
        <source>Hide on close</source>
        <translation>Ukryj przy zamknięciu</translation>
    </message>
    <message>
        <location filename="../src/configdialog.ui" line="650"/>
        <source>Always on top</source>
        <translation>Zawsze na wierzchu</translation>
    </message>
    <message>
        <location filename="../src/configdialog.ui" line="675"/>
        <source>Programs</source>
        <translation>Programy</translation>
    </message>
    <message>
        <location filename="../src/configdialog.ui" line="693"/>
        <source>Select password storage program:</source>
        <translation>Wybierz program do przechowywania haseł:</translation>
    </message>
    <message>
        <location filename="../src/configdialog.ui" line="709"/>
        <source>&amp;Use pass</source>
        <translation>&amp;Użyj pass</translation>
    </message>
    <message>
        <location filename="../src/configdialog.ui" line="733"/>
        <source>Native</source>
        <translation>Natywny</translation>
    </message>
    <message>
        <location filename="../src/configdialog.ui" line="769"/>
        <source>Generate</source>
        <translation>Wygeneruj</translation>
    </message>
    <message>
        <location filename="../src/configdialog.ui" line="772"/>
        <source>Generate GPG key pair</source>
        <translation>Wygeneruj parę kluczy GPG</translation>
    </message>
    <message>
        <location filename="../src/configdialog.ui" line="809"/>
        <source>Pass</source>
        <translation>Pass</translation>
    </message>
    <message>
        <location filename="../src/configdialog.ui" line="820"/>
        <source>pass</source>
        <translation>pass</translation>
    </message>
    <message>
        <location filename="../src/configdialog.ui" line="839"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;a href=&quot;https://www.passwordstore.org/&quot;&gt;&lt;span style=&quot; text-decoration: underline;&quot;&gt;www.passwordstore.org&lt;/span&gt;&lt;/a&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;a href=&quot;https://www.passwordstore.org/&quot;&gt;&lt;span style=&quot; text-decoration: underline;&quot;&gt;www.passwordstore.org&lt;/span&gt;&lt;/a&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../src/configdialog.ui" line="870"/>
        <source>Autodetect</source>
        <translation>Automatycznie wykryj</translation>
    </message>
    <message>
        <location filename="../src/configdialog.ui" line="893"/>
        <source>Profiles</source>
        <translation>Profile</translation>
    </message>
    <message>
        <location filename="../src/configdialog.ui" line="942"/>
        <source>Name</source>
        <translation>Nazwa</translation>
    </message>
    <message>
        <location filename="../src/configdialog.ui" line="945"/>
        <source>Profile name, used to identify this configuration profile</source>
        <translation>Nazwa profilu służąca do identyfikacji tego profilu konfiguracji</translation>
    </message>
    <message>
        <location filename="../src/configdialog.ui" line="950"/>
        <source>Path</source>
        <translation>Ścieżka</translation>
    </message>
    <message>
        <location filename="../src/configdialog.ui" line="953"/>
        <source>Path to the password store directory</source>
        <translation>Ścieżka do katalogu przechowującego hasła</translation>
    </message>
    <message>
        <location filename="../src/configdialog.ui" line="958"/>
        <source>Signing Key</source>
        <translation>Klucz podpisujący</translation>
    </message>
    <message>
        <location filename="../src/configdialog.ui" line="961"/>
        <source>Optional: GPG key to sign .gpg-id files for integrity verification. Leave empty unless you need to protect the user list from tampering.</source>
        <translation>Opcjonalnie: klucz GPG do podpisywania plików .gpg-id w celu weryfikacji integralności. Pozostaw puste, chyba że chcesz chronić listę użytkowników przed manipulacją.</translation>
    </message>
    <message>
        <location filename="../src/configdialog.ui" line="971"/>
        <source>Add</source>
        <translation>Dodaj</translation>
    </message>
    <message>
        <location filename="../src/configdialog.ui" line="986"/>
        <source>Delete</source>
        <translation>Usuń</translation>
    </message>
    <message>
        <location filename="../src/configdialog.ui" line="1021"/>
        <source>Template</source>
        <translation>Szablon</translation>
    </message>
    <message>
        <location filename="../src/configdialog.ui" line="1051"/>
        <source>Use template</source>
        <translation>Użyj szablonu</translation>
    </message>
    <message>
        <location filename="../src/configdialog.ui" line="1058"/>
        <source>Show all lines beginning with a word followed by a colon as fields in password fields, not only the listed ones</source>
        <translation>Pokaż wszystkie linie zaczynające się słowem i kończące dwukropkiem jako pola w polach haseł, zamiast listy</translation>
    </message>
    <message>
        <location filename="../src/configdialog.ui" line="1061"/>
        <source>Show all fields templated</source>
        <translation>Pokaż wszystkie pola z szablonu</translation>
    </message>
    <message>
        <location filename="../src/configdialog.ui" line="1088"/>
        <source>&lt;a href=&quot;https://QtPass.org/&quot;&gt;QtPass&lt;/a&gt; version </source>
        <translation>Wersja &lt;a href=&quot;https://QtPass.org/&quot;&gt;QtPass&lt;/a&gt; </translation>
    </message>
    <message>
        <location filename="../src/configdialog.cpp" line="68"/>
        <source>System tray is not available</source>
        <translation>Tacka systemowa nie jest dostępna</translation>
    </message>
    <message>
        <location filename="../src/configdialog.cpp" line="93"/>
        <source>Pass OTP extension needs to be installed</source>
        <translation>Rozszerzenie OTP musi być zainstalowane</translation>
    </message>
    <message>
        <location filename="../src/configdialog.cpp" line="98"/>
        <source>qrencode needs to be installed</source>
        <translation>qrencode musi być zainstalowane</translation>
    </message>
    <message>
        <location filename="../src/configdialog.cpp" line="124"/>
        <source>No Clipboard</source>
        <translation>Bez schowka</translation>
    </message>
    <message>
        <location filename="../src/configdialog.cpp" line="125"/>
        <source>Always copy to clipboard</source>
        <translation>Zawsze kopiuj do schowka</translation>
    </message>
    <message>
        <location filename="../src/configdialog.cpp" line="126"/>
        <source>On-demand copy to clipboard</source>
        <translation>Kopiuj do schowka na żądanie</translation>
    </message>
    <message>
        <location filename="../src/configdialog.cpp" line="207"/>
        <location filename="../src/configdialog.cpp" line="223"/>
        <source>This field is required</source>
        <translation>To pole jest wymagane</translation>
    </message>
    <message>
        <location filename="../src/configdialog.cpp" line="653"/>
        <source>Select recipients for %1</source>
        <translation>Wybierz odbiorców dla %1</translation>
    </message>
    <message>
        <location filename="../src/configdialog.cpp" line="671"/>
        <source>New Profile</source>
        <translation>Nowy profil</translation>
    </message>
    <message>
        <location filename="../src/configdialog.cpp" line="703"/>
        <source>No profile selected</source>
        <translation>Nie wybrano profilu</translation>
    </message>
    <message>
        <location filename="../src/configdialog.cpp" line="704"/>
        <source>No profile selected to delete</source>
        <translation>Nie wybrano profilu do usunięcia</translation>
    </message>
    <message>
        <location filename="../src/configdialog.cpp" line="803"/>
        <source>GnuPG not found</source>
        <translation>Nie znaleziono GnuPG</translation>
    </message>
    <message>
        <location filename="../src/configdialog.cpp" line="806"/>
        <source>Please install GnuPG on your system.&lt;br&gt;Install &lt;strong&gt;Ubuntu&lt;/strong&gt; from the Microsoft Store to get it.&lt;br&gt;If you already did so, make sure you started it once and&lt;br&gt;click &quot;Autodetect&quot; in the next dialog.</source>
        <translation>Zainstaluj GnuPG na swoim systemie.&lt;br&gt;Zainstaluj &lt;strong&gt;Ubuntu&lt;/strong&gt; z Microsoft Store.&lt;br&gt;Jeśli już to zrobiłeś, upewnij się, że uruchomiłeś system raz i&lt;br&gt;kliknij „Automatycznie wykryj” w następnym oknie dialogowym.</translation>
    </message>
    <message>
        <location filename="../src/configdialog.cpp" line="811"/>
        <source>Please install GnuPG on your system.&lt;br&gt;Install &lt;strong&gt;Ubuntu&lt;/strong&gt; from the Microsoft Store&lt;br&gt;or &lt;a href=&quot;https://www.gnupg.org/download/#sec-1-2&quot;&gt;download&lt;/a&gt; it from GnuPG.org</source>
        <translation>Zainstaluj GnuPG na swoim systemie.&lt;br&gt;Zainstaluj &lt;strong&gt;Ubuntu&lt;/strong&gt; z Microsoft Store&lt;br&gt;lub &lt;a href=&quot;https://www.gnupg.org/download/#sec-1-2&quot;&gt;zainstaluj&lt;/a&gt; z GnuPG.org</translation>
    </message>
    <message>
        <location filename="../src/configdialog.cpp" line="817"/>
        <source>Please install GnuPG on your system.&lt;br&gt;Install &lt;strong&gt;gpg&lt;/strong&gt; using your favorite package manager&lt;br&gt;or &lt;a href=&quot;https://www.gnupg.org/download/#sec-1-2&quot;&gt;download&lt;/a&gt; it from GnuPG.org</source>
        <translation>Zainstaluj GnuPG na swoim systemie.&lt;br&gt;Zainstaluj &lt;strong&gt;gpg&lt;/strong&gt; używając twojego ulubionego menedżera proramów&lt;br&gt;lub &lt;a href=&quot;https://www.gnupg.org/download/#sec-1-2&quot;&gt;zainstaluj&lt;/a&gt; z GnuPG.org</translation>
    </message>
    <message>
        <location filename="../src/configdialog.cpp" line="871"/>
        <source>Create password-store?</source>
        <translation>Stworzyć magazyn haseł?</translation>
    </message>
    <message>
        <location filename="../src/configdialog.cpp" line="872"/>
        <source>Would you like to create a password-store at %1?</source>
        <translation>Czy chciałbyś stworzyć magazyn haseł w %1?</translation>
    </message>
    <message>
        <location filename="../src/configdialog.cpp" line="877"/>
        <source>Error</source>
        <translation>Błąd</translation>
    </message>
    <message>
        <location filename="../src/configdialog.cpp" line="878"/>
        <source>Failed to create password-store at: %1</source>
        <translation>Nie udało się utworzyć magazynu haseł w: %1</translation>
    </message>
    <message>
        <location filename="../src/configdialog.cpp" line="909"/>
        <source>Password store not initialised</source>
        <translation>Magazyn haseł nie został zainicjowany</translation>
    </message>
    <message>
        <location filename="../src/configdialog.cpp" line="910"/>
        <source>The folder %1 doesn&apos;t seem to be a password store or is not yet initialised.</source>
        <translation>Folder %1 nie posiada magazynu haseł lub jeszcze nie jest zainicjowany.</translation>
    </message>
    <message>
        <location filename="../src/configdialog.ui" line="436"/>
        <source>Use PWGen</source>
        <translation>Użyj PWGen</translation>
    </message>
    <message>
        <location filename="../src/configdialog.ui" line="498"/>
        <source>Use Git</source>
        <translation>Użyj Git</translation>
    </message>
    <message>
        <location filename="../src/configdialog.ui" line="567"/>
        <source>Use QRencode</source>
        <translation>Uzyj QRencode</translation>
    </message>
    <message>
        <location filename="../src/configdialog.ui" line="581"/>
        <source>Use pass-otp extension</source>
        <translation>Użyj rozszerzenia pass-otp</translation>
    </message>
    <message>
        <location filename="../src/configdialog.ui" line="702"/>
        <source>Nati&amp;ve Git/GPG</source>
        <translation>Naty&amp;wny Git/GPG</translation>
    </message>
    <message>
        <location filename="../src/configdialog.ui" line="739"/>
        <source>Git</source>
        <translation>Git</translation>
    </message>
    <message>
        <location filename="../src/configdialog.ui" line="749"/>
        <location filename="../src/configdialog.ui" line="756"/>
        <location filename="../src/configdialog.ui" line="799"/>
        <location filename="../src/configdialog.ui" line="830"/>
        <location filename="../src/configdialog.ui" line="1008"/>
        <source>…</source>
        <translation>…</translation>
    </message>
    <message>
        <location filename="../src/configdialog.ui" line="779"/>
        <source>GPG</source>
        <translation>GPG</translation>
    </message>
    <message>
        <location filename="../src/configdialog.ui" line="792"/>
        <source>PWGen</source>
        <translation>PWGen</translation>
    </message>
    <message>
        <location filename="../src/configdialog.ui" line="1042"/>
        <source>Templates add extra fields in the password generation dialogue, and in the password view.</source>
        <translation>Szablony dodają dodatkowe pola w oknie dialogowym generowania hasła oraz w widoku hasła.</translation>
    </message>
    <message>
        <location filename="../src/configdialog.ui" line="1073"/>
        <source>login
URL
e-mail</source>
        <translation>login
URL
e-mail</translation>
    </message>
</context>
<context>
    <name>ImitatePass</name>
    <message>
        <location filename="../src/imitatepass.cpp" line="141"/>
        <location filename="../src/imitatepass.cpp" line="319"/>
        <location filename="../src/imitatepass.cpp" line="505"/>
        <source>Check .gpgid file signature!</source>
        <translation>Sprawdź podpis pliku .gpgid!</translation>
    </message>
    <message>
        <location filename="../src/imitatepass.cpp" line="142"/>
        <location filename="../src/imitatepass.cpp" line="320"/>
        <location filename="../src/imitatepass.cpp" line="506"/>
        <source>Signature for %1 is invalid.</source>
        <translation>Podpis %1 jest nieprawidłowy.</translation>
    </message>
    <message>
        <location filename="../src/imitatepass.cpp" line="149"/>
        <location filename="../src/imitatepass.cpp" line="598"/>
        <source>Can not edit</source>
        <translation>Nie można edytować</translation>
    </message>
    <message>
        <location filename="../src/imitatepass.cpp" line="150"/>
        <location filename="../src/imitatepass.cpp" line="599"/>
        <source>Could not read encryption key to use, .gpg-id file missing or invalid.</source>
        <translation>Nie można było odczytać klucza szyfrowania, plik .gpg-id nie istnieje lub jest niepoprawny.</translation>
    </message>
    <message>
        <location filename="../src/imitatepass.cpp" line="314"/>
        <source>GPG signing failed!</source>
        <translation>Podpisanie GPG się nie powiodło!</translation>
    </message>
    <message>
        <location filename="../src/imitatepass.cpp" line="315"/>
        <source>Failed to sign %1.</source>
        <translation>Nie udało się podpisać %1.</translation>
    </message>
    <message>
        <location filename="../src/imitatepass.cpp" line="382"/>
        <source>No signing key!</source>
        <translation>Brak klucza podpisu!</translation>
    </message>
    <message>
        <location filename="../src/imitatepass.cpp" line="383"/>
        <source>None of the secret signing keys is available.
You will not be able to change the user list!</source>
        <translation>Żaden z tajnych kluczy podpisu nie jest dostępny.
Nie będzie można zmienić listy użytkowników!</translation>
    </message>
    <message>
        <location filename="../src/imitatepass.cpp" line="260"/>
        <source>Cannot update</source>
        <translation>Nie można było zaaktualizować</translation>
    </message>
    <message>
        <location filename="../src/imitatepass.cpp" line="261"/>
        <source>Failed to open .gpg-id for writing.</source>
        <translation>Nie udało się otworzyć pliku .gpg-id w trybie zapisywania.</translation>
    </message>
    <message>
        <location filename="../src/imitatepass.cpp" line="274"/>
        <source>Check selected users!</source>
        <translation>Sprawdź wybranych użytkowników!</translation>
    </message>
    <message>
        <location filename="../src/imitatepass.cpp" line="275"/>
        <source>None of the selected keys have a secret key available.
You will not be able to decrypt any newly added passwords!</source>
        <translation>Żaden z zaznaczonych kluczy nie ma dostępnego tajnego klucza.
Nie będziesz w stanie rozszyfrować żadnych nowych haseł!</translation>
    </message>
    <message>
        <location filename="../src/imitatepass.cpp" line="662"/>
        <location filename="../src/imitatepass.cpp" line="769"/>
        <source>Re-encryption failed</source>
        <translation>Ponowne szyfrowanie się nie powiodło</translation>
    </message>
    <message>
        <location filename="../src/imitatepass.cpp" line="663"/>
        <source>Failed to replace %1. Original has been restored.</source>
        <translation>Nie udało się zastąpić %1. Oryginał został przywrócony.</translation>
    </message>
    <message>
        <location filename="../src/imitatepass.cpp" line="692"/>
        <source>Creating backup commit</source>
        <translation>Tworzenie zatwierdzenia kopii zapasowej</translation>
    </message>
    <message>
        <location filename="../src/imitatepass.cpp" line="698"/>
        <location filename="../src/imitatepass.cpp" line="706"/>
        <source>Backup commit failed</source>
        <translation>Nie udało się zatwierdzić kopii zapasowej</translation>
    </message>
    <message>
        <location filename="../src/imitatepass.cpp" line="699"/>
        <source>Could not inspect git status. Re-encryption was aborted.</source>
        <translation>Nie można sprawdzić statusu git. Ponowne szyfrowanie zostało przerwane.</translation>
    </message>
    <message>
        <location filename="../src/imitatepass.cpp" line="707"/>
        <source>Re-encryption was aborted because a git backup could not be created.</source>
        <translation>Ponowne szyfrowanie zostało przerwane, ponieważ nie udało się utworzyć kopii zapasowej git.</translation>
    </message>
    <message>
        <location filename="../src/imitatepass.cpp" line="729"/>
        <source>Re-encrypting from folder %1</source>
        <translation>Ponowne szyfrowanie z folderu %1</translation>
    </message>
    <message>
        <location filename="../src/imitatepass.cpp" line="732"/>
        <location filename="../src/imitatepass.cpp" line="787"/>
        <source>Updating password-store</source>
        <translation>Aktualizowanie magazynu haseł</translation>
    </message>
    <message>
        <location filename="../src/imitatepass.cpp" line="757"/>
        <source>GPG ID verification failed</source>
        <translation>Weryfikacja identyfikatora GPG się nie powiodła</translation>
    </message>
    <message>
        <location filename="../src/imitatepass.cpp" line="758"/>
        <source>Could not verify .gpg-id for directory.</source>
        <translation>Nie można zweryfikować pliku .gpg-id dla katalogu.</translation>
    </message>
    <message>
        <location filename="../src/imitatepass.cpp" line="770"/>
        <source>Failed to re-encrypt %1</source>
        <translation>Nie udało się ponownie zaszyfrować %1</translation>
    </message>
    <message>
        <location filename="../src/imitatepass.cpp" line="776"/>
        <source>Re-encryption completed: %1 succeeded, %2 failed</source>
        <translation>Ponowne szyfrowanie zakończone. Powiodło się: %1. Nie powiodło się: %2</translation>
    </message>
    <message>
        <location filename="../src/imitatepass.cpp" line="782"/>
        <source>Re-encryption completed: %1 files re-encrypted</source>
        <translation>Ponowne szyfrowanie ukończone. Ponownie zaszyfrowane pliki: %1</translation>
    </message>
</context>
<context>
    <name>KeygenDialog</name>
    <message>
        <location filename="../src/keygendialog.ui" line="14"/>
        <source>Generate GnuPG keypair</source>
        <translation>Generuj pare kluczy GnuPG</translation>
    </message>
    <message>
        <location filename="../src/keygendialog.ui" line="42"/>
        <source>Generate a new key pair</source>
        <translation>Generuj nową pare kluczy</translation>
    </message>
    <message>
        <location filename="../src/keygendialog.ui" line="91"/>
        <source>Email</source>
        <translation>E-mail</translation>
    </message>
    <message>
        <location filename="../src/keygendialog.ui" line="123"/>
        <source>Name</source>
        <translation>Nazwa</translation>
    </message>
    <message>
        <location filename="../src/keygendialog.ui" line="155"/>
        <source>Passphrase</source>
        <translation>Hasło</translation>
    </message>
    <message>
        <location filename="../src/keygendialog.ui" line="200"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;There is no limit on the length of a passphrase, and it should be carefully chosen. From the perspective of security, the passphrase to unlock the private key is one of the weakest points in GnuPG (and other public-key encryption systems as well) since it is the only protection you have if another individual gets your private key. &lt;br/&gt;Ideally, the passphrase should not use words from a dictionary and should mix the case of alphabetic characters as well as use non-alphabetic characters.&lt;br/&gt;A good passphrase is crucial to the secure use of GnuPG.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Długość hasła jest nieograniczona i należy je starannie dobrać. Z punktu widzenia bezpieczeństwa hasło do odblokowania klucza prywatnego jest jednym z najsłabszych punktów GnuPG (i innych systemów szyfrowania kluczem publicznym), ponieważ stanowi jedyne zabezpieczenie w przypadku, gdy inna osoba uzyska dostęp do klucza prywatnego. &lt;br/&gt;W idealnym przypadku hasło nie powinno zawierać słów ze słownika, a jedynie litery i znaki spoza alfabetu.&lt;br/&gt;Dobre hasło jest kluczem do bezpiecznego korzystania z GnuPG.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../src/keygendialog.ui" line="210"/>
        <source>Repeat pass</source>
        <translation>Powtórz hasło</translation>
    </message>
    <message>
        <location filename="../src/keygendialog.ui" line="227"/>
        <source>Expert</source>
        <translation>Zaawansowane</translation>
    </message>
    <message>
        <location filename="../src/keygendialog.ui" line="246"/>
        <source>Template contents will be set based on GPG version.</source>
        <translation>Zawartość szablonu zostanie ustawiona na podstawie wersji GPG.</translation>
    </message>
    <message>
        <source>#           QtPass GPG key generator
#
#      first test version please comment
#
%echo Generating a default key
Key-Type: RSA
Subkey-Type: RSA
Name-Real:
Name-Comment: QtPass
Name-Email:
Expire-Date: 0
%no-protection
# Do a commit here, so that we can later print &quot;done&quot; :-)
%commit
%echo done</source>
        <translation type="vanished"># Generator kluczy GPG QtPass
#
# pierwsza wersja testowa, proszę o komentarz
#
%echo Generowanie domyślnego klucza
Klucz-typ: RSA
Podklucz-typ: RSA
Nazwa-rzeczywista:
Nazwa-komentarz: QtPass
Nazwa-e-mail:
Data wygaśnięcia: 0
%no-protection
# Zatwierdź tutaj, abyśmy mogli później wyświetlić „done” :-)
%commit
%echo done</translation>
    </message>
    <message>
        <source>#           QtPass GPG key generator
#
#      first test version please comment
#
%echo Generating a default key
Key-Type: default
Subkey-Type: default
Name-Real:
Name-Comment: QtPass
Name-Email:
Expire-Date: 0
%no-protection
# Do a commit here, so that we can later print &quot;done&quot; :-)
%commit
%echo done</source>
        <translation type="vanished">#           QtPass GPG key generator
#
#      first test version please comment
#
%echo Generating a default key
Key-Type: default
Subkey-Type: default
Name-Real:
Name-Comment: QtPass
Name-Email:
Expire-Date: 0
%no-protection
# Do a commit here, so that we can later print &quot;done&quot; :-)
%commit
%echo done</translation>
    </message>
    <message>
        <location filename="../src/keygendialog.ui" line="259"/>
        <source>For expert options check out the &lt;a href=&quot;https://www.gnupg.org/documentation/manuals/gnupg/Unattended-GPG-key-generation.html&quot;&gt;GnuPG manual&lt;/a&gt;</source>
        <translation>Ustawienia zaawansowane można znaleźć w &lt;a href=&quot;https://www.gnupg.org/documentation/manuals/gnupg/Unattended-GPG-key-generation.html&quot;&gt;podręczniku GnuPG&lt;/a&gt;</translation>
    </message>
    <message>
        <location filename="../src/keygendialog.cpp" line="168"/>
        <source>Invalid name</source>
        <translation>Niepoprawna nazwa</translation>
    </message>
    <message>
        <location filename="../src/keygendialog.cpp" line="169"/>
        <source>Name must be at least 5 characters long.</source>
        <translation>Nazwa musi mieć co najmniej 5 znaków.</translation>
    </message>
    <message>
        <location filename="../src/keygendialog.cpp" line="180"/>
        <source>Invalid email</source>
        <translation>Niepoprawny e-mail</translation>
    </message>
    <message>
        <location filename="../src/keygendialog.cpp" line="181"/>
        <source>The email address you typed is not a valid email address.</source>
        <translation>Adres e-mail, który wpisano, jest niepoprawny.</translation>
    </message>
    <message>
        <location filename="../src/keygendialog.cpp" line="196"/>
        <source>This operation can take some minutes.&lt;br /&gt;We need to generate a lot of random bytes. It is a good idea to perform some other action (type on the keyboard, move the mouse, utilize the disks) during the prime generation; this gives the random number generator a better chance to gain enough entropy.</source>
        <translation>Ta operacja może potrwać kilka minut.&lt;br /&gt;Musimy wygenerować dużo losowych bajtów. Dobrym pomysłem jest wykonanie innej czynności (pisanie na klawiaturze, poruszanie myszą, korzystanie z dysków) podczas generowania liczb pierwszych; daje to generatorowi liczb losowych większą szansę na uzyskanie wystarczającej entropii.</translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <source>Copied to clipboard</source>
        <translation type="vanished">skopiowany do schowka</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="14"/>
        <source>QtPass</source>
        <translation>QtPass</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="68"/>
        <source>Select profile</source>
        <translation>Wybierz profil</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="120"/>
        <location filename="../src/mainwindow.cpp" line="536"/>
        <location filename="../src/mainwindow.cpp" line="719"/>
        <source>Search Password</source>
        <translation>Wyszukaj hasło</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="127"/>
        <source>Search inside password content (pass grep)</source>
        <translation>Wyszukaj w zawartości hasła (pass grep)</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="130"/>
        <source>⌕</source>
        <translation>⌕</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="133"/>
        <source>Content search toggle</source>
        <translation>Przełącznik wyszukiwania zawartości</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="136"/>
        <source>Toggle content search mode to search inside password files</source>
        <translation>Przełącz tryb wyszukiwania zawartości, aby wyszukiwać w plikach haseł</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="146"/>
        <source>Case-insensitive search</source>
        <translation>Wyszukiwanie bez uwzględniania wielkości liter</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="149"/>
        <source>Aa</source>
        <translation>Aa</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="152"/>
        <source>Case-insensitive toggle</source>
        <translation>Przełącznik ignorowania wielkości liter</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="155"/>
        <source>Toggle case-insensitive content search</source>
        <translation>Przełącz wyszukiwanie zawartości bez uwzględniania wielkości liter</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="211"/>
        <source>Results</source>
        <translation>Wyniki</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="263"/>
        <source>Welcome to QtPass</source>
        <translation>Witamy w QtPass</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="379"/>
        <location filename="../src/mainwindow.ui" line="382"/>
        <location filename="../src/mainwindow.cpp" line="1192"/>
        <source>Add password</source>
        <translation>Dodaj hasło</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="385"/>
        <source>Ctrl+N</source>
        <translation>Ctrl+N</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="390"/>
        <location filename="../src/mainwindow.ui" line="393"/>
        <location filename="../src/mainwindow.cpp" line="1191"/>
        <source>Add folder</source>
        <translation>Dodaj folder</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="398"/>
        <location filename="../src/mainwindow.ui" line="401"/>
        <location filename="../src/mainwindow.cpp" line="1199"/>
        <source>Edit</source>
        <translation>Edytuj</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="406"/>
        <location filename="../src/mainwindow.ui" line="409"/>
        <location filename="../src/mainwindow.cpp" line="1213"/>
        <source>Delete</source>
        <translation>Usuń</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="414"/>
        <source>OTP</source>
        <translation>OTP</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="417"/>
        <source>Generate OTP and copy to clipboard</source>
        <translation>Wygeneruj OTP i dodaj do schowka</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="420"/>
        <source>Ctrl+G</source>
        <translation>Ctrl+G</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="425"/>
        <source>Push</source>
        <translation>Push</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="428"/>
        <source>Git push</source>
        <translation>Git push</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="436"/>
        <source>Git pull</source>
        <translation>Git pull</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="433"/>
        <source>Update</source>
        <translation>Zaaktualizuj</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="441"/>
        <location filename="../src/mainwindow.cpp" line="1193"/>
        <source>Users</source>
        <translation>Użytkownicy</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="444"/>
        <source>Manage who can read password in folder</source>
        <translation>Zarządzaj, kto może odczytać hasło w folderze</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="449"/>
        <source>Config</source>
        <translation>Konfiguracja</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="452"/>
        <source>Configuration</source>
        <translation>Konfiguracja</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="202"/>
        <source>Welcome to QtPass %1</source>
        <translation>Witamy w QtPass %1</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="340"/>
        <location filename="../src/mainwindow.cpp" line="353"/>
        <source>Updating password-store</source>
        <translation>Aktualizowanie magazynu haseł</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="461"/>
        <location filename="../src/mainwindow.cpp" line="760"/>
        <source>Content hidden</source>
        <translation>Zawartość ukryta</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="465"/>
        <location filename="../src/mainwindow.cpp" line="1432"/>
        <source>Password</source>
        <translation>Hasło</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="502"/>
        <source>OTP Code</source>
        <translation>Kod OTP</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="504"/>
        <source>OTP code copied to clipboard</source>
        <translation>Kod OTP skopiowano do schowka</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="506"/>
        <source>No OTP code found in this password entry</source>
        <translation>W tym wpisie hasła nie znaleziono kodu OTP</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="540"/>
        <source>Password and Content hidden</source>
        <translation>Hasło i zawartość ukryta</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="620"/>
        <source>Looking for: %1</source>
        <translation>Szukanie: %1</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="670"/>
        <source>Searching…</source>
        <translation>Wyszukiwanie…</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="701"/>
        <source>Search content (regex)</source>
        <translation>Wyszukaj zawartość (wyrażenie regularne)</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="747"/>
        <source>No matches found.</source>
        <translation>Nie znaleziono wyników.</translation>
    </message>
    <message numerus="yes">
        <location filename="../src/mainwindow.cpp" line="770"/>
        <source>Found %n match(es) in %1 entr(ies).</source>
        <translation>
            <numerusform>Znaleziono %n wynik we wpisach: %1.</numerusform>
            <numerusform>Znaleziono %n wyniki we wpisach: %1.</numerusform>
            <numerusform>Znaleziono %n wyników we wpisach: %1.</numerusform>
        </translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="856"/>
        <location filename="../src/mainwindow.cpp" line="1258"/>
        <source>New file</source>
        <translation>Nowy plik</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="857"/>
        <source>New password file: 
(Will be placed in %1 )</source>
        <translation>Nowy plik hasła: 
(Zostanie dodane do %1 )</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="894"/>
        <source> and the whole content?</source>
        <translation> i cała treść?</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="904"/>
        <source> and the whole content? &lt;br&gt;&lt;strong&gt;Attention: there are unexpected files in the given folder, check them before continue.&lt;/strong&gt;</source>
        <translation> i cała treść? &lt;br&gt;&lt;strong&gt;Uwaga: znajdują się niespodziewane pliki w danym folderze, sprawdź je przed kontynuacją.&lt;/strong&gt;</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="913"/>
        <source>Delete folder?</source>
        <translation>Usunąć folder?</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="913"/>
        <source>Delete password?</source>
        <translation>Usunąć hasło?</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="914"/>
        <source>Are you sure you want to delete %1%2?</source>
        <translation>Czy na pewno chcesz usunąć %1%2?</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="934"/>
        <source>No password selected for OTP generation</source>
        <translation>Nie wybrano hasła do wygenerowania OTP</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1062"/>
        <source>Profile changed to %1</source>
        <translation>Profil zmienony na %1</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1190"/>
        <source>Open folder with file manager</source>
        <translation>Otwórz folder w menedżerze plików</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1205"/>
        <source>Rename folder</source>
        <translation>Zmień nazwe folderu</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1209"/>
        <source>Rename password</source>
        <translation>Zmień nazwe hasła</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1218"/>
        <source>Re-encrypt</source>
        <translation>Zaszyfruj ponownie</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1259"/>
        <source>New Folder: 
(Will be placed in %1 )</source>
        <translation>Nowy folder: 
(Zostanie dodany do %1 )</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1269"/>
        <location filename="../src/mainwindow.cpp" line="1278"/>
        <location filename="../src/mainwindow.cpp" line="1487"/>
        <source>Error</source>
        <translation>Błąd</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1270"/>
        <source>Failed to create folder: %1</source>
        <translation>Nie udało się utworzyć folderu: %1</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1279"/>
        <source>Failed to create .gpg-id file in: %1</source>
        <translation>Nie udało się utworzyć pliku .gpg-id w: %1</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1301"/>
        <location filename="../src/mainwindow.cpp" line="1337"/>
        <source>Rename file</source>
        <translation>Zmień nazwe pliku</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1301"/>
        <source>Rename Folder To: </source>
        <translation>Zmień nazwe folderu na: </translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1337"/>
        <source>Rename File To: </source>
        <translation>Zmień nazwę pliku na: </translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1488"/>
        <source>Directory does not exist: %1</source>
        <translation>Katalog nie istnieje: %1</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1493"/>
        <source>Re-encrypt passwords</source>
        <translation>Ponowne szyfrowanie haseł</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1494"/>
        <source>Re-encrypt all passwords in %1?

This will re-encrypt ALL password files in this folder using the current recipients defined in .gpg-id.

This may rewrite many files and cannot be undone easily.

Continue?</source>
        <translation>Zaszyfrować ponownie wszystkie hasła w&#xa0;%1?

Spowoduje to ponowne zaszyfrowanie WSZYSTKICH plików haseł w&#xa0;tym folderze, używając bieżących odbiorców zdefiniowanych w&#xa0;pliku .gpg-id.

Może to spowodować nadpisanie wielu plików i&#xa0;nie można tego łatwo cofnąć.

Kontynuować?</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="322"/>
        <source>&lt;p&gt;QtPass is a GUI for &lt;a href=&quot;https://www.passwordstore.org/&quot;&gt;pass&lt;/a&gt;, the standard unix password manager.&lt;/p&gt;
&lt;p&gt;Please report any &lt;a href=&quot;https://github.com/IJHack/qtpass/issues&quot;&gt;issues&lt;/a&gt; you might have with this software.&lt;/p&gt;
&lt;p&gt;&lt;a href=&quot;https://qtpass.org/&quot;&gt;Documentation&lt;/a&gt;&lt;/p&gt;
&lt;p&gt;&lt;a href=&quot;https://github.com/IJHack/qtpass&quot;&gt;SourceCode&lt;/a&gt;&lt;/p&gt;</source>
        <translation>&lt;p&gt;QtPass to graficzny interfejs użytkownika dla &lt;a href=&quot;https://www.passwordstore.org/&quot;&gt;pass&lt;/a&gt;, standardowego menedżera haseł w systemach uniksowych.&lt;/p&gt;
&lt;p&gt;Prosze zgłaszać jakiekolwiek &lt;a href=&quot;https://github.com/IJHack/qtpass/issues&quot;&gt;problemy&lt;/a&gt; z programem.&lt;/p&gt;
&lt;p&gt;&lt;a href=&quot;https://qtpass.org/&quot;&gt;Dokumentacja&lt;/a&gt;&lt;/p&gt;
&lt;p&gt;&lt;a href=&quot;https://github.com/IJHack/qtpass&quot;&gt;Kod źródłowy&lt;/a&gt;&lt;/p&gt;</translation>
    </message>
</context>
<context>
    <name>Pass</name>
    <message>
        <location filename="../src/pass.cpp" line="142"/>
        <source>Invalid password length</source>
        <translation>Nieprawidłowa długość hasła</translation>
    </message>
    <message>
        <location filename="../src/pass.cpp" line="143"/>
        <source>Can&apos;t generate password with zero length.</source>
        <translation>Nie można wygenerować hasła o zerowej długości.</translation>
    </message>
    <message>
        <location filename="../src/pass.cpp" line="186"/>
        <source>No characters chosen</source>
        <translation>Brak wybranych znaków</translation>
    </message>
    <message>
        <location filename="../src/pass.cpp" line="187"/>
        <source>Can&apos;t generate password, there are no characters to choose from set in the configuration!</source>
        <translation>Nie można wygenerować hasła, nie zostały wybrane żadne zestawy znaki w konfiguracji!</translation>
    </message>
    <message>
        <location filename="../src/pass.cpp" line="514"/>
        <location filename="../src/pass.cpp" line="533"/>
        <source>Encryption failed: GPG key has expired. Please renew or replace it.</source>
        <translation>Szyfrowanie nie powiodło się: klucz GPG wygasł. Należy go odnowić lub wymienić.</translation>
    </message>
    <message>
        <location filename="../src/pass.cpp" line="519"/>
        <location filename="../src/pass.cpp" line="538"/>
        <source>Encryption failed: GPG key has been revoked.</source>
        <translation>Szyfrowanie nie powiodło się: klucz GPG został unieważniony.</translation>
    </message>
    <message>
        <location filename="../src/pass.cpp" line="523"/>
        <location filename="../src/pass.cpp" line="543"/>
        <source>Encryption failed: recipient GPG key not found or invalid. Check that the key ID in .gpg-id is correct and imported.</source>
        <translation>Szyfrowanie nie powiodło się: klucz GPG odbiorcy nie został znaleziony lub jest nieprawidłowy. Sprawdź, czy identyfikator klucza w pliku .gpg-id jest poprawny i zaimportuj go.</translation>
    </message>
    <message>
        <location filename="../src/pass.cpp" line="527"/>
        <location filename="../src/pass.cpp" line="547"/>
        <source>Encryption failed. Check that your GPG key is valid.</source>
        <translation>Szyfrowanie nie powiodło się. Sprawdź, czy klucz GPG jest prawidłowy.</translation>
    </message>
</context>
<context>
    <name>PasswordDialog</name>
    <message>
        <location filename="../src/passworddialog.ui" line="14"/>
        <location filename="../src/passworddialog.ui" line="65"/>
        <source>Password</source>
        <translation>Hasło</translation>
    </message>
    <message>
        <location filename="../src/passworddialog.ui" line="75"/>
        <source>Generate</source>
        <translation>Wygeneruj</translation>
    </message>
    <message>
        <location filename="../src/passworddialog.ui" line="86"/>
        <source>Show password</source>
        <translation>Pokaż hasło</translation>
    </message>
    <message>
        <location filename="../src/passworddialog.ui" line="106"/>
        <source>Character Set:</source>
        <translation>Zestaw znaków:</translation>
    </message>
    <message>
        <location filename="../src/passworddialog.ui" line="114"/>
        <source>All Characters</source>
        <translation>Wszystkie znaki</translation>
    </message>
    <message>
        <location filename="../src/passworddialog.ui" line="119"/>
        <source>Alphabetical</source>
        <translation>Alfabetyczne</translation>
    </message>
    <message>
        <location filename="../src/passworddialog.ui" line="124"/>
        <source>Alphanumerical</source>
        <translation>Alfanumeryczne</translation>
    </message>
    <message>
        <location filename="../src/passworddialog.ui" line="129"/>
        <source>Custom</source>
        <translation>Niestandardowe</translation>
    </message>
    <message>
        <location filename="../src/passworddialog.ui" line="143"/>
        <source>Length:</source>
        <translation>Długość:</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../main/main.cpp" line="155"/>
        <location filename="../main/main.cpp" line="159"/>
        <source>LTR</source>
        <translation>LTR</translation>
    </message>
</context>
<context>
    <name>QtPass</name>
    <message>
        <location filename="../src/qtpass.cpp" line="512"/>
        <source>Copied to clipboard</source>
        <translation>Skopiowano do schowka</translation>
    </message>
    <message>
        <location filename="../src/qtpass.cpp" line="160"/>
        <source>Generating GPG key pair</source>
        <translation>Generowanie pary kluczy GPG</translation>
    </message>
    <message>
        <location filename="../src/qtpass.cpp" line="223"/>
        <source>Failed to connect WebDAV:
</source>
        <translation>Nie udało się połączyć z WebDAV:
</translation>
    </message>
    <message>
        <location filename="../src/qtpass.cpp" line="240"/>
        <source>QtPass WebDAV password</source>
        <translation>Hasło WebDAV QtPass</translation>
    </message>
    <message>
        <location filename="../src/qtpass.cpp" line="241"/>
        <source>Enter password to connect to WebDAV:</source>
        <translation>Podaj hasło do połączenia się z WebDAV:</translation>
    </message>
    <message>
        <location filename="../src/qtpass.cpp" line="258"/>
        <source>fusedav exited unexpectedly
</source>
        <translation>fusedav niespodziewanie wyłączył się
</translation>
    </message>
    <message>
        <location filename="../src/qtpass.cpp" line="262"/>
        <source>Failed to start fusedav to connect WebDAV:
</source>
        <translation>Nie udało się uruchomić fusedav w celu połączenia z WebDAV:
</translation>
    </message>
    <message>
        <location filename="../src/qtpass.cpp" line="275"/>
        <source>QProcess::FailedToStart</source>
        <translation>QPRocess::FailedToStart</translation>
    </message>
    <message>
        <location filename="../src/qtpass.cpp" line="278"/>
        <source>QProcess::Crashed</source>
        <translation>QProcess::Crashed</translation>
    </message>
    <message>
        <location filename="../src/qtpass.cpp" line="281"/>
        <source>QProcess::Timedout</source>
        <translation>QProcess::Timedout</translation>
    </message>
    <message>
        <location filename="../src/qtpass.cpp" line="284"/>
        <source>QProcess::ReadError</source>
        <translation>QProcess::ReadError</translation>
    </message>
    <message>
        <location filename="../src/qtpass.cpp" line="287"/>
        <source>QProcess::WriteError</source>
        <translation>QProcess::WriteError</translation>
    </message>
    <message>
        <location filename="../src/qtpass.cpp" line="290"/>
        <source>QProcess::UnknownError</source>
        <translation>QProcess::UnknownError</translation>
    </message>
    <message>
        <location filename="../src/qtpass.cpp" line="306"/>
        <source>GPG key pair generation failed</source>
        <translation>Nie udało się wygenerować pary kluczy GPG</translation>
    </message>
    <message>
        <location filename="../src/qtpass.cpp" line="380"/>
        <source>GPG key pair generated successfully</source>
        <translation>Udało się wygenerować parę kluczy GPG</translation>
    </message>
    <message>
        <location filename="../src/qtpass.cpp" line="465"/>
        <source>Clipboard cleared</source>
        <translation>Schowek został wyczyszczony</translation>
    </message>
    <message>
        <location filename="../src/qtpass.cpp" line="467"/>
        <source>Clipboard not cleared</source>
        <translation>Schowek nie został wyczyszczony</translation>
    </message>
</context>
<context>
    <name>StoreModel</name>
    <message>
        <source>force overwrite?</source>
        <translation type="vanished">wymuś nadpisanie?</translation>
    </message>
    <message>
        <location filename="../src/storemodel.cpp" line="411"/>
        <source>Force overwrite?</source>
        <translation>Wymusić nadpisanie?</translation>
    </message>
    <message>
        <location filename="../src/storemodel.cpp" line="412"/>
        <source>overwrite %1 with %2?</source>
        <translation>nadpisać %1 przez %2?</translation>
    </message>
</context>
<context>
    <name>TrayIcon</name>
    <message>
        <location filename="../src/trayicon.cpp" line="67"/>
        <source>&amp;Show</source>
        <translation>&amp;Pokaż</translation>
    </message>
    <message>
        <location filename="../src/trayicon.cpp" line="69"/>
        <source>&amp;Hide</source>
        <translation>&amp;Ukryj</translation>
    </message>
    <message>
        <location filename="../src/trayicon.cpp" line="72"/>
        <source>Mi&amp;nimize</source>
        <translation>Mi&amp;nimalizuj</translation>
    </message>
    <message>
        <location filename="../src/trayicon.cpp" line="75"/>
        <source>Ma&amp;ximize</source>
        <translation>Ma&amp;ksymalizuj</translation>
    </message>
    <message>
        <location filename="../src/trayicon.cpp" line="78"/>
        <source>&amp;Restore</source>
        <translation>&amp;Przywróć</translation>
    </message>
    <message>
        <location filename="../src/trayicon.cpp" line="81"/>
        <source>&amp;Quit</source>
        <translation>&amp;Wyjdź</translation>
    </message>
</context>
<context>
    <name>UsersDialog</name>
    <message>
        <location filename="../src/usersdialog.ui" line="20"/>
        <source>Read access users</source>
        <translation>Użytkownicy z dostępem do odczytu</translation>
    </message>
    <message>
        <source>Select which users should be able to decrypt passwords stored in this folder.
Note: Existing files will not be modified, and retain the old permissions until you edit them.
Blue entries have a secret key available, select one of these to be able to decrypt.
Red entries are not valid, you will not be able to encrypt to these.</source>
        <translation type="vanished">Wybierz użytkowników, którzy powinni móc odszyfrowywać hasła przechowywane w tym folderze.
Uwaga: istniejące pliki nie zostaną zmodyfikowane i zachowają stare uprawnienia, dopóki ich nie edytujesz.
Wpisy niebieskie mają dostępny klucz tajny, wybierz jeden z nich, aby móc odszyfrować.
Wpisy czerwone są nieprawidłowe, nie będziesz w stanie ich zaszyfrować.</translation>
    </message>
    <message>
        <location filename="../src/usersdialog.ui" line="45"/>
        <source>Select which users should be able to decrypt passwords stored in this folder.
Note: Existing files will not be modified, and retain the old permissions until you edit them.
Blue entries have a secret key available, select one of these to be able to decrypt.
Black entries have an encryption key available and it is trusted, select one of these to allow other people to decrypt.
Red entries are not valid, you will not be able to encrypt to these.</source>
        <translation>Wybierz użytkowników, którzy powinni mieć możliwość odszyfrowywania haseł zapisanych w tym folderze.
Uwaga: istniejące pliki nie zostaną zmodyfikowane i zachowają stare uprawnienia do momentu ich edycji.
Wpisy oznaczone kolorem niebieskim mają dostępny klucz tajny. Wybierz jeden z nich, aby móc je odszyfrować.
Wpisy oznaczone kolorem czarnym mają dostępny i zaufany klucz szyfrujący. Wybierz jeden z nich, aby umożliwić innym osobom odszyfrowanie.
Wpisy oznaczone kolorem czerwonym są nieprawidłowe i nie będzie można ich zaszyfrować.</translation>
    </message>
    <message>
        <location filename="../src/usersdialog.ui" line="70"/>
        <source>Search for users</source>
        <translation>Szukaj użytkowników</translation>
    </message>
    <message>
        <location filename="../src/usersdialog.ui" line="77"/>
        <source>Show unusable keys</source>
        <translation>Pokaż nieużywalne klucze</translation>
    </message>
    <message>
        <location filename="../src/usersdialog.cpp" line="71"/>
        <source>Keylist missing</source>
        <translation>Brak listy kluczy</translation>
    </message>
    <message>
        <location filename="../src/usersdialog.cpp" line="72"/>
        <source>Could not fetch list of available GPG keys</source>
        <translation>Nie można pobrać listy dostępnych kluczy GPG</translation>
    </message>
    <message>
        <location filename="../src/usersdialog.cpp" line="148"/>
        <source>Key not found in keyring</source>
        <translation>Klucz nie został znaleziony w breloku</translation>
    </message>
    <message>
        <location filename="../src/usersdialog.cpp" line="301"/>
        <source>created</source>
        <translation>stworzono</translation>
    </message>
    <message>
        <location filename="../src/usersdialog.cpp" line="305"/>
        <source>expires</source>
        <translation>traci ważność</translation>
    </message>
    <message>
        <location filename="../src/usersdialog.cpp" line="328"/>
        <source>[INVALID] </source>
        <translation>[NIEWAŻNY] </translation>
    </message>
    <message>
        <location filename="../src/usersdialog.cpp" line="331"/>
        <source>[EXPIRED] </source>
        <translation>[WYGASŁY] </translation>
    </message>
    <message>
        <location filename="../src/usersdialog.cpp" line="335"/>
        <source>[PARTIAL] </source>
        <translation>[CZĘŚCIOWY] </translation>
    </message>
</context>
</TS>
