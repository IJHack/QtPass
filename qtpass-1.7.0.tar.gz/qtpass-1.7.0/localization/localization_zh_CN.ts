<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="zh_CN">
<context>
    <name>ConfigDialog</name>
    <message>
        <location filename="../src/configdialog.ui" line="20"/>
        <source>Configuration</source>
        <translation>设置</translation>
    </message>
    <message>
        <location filename="../src/configdialog.ui" line="46"/>
        <source>Settings</source>
        <translation>选项</translation>
    </message>
    <message>
        <location filename="../src/configdialog.ui" line="72"/>
        <source>Clipboard behaviour:</source>
        <translation>剪贴板选项：</translation>
    </message>
    <message>
        <location filename="../src/configdialog.ui" line="98"/>
        <source>Autoclear after:</source>
        <translation>清除剪贴板:</translation>
    </message>
    <message>
        <location filename="../src/configdialog.ui" line="115"/>
        <location filename="../src/configdialog.ui" line="198"/>
        <source>Seconds</source>
        <translation>秒</translation>
    </message>
    <message>
        <source>Password Behaviour:</source>
        <translation type="vanished">密码显示：</translation>
    </message>
    <message>
        <location filename="../src/configdialog.ui" line="159"/>
        <source>Hide content</source>
        <translation>隐藏内容</translation>
    </message>
    <message>
        <location filename="../src/configdialog.ui" line="166"/>
        <source>Hide password</source>
        <translation>隐藏密码</translation>
    </message>
    <message>
        <location filename="../src/configdialog.ui" line="175"/>
        <source>Autoclear panel after:</source>
        <translation>自动隐藏密码：</translation>
    </message>
    <message>
        <location filename="../src/configdialog.ui" line="224"/>
        <source>Use a monospace font</source>
        <translation>使用等宽字体</translation>
    </message>
    <message>
        <location filename="../src/configdialog.ui" line="231"/>
        <source>Display the files content as-is</source>
        <translation>按原样显示文件内容</translation>
    </message>
    <message>
        <location filename="../src/configdialog.ui" line="238"/>
        <source>No line wrapping</source>
        <translation>不换行</translation>
    </message>
    <message>
        <location filename="../src/configdialog.ui" line="270"/>
        <source>Password Generation:</source>
        <translation>密码生成选项：</translation>
    </message>
    <message>
        <location filename="../src/configdialog.ui" line="282"/>
        <source>Password Length:</source>
        <translation>密码长度：</translation>
    </message>
    <message>
        <location filename="../src/configdialog.ui" line="316"/>
        <source>Characters</source>
        <translation>位</translation>
    </message>
    <message>
        <location filename="../src/configdialog.ui" line="344"/>
        <source>Use characters:</source>
        <translation>所用字符：</translation>
    </message>
    <message>
        <location filename="../src/configdialog.ui" line="362"/>
        <source>Select character set for password generation</source>
        <translation>选择密码所用的的字符集</translation>
    </message>
    <message>
        <location filename="../src/configdialog.ui" line="366"/>
        <source>All Characters</source>
        <translation>所有字符</translation>
    </message>
    <message>
        <location filename="../src/configdialog.ui" line="371"/>
        <source>Alphabetical</source>
        <translation>英文字母</translation>
    </message>
    <message>
        <location filename="../src/configdialog.ui" line="376"/>
        <source>Alphanumerical</source>
        <translation>字母和数字</translation>
    </message>
    <message>
        <location filename="../src/configdialog.ui" line="381"/>
        <source>Custom</source>
        <translation>自定义</translation>
    </message>
    <message>
        <location filename="../src/configdialog.ui" line="419"/>
        <source>ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789</source>
        <translation>ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789</translation>
    </message>
    <message>
        <location filename="../src/configdialog.ui" line="453"/>
        <source>Include special symbols</source>
        <translation>包括特殊符号</translation>
    </message>
    <message>
        <location filename="../src/configdialog.ui" line="592"/>
        <source>Enable content search (pass grep)</source>
        <translation>启用内容搜索（pass grep）</translation>
    </message>
    <message>
        <location filename="../src/configdialog.ui" line="595"/>
        <source>Allow searching inside password file contents. Requires decrypting every file and can be slow on large stores.</source>
        <translation>允许搜索密码文件内容。需解密每个文件，如果存储很多可能会很慢。</translation>
    </message>
    <message>
        <location filename="../src/configdialog.ui" line="769"/>
        <source>Generate</source>
        <translation>生成</translation>
    </message>
    <message>
        <location filename="../src/configdialog.ui" line="772"/>
        <source>Generate GPG key pair</source>
        <translation>生成 GPG 密钥对</translation>
    </message>
    <message>
        <location filename="../src/configdialog.ui" line="945"/>
        <source>Profile name, used to identify this configuration profile</source>
        <translation>配置文件名，用于识别这个配置文件</translation>
    </message>
    <message>
        <location filename="../src/configdialog.ui" line="953"/>
        <source>Path to the password store directory</source>
        <translation>密码存储目录的路径</translation>
    </message>
    <message>
        <location filename="../src/configdialog.ui" line="958"/>
        <source>Signing Key</source>
        <translation>签名密钥</translation>
    </message>
    <message>
        <location filename="../src/configdialog.ui" line="961"/>
        <source>Optional: GPG key to sign .gpg-id files for integrity verification. Leave empty unless you need to protect the user list from tampering.</source>
        <translation>可选：用 GPG 密钥签署 .gpg-id 文件用于验证完整性。除非需要保护用户列表免于篡改否则请留空。</translation>
    </message>
    <message>
        <location filename="../src/configdialog.ui" line="1001"/>
        <source>Current path</source>
        <translation>当前路径</translation>
    </message>
    <message>
        <source>Use pwgen</source>
        <translation type="vanished">使用 pwgen</translation>
    </message>
    <message>
        <location filename="../src/configdialog.ui" line="443"/>
        <source>Exclude capital letters</source>
        <translation>不包含大写字母</translation>
    </message>
    <message>
        <source>Include special symbols </source>
        <translation type="vanished">包含特殊符号 </translation>
    </message>
    <message>
        <location filename="../src/configdialog.ui" line="460"/>
        <source>Generate easy to memorize but less secure passwords</source>
        <translation>生成好记的密码（不安全）</translation>
    </message>
    <message>
        <location filename="../src/configdialog.ui" line="467"/>
        <source>Exclude numbers</source>
        <translation>不包含数字</translation>
    </message>
    <message>
        <location filename="../src/configdialog.ui" line="486"/>
        <source>Git:</source>
        <translation>Git选项：</translation>
    </message>
    <message>
        <source>Use git</source>
        <translation type="vanished">使用 git</translation>
    </message>
    <message>
        <location filename="../src/configdialog.ui" line="512"/>
        <source>Automatically add .gpg-id files</source>
        <translation>自动添加 gpg-id 文件</translation>
    </message>
    <message>
        <location filename="../src/configdialog.ui" line="519"/>
        <source>Automatically push</source>
        <translation>自动上传</translation>
    </message>
    <message>
        <location filename="../src/configdialog.ui" line="526"/>
        <source>Automatically pull</source>
        <translation>自动更新合并</translation>
    </message>
    <message>
        <location filename="../src/configdialog.ui" line="617"/>
        <source>System:</source>
        <translation>系统选项：</translation>
    </message>
    <message>
        <location filename="../src/configdialog.ui" line="629"/>
        <source>Use TrayIcon</source>
        <translation>显示托盘图标</translation>
    </message>
    <message>
        <location filename="../src/configdialog.ui" line="636"/>
        <source>Start minimized</source>
        <translation>启动后隐藏窗口</translation>
    </message>
    <message>
        <location filename="../src/configdialog.ui" line="643"/>
        <source>Hide on close</source>
        <translation>关闭窗口后台运行</translation>
    </message>
    <message>
        <location filename="../src/configdialog.ui" line="650"/>
        <source>Always on top</source>
        <translation>始终在前</translation>
    </message>
    <message>
        <location filename="../src/configdialog.ui" line="675"/>
        <source>Programs</source>
        <translation>程序</translation>
    </message>
    <message>
        <location filename="../src/configdialog.ui" line="693"/>
        <source>Select password storage program:</source>
        <translation>选择管理密码的程序：</translation>
    </message>
    <message>
        <source>Nati&amp;ve git/gpg</source>
        <translation type="vanished">使用原生 git/gpg（推荐） (&amp;V)</translation>
    </message>
    <message>
        <location filename="../src/configdialog.ui" line="709"/>
        <source>&amp;Use pass</source>
        <translation>使用 pass (&amp;U)</translation>
    </message>
    <message>
        <location filename="../src/configdialog.ui" line="733"/>
        <source>Native</source>
        <translation>命令路径</translation>
    </message>
    <message>
        <source>git</source>
        <translation type="vanished">git</translation>
    </message>
    <message>
        <source>...</source>
        <translation type="vanished">浏览</translation>
    </message>
    <message>
        <source>gpg</source>
        <translation type="vanished">gpg</translation>
    </message>
    <message>
        <source>pwgen</source>
        <translation type="vanished">pwgen</translation>
    </message>
    <message>
        <location filename="../src/configdialog.ui" line="809"/>
        <source>Pass</source>
        <translation>Pass 路径</translation>
    </message>
    <message>
        <location filename="../src/configdialog.ui" line="820"/>
        <source>pass</source>
        <translation>pass</translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;a href=&quot;https://www.passwordstore.org/&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0000ff;&quot;&gt;www.passwordstore.org&lt;/span&gt;&lt;/a&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="vanished">&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;a href=&quot;https://www.passwordstore.org/&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0000ff;&quot;&gt;www.passwordstore.org&lt;/span&gt;&lt;/a&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../src/configdialog.ui" line="893"/>
        <source>Profiles</source>
        <translation>配置文件</translation>
    </message>
    <message>
        <location filename="../src/configdialog.ui" line="942"/>
        <source>Name</source>
        <translation>用户名</translation>
    </message>
    <message>
        <location filename="../src/configdialog.ui" line="950"/>
        <source>Path</source>
        <translation>密码库路径</translation>
    </message>
    <message>
        <location filename="../src/configdialog.ui" line="971"/>
        <source>Add</source>
        <translation>添加</translation>
    </message>
    <message>
        <location filename="../src/configdialog.ui" line="986"/>
        <source>Delete</source>
        <translation>删除</translation>
    </message>
    <message>
        <source>Current password-store</source>
        <translation type="vanished">当前密码库路径</translation>
    </message>
    <message>
        <location filename="../src/configdialog.ui" line="1021"/>
        <source>Template</source>
        <translation>模板</translation>
    </message>
    <message>
        <source>Templates add extra fields in the password generation dialogue and in the password view.</source>
        <translation type="vanished">模版会以表单的形式显示在密码和编辑密码的窗口上（一行一个）.</translation>
    </message>
    <message>
        <location filename="../src/configdialog.ui" line="1051"/>
        <source>Use template</source>
        <translation>使用模板</translation>
    </message>
    <message>
        <location filename="../src/configdialog.ui" line="1058"/>
        <source>Show all lines beginning with a word followed by a colon as fields in password fields, not only the listed ones</source>
        <translation>只要是密码文件中一个词或几个字加一个英文冒号的格式，都看作模版显示在密码框上，而不仅仅只显示下面列出的项目</translation>
    </message>
    <message>
        <location filename="../src/configdialog.ui" line="1061"/>
        <source>Show all fields templated</source>
        <translation>显示所有模板项</translation>
    </message>
    <message>
        <source>login
url
email</source>
        <translation type="vanished">用户名
网址
邮箱</translation>
    </message>
    <message>
        <location filename="../src/configdialog.ui" line="1088"/>
        <source>&lt;a href=&quot;https://QtPass.org/&quot;&gt;QtPass&lt;/a&gt; version </source>
        <translation>&lt;a href=&quot;https://QtPass.org/&quot;&gt;QtPass&lt;/a&gt; 版本 </translation>
    </message>
    <message>
        <location filename="../src/configdialog.cpp" line="124"/>
        <source>No Clipboard</source>
        <translation>不使用剪贴板</translation>
    </message>
    <message>
        <location filename="../src/configdialog.cpp" line="125"/>
        <source>Always copy to clipboard</source>
        <translation>总是复制到剪贴板</translation>
    </message>
    <message>
        <location filename="../src/configdialog.cpp" line="126"/>
        <source>On-demand copy to clipboard</source>
        <translation>手动复制到剪贴板</translation>
    </message>
    <message>
        <location filename="../src/configdialog.cpp" line="207"/>
        <location filename="../src/configdialog.cpp" line="223"/>
        <source>This field is required</source>
        <translation>此字段必填</translation>
    </message>
    <message>
        <location filename="../src/configdialog.cpp" line="653"/>
        <source>Select recipients for %1</source>
        <translation>选择 %1 的接收者</translation>
    </message>
    <message>
        <location filename="../src/configdialog.cpp" line="671"/>
        <source>New Profile</source>
        <translation>新配置文件</translation>
    </message>
    <message>
        <location filename="../src/configdialog.cpp" line="703"/>
        <source>No profile selected</source>
        <translation>未选择用户</translation>
    </message>
    <message>
        <location filename="../src/configdialog.cpp" line="704"/>
        <source>No profile selected to delete</source>
        <translation>未选择用户，无法删除</translation>
    </message>
    <message>
        <location filename="../src/configdialog.cpp" line="803"/>
        <source>GnuPG not found</source>
        <translation>无法找到 GnuPG</translation>
    </message>
    <message>
        <location filename="../src/configdialog.cpp" line="817"/>
        <source>Please install GnuPG on your system.&lt;br&gt;Install &lt;strong&gt;gpg&lt;/strong&gt; using your favorite package manager&lt;br&gt;or &lt;a href=&quot;https://www.gnupg.org/download/#sec-1-2&quot;&gt;download&lt;/a&gt; it from GnuPG.org</source>
        <translation>GnuPG未安装。&lt;br&gt;可以用系统的软件包管理器来安装&lt;strong&gt;gpg&lt;/strong&gt;&lt;br&gt;或者从 GnuPG.org &lt;a href=&quot;https://www.gnupg.org/download/#sec-1-2&quot;&gt;下载&lt;/a&gt;</translation>
    </message>
    <message>
        <location filename="../src/configdialog.cpp" line="871"/>
        <source>Create password-store?</source>
        <translation>是否创建密码库？</translation>
    </message>
    <message>
        <location filename="../src/configdialog.cpp" line="872"/>
        <source>Would you like to create a password-store at %1?</source>
        <translation>是否在 %1 创建密码库？</translation>
    </message>
    <message>
        <location filename="../src/configdialog.cpp" line="877"/>
        <source>Error</source>
        <translation>出错</translation>
    </message>
    <message>
        <location filename="../src/configdialog.cpp" line="878"/>
        <source>Failed to create password-store at: %1</source>
        <translation>未能在下列位置创建密码库：%1</translation>
    </message>
    <message>
        <location filename="../src/configdialog.cpp" line="909"/>
        <source>Password store not initialised</source>
        <translation>密码库未初始化</translation>
    </message>
    <message>
        <location filename="../src/configdialog.cpp" line="910"/>
        <source>The folder %1 doesn&apos;t seem to be a password store or is not yet initialised.</source>
        <translation>文件夹 %1 不是一个密码库或未初始化.</translation>
    </message>
    <message>
        <location filename="../src/configdialog.ui" line="91"/>
        <source>Use primary selection</source>
        <translation>使用主选择</translation>
    </message>
    <message>
        <location filename="../src/configdialog.ui" line="147"/>
        <source>Content panel behaviour:</source>
        <translation>内容面板行为：</translation>
    </message>
    <message>
        <location filename="../src/configdialog.ui" line="558"/>
        <source>Extensions:</source>
        <translation>扩展：</translation>
    </message>
    <message>
        <source>Use qrencode</source>
        <translation type="vanished">使用qrencode</translation>
    </message>
    <message>
        <source>Use pass otp extension</source>
        <translation type="vanished">使用pass otp扩展</translation>
    </message>
    <message>
        <location filename="../src/configdialog.ui" line="839"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;a href=&quot;https://www.passwordstore.org/&quot;&gt;&lt;span style=&quot; text-decoration: underline;&quot;&gt;www.passwordstore.org&lt;/span&gt;&lt;/a&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;a href=&quot;https://www.passwordstore.org/&quot;&gt;&lt;span style=&quot; text-decoration: underline;&quot;&gt;www.passwordstore.org&lt;/span&gt;&lt;/a&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../src/configdialog.ui" line="870"/>
        <source>Autodetect</source>
        <translation>自动检测</translation>
    </message>
    <message>
        <location filename="../src/configdialog.cpp" line="68"/>
        <source>System tray is not available</source>
        <translation>系统托盘不可用</translation>
    </message>
    <message>
        <location filename="../src/configdialog.cpp" line="93"/>
        <source>Pass OTP extension needs to be installed</source>
        <translation>需要安装pass OTP扩展</translation>
    </message>
    <message>
        <location filename="../src/configdialog.cpp" line="98"/>
        <source>qrencode needs to be installed</source>
        <translation>需要安装qrencode</translation>
    </message>
    <message>
        <location filename="../src/configdialog.cpp" line="806"/>
        <source>Please install GnuPG on your system.&lt;br&gt;Install &lt;strong&gt;Ubuntu&lt;/strong&gt; from the Microsoft Store to get it.&lt;br&gt;If you already did so, make sure you started it once and&lt;br&gt;click &quot;Autodetect&quot; in the next dialog.</source>
        <translation>请在您的系统上安装GnuPG。&lt;br&gt;从Microsoft Store安装&lt;strong&gt; Ubuntu &lt;/ strong&gt;即可获取。&lt;br&gt;如果您已经这样做，请确保已启动它一次，并&lt;br&gt;单击“自动检测”在下一个对话框中。</translation>
    </message>
    <message>
        <location filename="../src/configdialog.cpp" line="811"/>
        <source>Please install GnuPG on your system.&lt;br&gt;Install &lt;strong&gt;Ubuntu&lt;/strong&gt; from the Microsoft Store&lt;br&gt;or &lt;a href=&quot;https://www.gnupg.org/download/#sec-1-2&quot;&gt;download&lt;/a&gt; it from GnuPG.org</source>
        <translation>请在您的系统上安装GnuPG。&lt;br&gt;从Microsoft Store &lt;br&gt;安装&lt;strong&gt; Ubuntu &lt;/ strong&gt;或&lt;a href =“ https://www.gnupg.org/download/#sec-1-2 “&gt;从GnuPG.org下载&lt;/a&gt;它</translation>
    </message>
    <message>
        <location filename="../src/configdialog.ui" line="436"/>
        <source>Use PWGen</source>
        <translation>使用 PWGen</translation>
    </message>
    <message>
        <location filename="../src/configdialog.ui" line="498"/>
        <source>Use Git</source>
        <translation>使用 Git</translation>
    </message>
    <message>
        <location filename="../src/configdialog.ui" line="567"/>
        <source>Use QRencode</source>
        <translation>使用 QRencode</translation>
    </message>
    <message>
        <location filename="../src/configdialog.ui" line="581"/>
        <source>Use pass-otp extension</source>
        <translation>使用pass-otp扩展</translation>
    </message>
    <message>
        <location filename="../src/configdialog.ui" line="702"/>
        <source>Nati&amp;ve Git/GPG</source>
        <translation>本地Git/GPG（&amp;V）</translation>
    </message>
    <message>
        <location filename="../src/configdialog.ui" line="739"/>
        <source>Git</source>
        <translation>Git</translation>
    </message>
    <message>
        <location filename="../src/configdialog.ui" line="749"/>
        <location filename="../src/configdialog.ui" line="756"/>
        <location filename="../src/configdialog.ui" line="799"/>
        <location filename="../src/configdialog.ui" line="830"/>
        <location filename="../src/configdialog.ui" line="1008"/>
        <source>…</source>
        <translation>…</translation>
    </message>
    <message>
        <location filename="../src/configdialog.ui" line="779"/>
        <source>GPG</source>
        <translation>GPG</translation>
    </message>
    <message>
        <location filename="../src/configdialog.ui" line="792"/>
        <source>PWGen</source>
        <translation>PWGen</translation>
    </message>
    <message>
        <location filename="../src/configdialog.ui" line="1042"/>
        <source>Templates add extra fields in the password generation dialogue, and in the password view.</source>
        <translation>模板在“密码生成”对话框和“密码”视图中添加额外字段。</translation>
    </message>
    <message>
        <location filename="../src/configdialog.ui" line="1073"/>
        <source>login
URL
e-mail</source>
        <translation>login
URL
e-mail</translation>
    </message>
</context>
<context>
    <name>ImitatePass</name>
    <message>
        <location filename="../src/imitatepass.cpp" line="141"/>
        <location filename="../src/imitatepass.cpp" line="319"/>
        <location filename="../src/imitatepass.cpp" line="505"/>
        <source>Check .gpgid file signature!</source>
        <translation>检查 .gpgid 文件签名！</translation>
    </message>
    <message>
        <location filename="../src/imitatepass.cpp" line="142"/>
        <location filename="../src/imitatepass.cpp" line="320"/>
        <location filename="../src/imitatepass.cpp" line="506"/>
        <source>Signature for %1 is invalid.</source>
        <translation>%1 签名无效。</translation>
    </message>
    <message>
        <location filename="../src/imitatepass.cpp" line="149"/>
        <location filename="../src/imitatepass.cpp" line="598"/>
        <source>Can not edit</source>
        <translation>无法编辑</translation>
    </message>
    <message>
        <location filename="../src/imitatepass.cpp" line="150"/>
        <location filename="../src/imitatepass.cpp" line="599"/>
        <source>Could not read encryption key to use, .gpg-id file missing or invalid.</source>
        <translation>无法读取加密密钥，.gpg-id 文件丢失或无效.</translation>
    </message>
    <message>
        <location filename="../src/imitatepass.cpp" line="314"/>
        <source>GPG signing failed!</source>
        <translation>GPG 签名失败！</translation>
    </message>
    <message>
        <location filename="../src/imitatepass.cpp" line="315"/>
        <source>Failed to sign %1.</source>
        <translation>签署 %1 失败。</translation>
    </message>
    <message>
        <location filename="../src/imitatepass.cpp" line="382"/>
        <source>No signing key!</source>
        <translation>无签名密钥！</translation>
    </message>
    <message>
        <location filename="../src/imitatepass.cpp" line="383"/>
        <source>None of the secret signing keys is available.
You will not be able to change the user list!</source>
        <translation>没有一个私密签名密钥可用。
你将无法更改用户列表！</translation>
    </message>
    <message>
        <location filename="../src/imitatepass.cpp" line="260"/>
        <source>Cannot update</source>
        <translation>无法更新</translation>
    </message>
    <message>
        <location filename="../src/imitatepass.cpp" line="261"/>
        <source>Failed to open .gpg-id for writing.</source>
        <translation>.gpg-id 无法写入.</translation>
    </message>
    <message>
        <location filename="../src/imitatepass.cpp" line="274"/>
        <source>Check selected users!</source>
        <translation>请核对所选用户！</translation>
    </message>
    <message>
        <location filename="../src/imitatepass.cpp" line="275"/>
        <source>None of the selected keys have a secret key available.
You will not be able to decrypt any newly added passwords!</source>
        <translation>警告：所选密钥都没有私钥可用。
任何新添加的密码将无法解密！</translation>
    </message>
    <message>
        <location filename="../src/imitatepass.cpp" line="662"/>
        <location filename="../src/imitatepass.cpp" line="769"/>
        <source>Re-encryption failed</source>
        <translation>重新加密失败</translation>
    </message>
    <message>
        <location filename="../src/imitatepass.cpp" line="663"/>
        <source>Failed to replace %1. Original has been restored.</source>
        <translation>替换 %1 失败。已恢复原来密码。</translation>
    </message>
    <message>
        <location filename="../src/imitatepass.cpp" line="692"/>
        <source>Creating backup commit</source>
        <translation>正在创建备份提交</translation>
    </message>
    <message>
        <location filename="../src/imitatepass.cpp" line="698"/>
        <location filename="../src/imitatepass.cpp" line="706"/>
        <source>Backup commit failed</source>
        <translation>备份提交失败</translation>
    </message>
    <message>
        <location filename="../src/imitatepass.cpp" line="699"/>
        <source>Could not inspect git status. Re-encryption was aborted.</source>
        <translation>无法检视 git 状态。重新加密被终止。</translation>
    </message>
    <message>
        <location filename="../src/imitatepass.cpp" line="707"/>
        <source>Re-encryption was aborted because a git backup could not be created.</source>
        <translation>重新加密被终止，因无法创建 git 备份。</translation>
    </message>
    <message>
        <location filename="../src/imitatepass.cpp" line="729"/>
        <source>Re-encrypting from folder %1</source>
        <translation>重新从文件夹 %1 加密</translation>
    </message>
    <message>
        <location filename="../src/imitatepass.cpp" line="732"/>
        <location filename="../src/imitatepass.cpp" line="787"/>
        <source>Updating password-store</source>
        <translation>正在更新密码库</translation>
    </message>
    <message>
        <location filename="../src/imitatepass.cpp" line="757"/>
        <source>GPG ID verification failed</source>
        <translation>GPG ID 验证失败</translation>
    </message>
    <message>
        <location filename="../src/imitatepass.cpp" line="758"/>
        <source>Could not verify .gpg-id for directory.</source>
        <translation>无法验证目录的 .gpg-id。</translation>
    </message>
    <message>
        <location filename="../src/imitatepass.cpp" line="770"/>
        <source>Failed to re-encrypt %1</source>
        <translation>重新加密 %1 失败</translation>
    </message>
    <message>
        <location filename="../src/imitatepass.cpp" line="776"/>
        <source>Re-encryption completed: %1 succeeded, %2 failed</source>
        <translation>重新加密已完成: %1 个成功，%2 个失败</translation>
    </message>
    <message>
        <location filename="../src/imitatepass.cpp" line="782"/>
        <source>Re-encryption completed: %1 files re-encrypted</source>
        <translation>重新加密已完成: 重新加密了 %1 个文件</translation>
    </message>
</context>
<context>
    <name>KeygenDialog</name>
    <message>
        <location filename="../src/keygendialog.ui" line="14"/>
        <source>Generate GnuPG keypair</source>
        <translation>生成 GnuPG 密钥</translation>
    </message>
    <message>
        <location filename="../src/keygendialog.ui" line="42"/>
        <source>Generate a new key pair</source>
        <translation>创建新的密钥对</translation>
    </message>
    <message>
        <location filename="../src/keygendialog.ui" line="155"/>
        <source>Passphrase</source>
        <translation>口令</translation>
    </message>
    <message>
        <location filename="../src/keygendialog.ui" line="91"/>
        <source>Email</source>
        <translation>邮箱</translation>
    </message>
    <message>
        <location filename="../src/keygendialog.ui" line="123"/>
        <source>Name</source>
        <translation>姓名</translation>
    </message>
    <message>
        <location filename="../src/keygendialog.ui" line="200"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;There is no limit on the length of a passphrase, and it should be carefully chosen. From the perspective of security, the passphrase to unlock the private key is one of the weakest points in GnuPG (and other public-key encryption systems as well) since it is the only protection you have if another individual gets your private key. &lt;br/&gt;Ideally, the passphrase should not use words from a dictionary and should mix the case of alphabetic characters as well as use non-alphabetic characters.&lt;br/&gt;A good passphrase is crucial to the secure use of GnuPG.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;密码短语的长度没有限制，应该仔细选择。从安全性的角度来看，解锁私钥的密码短语是 GnuPG（以及其他公钥加密系统）中最薄弱的一点，因为如果其他人获得您的私钥，它是您唯一的保护。&lt;br/&gt;理想情况下，密码短语不应使用字典中的单词，而应混合字母字符大小写以及使用非字母字符 。&lt;br/&gt; 良好的密码短语对于安全使用 GnuPG 至关重要。&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../src/keygendialog.ui" line="210"/>
        <source>Repeat pass</source>
        <translation>重复密码</translation>
    </message>
    <message>
        <location filename="../src/keygendialog.ui" line="227"/>
        <source>Expert</source>
        <translation>专家模式</translation>
    </message>
    <message>
        <location filename="../src/keygendialog.ui" line="246"/>
        <source>Template contents will be set based on GPG version.</source>
        <translation>将根据 GPG 版本设置模板内容。</translation>
    </message>
    <message>
        <source>#           QtPass GPG key generator
#
#      first test version please comment
#
%echo Generating a default key
Key-Type: RSA
Subkey-Type: RSA
Name-Real:
Name-Comment: QtPass
Name-Email:
Expire-Date: 0
%no-protection
# Do a commit here, so that we can later print &quot;done&quot; :-)
%commit
%echo done</source>
        <translation type="vanished">#           QtPass GPG key generator
#
#      first test version please comment
#
%echo Generating a default key
Key-Type: RSA
Subkey-Type: RSA
Name-Real:
Name-Comment: QtPass
Name-Email:
Expire-Date: 0
%no-protection
# Do a commit here, so that we can later print &quot;done&quot; :-)
%commit
%echo done</translation>
    </message>
    <message>
        <source>#           QtPass GPG key generator
#
#      first test version please comment
#
%echo Generating a default key
Key-Type: default
Subkey-Type: default
Name-Real:
Name-Comment: QtPass
Name-Email:
Expire-Date: 0
%no-protection
# Do a commit here, so that we can later print &quot;done&quot; :-)
%commit
%echo done</source>
        <translation type="vanished">#           QtPass GPG key generator
#
#      first test version please comment
#
%echo Generating a default key
Key-Type: default
Subkey-Type: default
Name-Real:
Name-Comment: QtPass
Name-Email:
Expire-Date: 0
%no-protection
# Do a commit here, so that we can later print &quot;done&quot; :-)
%commit
%echo done</translation>
    </message>
    <message>
        <location filename="../src/keygendialog.ui" line="259"/>
        <source>For expert options check out the &lt;a href=&quot;https://www.gnupg.org/documentation/manuals/gnupg/Unattended-GPG-key-generation.html&quot;&gt;GnuPG manual&lt;/a&gt;</source>
        <translation>高级选项请查看 &lt;a href=&quot;https://www.gnupg.org/documentation/manuals/gnupg/Unattended-GPG-key-generation.html&quot;&gt;GnuPG用户手册&lt;/a&gt;</translation>
    </message>
    <message>
        <location filename="../src/keygendialog.cpp" line="168"/>
        <source>Invalid name</source>
        <translation>不合法的姓名</translation>
    </message>
    <message>
        <location filename="../src/keygendialog.cpp" line="169"/>
        <source>Name must be at least 5 characters long.</source>
        <translation>姓名至少需要5个字符。</translation>
    </message>
    <message>
        <location filename="../src/keygendialog.cpp" line="180"/>
        <source>Invalid email</source>
        <translation>不合法的邮箱地址</translation>
    </message>
    <message>
        <location filename="../src/keygendialog.cpp" line="181"/>
        <source>The email address you typed is not a valid email address.</source>
        <translation>您输入的邮箱不是一个合法的邮箱地址。</translation>
    </message>
    <message>
        <location filename="../src/keygendialog.cpp" line="196"/>
        <source>This operation can take some minutes.&lt;br /&gt;We need to generate a lot of random bytes. It is a good idea to perform some other action (type on the keyboard, move the mouse, utilize the disks) during the prime generation; this gives the random number generator a better chance to gain enough entropy.</source>
        <translation>密码生成需要较长时间，请耐心等待。&lt;br /&gt;程序需要收集很多随机数，在此期间使用电脑进行一些其他操作（例如敲击键盘，移动鼠标，读写硬盘等）会加快此过程，并且使随机数生成器更随机化。</translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../src/mainwindow.ui" line="14"/>
        <source>QtPass</source>
        <translation>QtPass 密码库管理器</translation>
    </message>
    <message>
        <source>Add</source>
        <translation type="vanished">新建</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="398"/>
        <location filename="../src/mainwindow.ui" line="401"/>
        <location filename="../src/mainwindow.cpp" line="1199"/>
        <source>Edit</source>
        <translation>编辑</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="406"/>
        <location filename="../src/mainwindow.ui" line="409"/>
        <location filename="../src/mainwindow.cpp" line="1213"/>
        <source>Delete</source>
        <translation>删除</translation>
    </message>
    <message>
        <source>git push</source>
        <translation type="vanished">git push</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="425"/>
        <source>Push</source>
        <translation>上传</translation>
    </message>
    <message>
        <source>git pull</source>
        <translation type="vanished">git pull</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="433"/>
        <source>Update</source>
        <translation>更新</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="444"/>
        <source>Manage who can read password in folder</source>
        <translation>选择用哪个密钥来解密保存在密码库中的密码</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="441"/>
        <location filename="../src/mainwindow.cpp" line="1193"/>
        <source>Users</source>
        <translation>用户</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="428"/>
        <source>Git push</source>
        <translation>Git push</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="436"/>
        <source>Git pull</source>
        <translation>Git pull</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="452"/>
        <source>Configuration</source>
        <translation>设置</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="449"/>
        <source>Config</source>
        <translation>设置</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="263"/>
        <source>Welcome to QtPass</source>
        <translation>欢迎使用 QtPass</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="120"/>
        <location filename="../src/mainwindow.cpp" line="536"/>
        <location filename="../src/mainwindow.cpp" line="719"/>
        <source>Search Password</source>
        <translation>搜索密码库</translation>
    </message>
    <message>
        <source>qtpass</source>
        <translation type="vanished">qtpass</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="202"/>
        <source>Welcome to QtPass %1</source>
        <translation>欢迎使用 QtPass %1</translation>
    </message>
    <message>
        <source>Add Password</source>
        <translation type="vanished">新密码</translation>
    </message>
    <message>
        <source>Add Folder</source>
        <translation type="vanished">新文件夹</translation>
    </message>
    <message>
        <source>Failed to connect WebDAV:
</source>
        <translation type="vanished">无法连接 WebDAV：
</translation>
    </message>
    <message>
        <source>QtPass WebDAV password</source>
        <translation type="vanished">QtPass WebDAV 密码</translation>
    </message>
    <message>
        <source>Enter password to connect to WebDAV:</source>
        <translation type="vanished">输入 WebDAV 密码以连接：</translation>
    </message>
    <message>
        <source>fusedav exited unexpectedly
</source>
        <translation type="vanished">fusedav 意外退出
</translation>
    </message>
    <message>
        <source>Failed to start fusedav to connect WebDAV:
</source>
        <translation type="vanished">无法连接 WebDAV，fusedav无法启动：
</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="340"/>
        <location filename="../src/mainwindow.cpp" line="353"/>
        <source>Updating password-store</source>
        <translation>正在更新密码库</translation>
    </message>
    <message>
        <source>Can not edit</source>
        <translation type="vanished">无法编辑</translation>
    </message>
    <message>
        <source>Selected password file does not exist, not able to edit</source>
        <translation type="vanished">选定的密码文件不存在，不可编辑</translation>
    </message>
    <message>
        <source>Password hidden</source>
        <translation type="vanished">密码已隐藏</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="461"/>
        <location filename="../src/mainwindow.cpp" line="760"/>
        <source>Content hidden</source>
        <translation>内容已隐藏</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="465"/>
        <location filename="../src/mainwindow.cpp" line="1432"/>
        <source>Password</source>
        <translation>密码</translation>
    </message>
    <message>
        <source>Clipboard cleared</source>
        <translation type="vanished">剪贴板已清除</translation>
    </message>
    <message>
        <source>Clipboard not cleared</source>
        <translation type="vanished">剪贴板未清除</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="540"/>
        <source>Password and Content hidden</source>
        <translation>密码和内容已隐藏</translation>
    </message>
    <message>
        <source>QProcess::FailedToStart</source>
        <translation type="vanished">系统错误：启动失败 QProcess::FailedToStart</translation>
    </message>
    <message>
        <source>QProcess::Crashed</source>
        <translation type="vanished">系统错误：程序崩溃 QProcess::Crashed</translation>
    </message>
    <message>
        <source>QProcess::Timedout</source>
        <translation type="vanished">系统错误：响应超时 QProcess::Timedout</translation>
    </message>
    <message>
        <source>QProcess::ReadError</source>
        <translation type="vanished">系统错误：读取错误 QProcess::ReadError</translation>
    </message>
    <message>
        <source>QProcess::WriteError</source>
        <translation type="vanished">系统错误：写入错误 QProcess::WriteError</translation>
    </message>
    <message>
        <source>QProcess::UnknownError</source>
        <translation type="vanished">系统错误：未知错误 QProcess::UnknownError</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="620"/>
        <source>Looking for: %1</source>
        <translation>搜索：%1</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="856"/>
        <location filename="../src/mainwindow.cpp" line="1258"/>
        <source>New file</source>
        <translation>新文件</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="857"/>
        <source>New password file: 
(Will be placed in %1 )</source>
        <translation>新建密码：
（将被放在 %1 )</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="914"/>
        <source>Are you sure you want to delete %1%2?</source>
        <translation>确定删除 %1%2?</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="913"/>
        <source>Delete password?</source>
        <translation>删除密码？</translation>
    </message>
    <message>
        <source>Are you sure you want to delete %1?</source>
        <translation type="vanished">确定删除 %1 ？</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="913"/>
        <source>Delete folder?</source>
        <translation>删除文件夹？</translation>
    </message>
    <message>
        <source>Can not get key list</source>
        <translation type="vanished">无法获取密钥列表</translation>
    </message>
    <message>
        <source>Unable to get list of available gpg keys</source>
        <translation type="vanished">无法获取可用的 GPG 密钥列表</translation>
    </message>
    <message>
        <source>Key not found in keyring</source>
        <translation type="vanished">所选密钥未找到</translation>
    </message>
    <message>
        <source>Generating GPG key pair</source>
        <translation type="vanished">正在生成 GPG 密钥对</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1062"/>
        <source>Profile changed to %1</source>
        <translation>用户已更改为 %1</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="390"/>
        <location filename="../src/mainwindow.ui" line="393"/>
        <location filename="../src/mainwindow.cpp" line="1191"/>
        <source>Add folder</source>
        <translation>新文件夹</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="379"/>
        <location filename="../src/mainwindow.ui" line="382"/>
        <location filename="../src/mainwindow.cpp" line="1192"/>
        <source>Add password</source>
        <translation>添加密码</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1259"/>
        <source>New Folder: 
(Will be placed in %1 )</source>
        <translation>新建文件夹：
（将被放在 %1 )</translation>
    </message>
    <message>
        <source>Copied to clipboard</source>
        <translation type="vanished">复制到剪贴板</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="68"/>
        <source>Select profile</source>
        <translation>选择配置文件</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="127"/>
        <source>Search inside password content (pass grep)</source>
        <translation>搜索密码内容（pass grep）</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="130"/>
        <source>⌕</source>
        <translation>⌕</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="133"/>
        <source>Content search toggle</source>
        <translation>内容搜索模式切换</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="136"/>
        <source>Toggle content search mode to search inside password files</source>
        <translation>切换搜索密码文件内容的模式</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="146"/>
        <source>Case-insensitive search</source>
        <translation>不区分大小写</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="149"/>
        <source>Aa</source>
        <translation>Aa</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="152"/>
        <source>Case-insensitive toggle</source>
        <translation>是否不区分大小写</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="155"/>
        <source>Toggle case-insensitive content search</source>
        <translation>开/关不区分大小写的内容搜索</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="211"/>
        <source>Results</source>
        <translation>结果</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="385"/>
        <source>Ctrl+N</source>
        <translation>Ctrl+N</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="414"/>
        <source>OTP</source>
        <translation>OTP</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="417"/>
        <source>Generate OTP and copy to clipboard</source>
        <translation>生成OTP并复制到剪贴板</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="420"/>
        <source>Ctrl+G</source>
        <translation>Ctrl+G</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="502"/>
        <source>OTP Code</source>
        <translation>OTP码</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="504"/>
        <source>OTP code copied to clipboard</source>
        <translation>OTP 码已复制到剪贴板</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="506"/>
        <source>No OTP code found in this password entry</source>
        <translation>此密码条目中未找到 OTP 码</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="670"/>
        <source>Searching…</source>
        <translation>搜索中…</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="701"/>
        <source>Search content (regex)</source>
        <translation>搜索内容（正则表达式）</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="747"/>
        <source>No matches found.</source>
        <translation>未找到匹配。</translation>
    </message>
    <message numerus="yes">
        <location filename="../src/mainwindow.cpp" line="770"/>
        <source>Found %n match(es) in %1 entr(ies).</source>
        <translation>
            <numerusform>在 %1 项中找到了 %n 个匹配。</numerusform>
        </translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="894"/>
        <source> and the whole content?</source>
        <translation> 和全部内容？</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="904"/>
        <source> and the whole content? &lt;br&gt;&lt;strong&gt;Attention: there are unexpected files in the given folder, check them before continue.&lt;/strong&gt;</source>
        <translation> 和整个内容？&lt;br&gt;&lt;strong&gt;注意：给定文件夹中有意外文件，请在继续之前检查它们 &lt;/strong&gt;</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="934"/>
        <source>No password selected for OTP generation</source>
        <translation>未选中密码用于生成 OTP</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1190"/>
        <source>Open folder with file manager</source>
        <translation>使用文件管理器打开文件夹</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1205"/>
        <source>Rename folder</source>
        <translation>重命名文件夹</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1209"/>
        <source>Rename password</source>
        <translation>重命名密码</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1218"/>
        <source>Re-encrypt</source>
        <translation>重新加密</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1269"/>
        <location filename="../src/mainwindow.cpp" line="1278"/>
        <location filename="../src/mainwindow.cpp" line="1487"/>
        <source>Error</source>
        <translation>出错</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1270"/>
        <source>Failed to create folder: %1</source>
        <translation>未能创建文件夹：%1</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1279"/>
        <source>Failed to create .gpg-id file in: %1</source>
        <translation>在下列位置创建 .gpg-id 文件失败：%1</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1301"/>
        <location filename="../src/mainwindow.cpp" line="1337"/>
        <source>Rename file</source>
        <translation>重命名文件</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1301"/>
        <source>Rename Folder To: </source>
        <translation>重命名文件夹为： </translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1337"/>
        <source>Rename File To: </source>
        <translation>将文件重命名为： </translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1488"/>
        <source>Directory does not exist: %1</source>
        <translation>目录不存在：%1</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1493"/>
        <source>Re-encrypt passwords</source>
        <translation>重新加密密码</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1494"/>
        <source>Re-encrypt all passwords in %1?

This will re-encrypt ALL password files in this folder using the current recipients defined in .gpg-id.

This may rewrite many files and cannot be undone easily.

Continue?</source>
        <translation>重新加密 %1 内的所有密码吗？

这会用 .gpg-id 中定义的当前收件人重新加密此文件夹中的所有密码。

这可能重写很多文件，无法轻易撤销。

要继续吗？</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="322"/>
        <source>&lt;p&gt;QtPass is a GUI for &lt;a href=&quot;https://www.passwordstore.org/&quot;&gt;pass&lt;/a&gt;, the standard unix password manager.&lt;/p&gt;
&lt;p&gt;Please report any &lt;a href=&quot;https://github.com/IJHack/qtpass/issues&quot;&gt;issues&lt;/a&gt; you might have with this software.&lt;/p&gt;
&lt;p&gt;&lt;a href=&quot;https://qtpass.org/&quot;&gt;Documentation&lt;/a&gt;&lt;/p&gt;
&lt;p&gt;&lt;a href=&quot;https://github.com/IJHack/qtpass&quot;&gt;SourceCode&lt;/a&gt;&lt;/p&gt;</source>
        <translation>&lt;p&gt; QtPass是 &lt;a href=&quot;https://www.passwordstore.org/&quot;&gt; pass &lt;/a&gt;（标准的Unix密码管理器）的GUI。&lt;/p&gt;
&lt;p&gt;请报告此软件可能包含的所有&lt;a href=&quot;https://github.com/IJHack/qtpass/issues&quot;&gt;问题&lt;/a&gt;。&lt;/p&gt;
&lt;p&gt; &lt;a href=&quot;https://qtpass.org/&quot;&gt;文档&lt;/a&gt; &lt;/p&gt;
&lt;p&gt; &lt;a href=&quot;https://github.com/IJHack/qtpass&quot;&gt;源代码&lt;/a&gt; &lt;/p&gt;</translation>
    </message>
</context>
<context>
    <name>Pass</name>
    <message>
        <location filename="../src/pass.cpp" line="142"/>
        <source>Invalid password length</source>
        <translation>密码长度无效</translation>
    </message>
    <message>
        <location filename="../src/pass.cpp" line="143"/>
        <source>Can&apos;t generate password with zero length.</source>
        <translation>无法生成零长度密码。</translation>
    </message>
    <message>
        <location filename="../src/pass.cpp" line="186"/>
        <source>No characters chosen</source>
        <translation>未选择任何字符</translation>
    </message>
    <message>
        <location filename="../src/pass.cpp" line="187"/>
        <source>Can&apos;t generate password, there are no characters to choose from set in the configuration!</source>
        <translation>未选择任何字符，无法生成密码！</translation>
    </message>
    <message>
        <location filename="../src/pass.cpp" line="514"/>
        <location filename="../src/pass.cpp" line="533"/>
        <source>Encryption failed: GPG key has expired. Please renew or replace it.</source>
        <translation>加密失败：GPG 密钥已过期。请更新或替换它。</translation>
    </message>
    <message>
        <location filename="../src/pass.cpp" line="519"/>
        <location filename="../src/pass.cpp" line="538"/>
        <source>Encryption failed: GPG key has been revoked.</source>
        <translation>加密失败：GPG 密钥已被撤销。</translation>
    </message>
    <message>
        <location filename="../src/pass.cpp" line="523"/>
        <location filename="../src/pass.cpp" line="543"/>
        <source>Encryption failed: recipient GPG key not found or invalid. Check that the key ID in .gpg-id is correct and imported.</source>
        <translation>加密失败：收件人GPG 密钥未找到或无效。检查 .gpg-id 中的 key ID 是否正确且已导入。</translation>
    </message>
    <message>
        <location filename="../src/pass.cpp" line="527"/>
        <location filename="../src/pass.cpp" line="547"/>
        <source>Encryption failed. Check that your GPG key is valid.</source>
        <translation>加密失败。检查你的 GPG 密钥是否有效。</translation>
    </message>
</context>
<context>
    <name>PasswordDialog</name>
    <message>
        <location filename="../src/passworddialog.ui" line="14"/>
        <location filename="../src/passworddialog.ui" line="65"/>
        <source>Password</source>
        <translation>密码</translation>
    </message>
    <message>
        <location filename="../src/passworddialog.ui" line="75"/>
        <source>Generate</source>
        <translation>生成</translation>
    </message>
    <message>
        <location filename="../src/passworddialog.ui" line="86"/>
        <source>Show password</source>
        <translation>显示密码</translation>
    </message>
    <message>
        <location filename="../src/passworddialog.ui" line="106"/>
        <source>Character Set:</source>
        <translation>字符集：</translation>
    </message>
    <message>
        <location filename="../src/passworddialog.ui" line="114"/>
        <source>All Characters</source>
        <translation>所有字符</translation>
    </message>
    <message>
        <location filename="../src/passworddialog.ui" line="119"/>
        <source>Alphabetical</source>
        <translation>英文字母</translation>
    </message>
    <message>
        <location filename="../src/passworddialog.ui" line="124"/>
        <source>Alphanumerical</source>
        <translation>字母和数字</translation>
    </message>
    <message>
        <location filename="../src/passworddialog.ui" line="129"/>
        <source>Custom</source>
        <translation>自定义</translation>
    </message>
    <message>
        <location filename="../src/passworddialog.ui" line="143"/>
        <source>Length:</source>
        <translation>长度：</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../main/main.cpp" line="155"/>
        <location filename="../main/main.cpp" line="159"/>
        <source>LTR</source>
        <translation>LTR</translation>
    </message>
</context>
<context>
    <name>QtPass</name>
    <message>
        <location filename="../src/qtpass.cpp" line="160"/>
        <source>Generating GPG key pair</source>
        <translation>正在生成 GPG 密钥对</translation>
    </message>
    <message>
        <location filename="../src/qtpass.cpp" line="223"/>
        <source>Failed to connect WebDAV:
</source>
        <translation>无法连接 WebDAV：
</translation>
    </message>
    <message>
        <location filename="../src/qtpass.cpp" line="240"/>
        <source>QtPass WebDAV password</source>
        <translation>QtPass WebDAV 密码</translation>
    </message>
    <message>
        <location filename="../src/qtpass.cpp" line="241"/>
        <source>Enter password to connect to WebDAV:</source>
        <translation>输入 WebDAV 密码以连接：</translation>
    </message>
    <message>
        <location filename="../src/qtpass.cpp" line="258"/>
        <source>fusedav exited unexpectedly
</source>
        <translation>fusedav 意外退出
</translation>
    </message>
    <message>
        <location filename="../src/qtpass.cpp" line="262"/>
        <source>Failed to start fusedav to connect WebDAV:
</source>
        <translation>无法连接 WebDAV，fusedav无法启动：
</translation>
    </message>
    <message>
        <location filename="../src/qtpass.cpp" line="275"/>
        <source>QProcess::FailedToStart</source>
        <translation>系统错误：启动失败 QProcess::FailedToStart</translation>
    </message>
    <message>
        <location filename="../src/qtpass.cpp" line="278"/>
        <source>QProcess::Crashed</source>
        <translation>系统错误：程序崩溃 QProcess::Crashed</translation>
    </message>
    <message>
        <location filename="../src/qtpass.cpp" line="281"/>
        <source>QProcess::Timedout</source>
        <translation>系统错误：响应超时 QProcess::Timedout</translation>
    </message>
    <message>
        <location filename="../src/qtpass.cpp" line="284"/>
        <source>QProcess::ReadError</source>
        <translation>系统错误：读取错误 QProcess::ReadError</translation>
    </message>
    <message>
        <location filename="../src/qtpass.cpp" line="287"/>
        <source>QProcess::WriteError</source>
        <translation>系统错误：写入错误 QProcess::WriteError</translation>
    </message>
    <message>
        <location filename="../src/qtpass.cpp" line="290"/>
        <source>QProcess::UnknownError</source>
        <translation>系统错误：未知错误 QProcess::UnknownError</translation>
    </message>
    <message>
        <location filename="../src/qtpass.cpp" line="306"/>
        <source>GPG key pair generation failed</source>
        <translation>GPG 密钥对生成失败</translation>
    </message>
    <message>
        <location filename="../src/qtpass.cpp" line="380"/>
        <source>GPG key pair generated successfully</source>
        <translation>成功生成了 GPG 密钥对</translation>
    </message>
    <message>
        <location filename="../src/qtpass.cpp" line="465"/>
        <source>Clipboard cleared</source>
        <translation>剪贴板已清除</translation>
    </message>
    <message>
        <location filename="../src/qtpass.cpp" line="467"/>
        <source>Clipboard not cleared</source>
        <translation>剪贴板未清除</translation>
    </message>
    <message>
        <location filename="../src/qtpass.cpp" line="512"/>
        <source>Copied to clipboard</source>
        <translation>复制到剪贴板</translation>
    </message>
</context>
<context>
    <name>StoreModel</name>
    <message>
        <source>force overwrite?</source>
        <translation type="vanished">强制覆盖？</translation>
    </message>
    <message>
        <location filename="../src/storemodel.cpp" line="411"/>
        <source>Force overwrite?</source>
        <translation>强制覆盖？</translation>
    </message>
    <message>
        <location filename="../src/storemodel.cpp" line="412"/>
        <source>overwrite %1 with %2?</source>
        <translation>用%2覆盖%1？</translation>
    </message>
</context>
<context>
    <name>TrayIcon</name>
    <message>
        <location filename="../src/trayicon.cpp" line="67"/>
        <source>&amp;Show</source>
        <translation>显示 (&amp;S)</translation>
    </message>
    <message>
        <location filename="../src/trayicon.cpp" line="69"/>
        <source>&amp;Hide</source>
        <translation>隐藏 (&amp;H)</translation>
    </message>
    <message>
        <location filename="../src/trayicon.cpp" line="72"/>
        <source>Mi&amp;nimize</source>
        <translation>最小化 (&amp;N)</translation>
    </message>
    <message>
        <location filename="../src/trayicon.cpp" line="75"/>
        <source>Ma&amp;ximize</source>
        <translation>最大化 (&amp;X)</translation>
    </message>
    <message>
        <location filename="../src/trayicon.cpp" line="78"/>
        <source>&amp;Restore</source>
        <translation>恢复 (&amp;R)</translation>
    </message>
    <message>
        <location filename="../src/trayicon.cpp" line="81"/>
        <source>&amp;Quit</source>
        <translation>退出 (&amp;Q)</translation>
    </message>
</context>
<context>
    <name>UsersDialog</name>
    <message>
        <location filename="../src/usersdialog.ui" line="20"/>
        <source>Read access users</source>
        <translation>选择用户</translation>
    </message>
    <message>
        <location filename="../src/usersdialog.ui" line="45"/>
        <source>Select which users should be able to decrypt passwords stored in this folder.
Note: Existing files will not be modified, and retain the old permissions until you edit them.
Blue entries have a secret key available, select one of these to be able to decrypt.
Black entries have an encryption key available and it is trusted, select one of these to allow other people to decrypt.
Red entries are not valid, you will not be able to encrypt to these.</source>
        <translation>选择哪些用户应该可以解密存储在此文件夹中的密码。
注：现有文件不会被修改，并且在你编辑它们前保留旧权限。
蓝色项目有 secret key 可用，要解密请从这些项目中选择一个。
黑色项目有加密密钥可用并被信任，从这些项目中选择一个允许别人解密。
红色项目无效，你无法加密这些项目。</translation>
    </message>
    <message>
        <source>Select which users should be able to decrypt passwords stored in this folder.
Note: Existing files will not be modified, and retain the old permissions until you edit them.
Blue entries have a secret key available, select one of these to be able to decrypt.
Red entries are not valid, you will not be able to encrypt to these.</source>
        <translation type="vanished">选择哪些用户应该能够解密此文件夹中存储的密码。
注意：现有文件将不会被修改，并保留旧的权限，直到您对其进行编辑。
蓝色条目具有可用的秘密密钥，请选择其中一项以进行解密。
红色条目无效，您将无法对其进行加密。</translation>
    </message>
    <message>
        <location filename="../src/usersdialog.ui" line="70"/>
        <source>Search for users</source>
        <translation>搜索用户</translation>
    </message>
    <message>
        <source>Select which users should be able to decrypt passwords stored in this folder.
Note: Existing files will not be modified and retain the old permissions until you edit them.
Blue entries have a secret key available, select one of these to be able to decrypt.
Red entries are not valid, you will not be able to encrypt to these.</source>
        <translation type="vanished">选择哪些用户能够解密保存在密码库中的密码。
注：现有的文件不会被修改，并保留现有的权限，直到您对其进行编辑。
蓝色表示有私钥和公钥可用，可以用来加密。
红色表示没有私钥，不可以用来加密。</translation>
    </message>
    <message>
        <source>Search Users</source>
        <translation type="vanished">搜索用户</translation>
    </message>
    <message>
        <location filename="../src/usersdialog.ui" line="77"/>
        <source>Show unusable keys</source>
        <translation>显示不可用密钥</translation>
    </message>
    <message>
        <source>Can not get key list</source>
        <translation type="vanished">无法获取密钥列表</translation>
    </message>
    <message>
        <source>Unable to get list of available gpg keys</source>
        <translation type="vanished">无法获取可用的 GPG 密钥列表</translation>
    </message>
    <message>
        <location filename="../src/usersdialog.cpp" line="71"/>
        <source>Keylist missing</source>
        <translation>缺少密钥列表</translation>
    </message>
    <message>
        <location filename="../src/usersdialog.cpp" line="72"/>
        <source>Could not fetch list of available GPG keys</source>
        <translation>无法获取可用GPG密钥的列表</translation>
    </message>
    <message>
        <location filename="../src/usersdialog.cpp" line="148"/>
        <source>Key not found in keyring</source>
        <translation>所选密钥未找到</translation>
    </message>
    <message>
        <location filename="../src/usersdialog.cpp" line="301"/>
        <source>created</source>
        <translation>创建于</translation>
    </message>
    <message>
        <location filename="../src/usersdialog.cpp" line="305"/>
        <source>expires</source>
        <translation>过期于</translation>
    </message>
    <message>
        <location filename="../src/usersdialog.cpp" line="328"/>
        <source>[INVALID] </source>
        <translation>[无效] </translation>
    </message>
    <message>
        <location filename="../src/usersdialog.cpp" line="331"/>
        <source>[EXPIRED] </source>
        <translation>[已过期] </translation>
    </message>
    <message>
        <location filename="../src/usersdialog.cpp" line="335"/>
        <source>[PARTIAL] </source>
        <translation>[不完整] </translation>
    </message>
</context>
</TS>
