<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="zh_CN">
<context>
    <name>ConfigDialog</name>
    <message>
        <location filename="../src/configdialog.ui" line="20"/>
        <source>Configuration</source>
        <translation>配置</translation>
    </message>
    <message>
        <location filename="../src/configdialog.ui" line="46"/>
        <source>Settings</source>
        <translation>設定</translation>
    </message>
    <message>
        <location filename="../src/configdialog.ui" line="72"/>
        <source>Clipboard behaviour:</source>
        <translation>剪貼簿行為:</translation>
    </message>
    <message>
        <location filename="../src/configdialog.ui" line="91"/>
        <source>Use primary selection</source>
        <translation>使用主選取</translation>
    </message>
    <message>
        <location filename="../src/configdialog.ui" line="98"/>
        <source>Autoclear after:</source>
        <translation>自動清除後:</translation>
    </message>
    <message>
        <location filename="../src/configdialog.ui" line="115"/>
        <location filename="../src/configdialog.ui" line="198"/>
        <source>Seconds</source>
        <translation>秒</translation>
    </message>
    <message>
        <source>Password Behaviour:</source>
        <translation type="vanished">Password Behaviour:</translation>
    </message>
    <message>
        <location filename="../src/configdialog.ui" line="147"/>
        <source>Content panel behaviour:</source>
        <translation>內容面板行為:</translation>
    </message>
    <message>
        <location filename="../src/configdialog.ui" line="159"/>
        <source>Hide content</source>
        <translation>隱藏內容</translation>
    </message>
    <message>
        <location filename="../src/configdialog.ui" line="166"/>
        <source>Hide password</source>
        <translation>隱藏密碼</translation>
    </message>
    <message>
        <location filename="../src/configdialog.ui" line="175"/>
        <source>Autoclear panel after:</source>
        <translation>自動清除面板後:</translation>
    </message>
    <message>
        <location filename="../src/configdialog.ui" line="224"/>
        <source>Use a monospace font</source>
        <translation>使用等寬字體</translation>
    </message>
    <message>
        <location filename="../src/configdialog.ui" line="231"/>
        <source>Display the files content as-is</source>
        <translation>顯示檔案內容原樣</translation>
    </message>
    <message>
        <location filename="../src/configdialog.ui" line="238"/>
        <source>No line wrapping</source>
        <translation>不換行</translation>
    </message>
    <message>
        <location filename="../src/configdialog.ui" line="270"/>
        <source>Password Generation:</source>
        <translation>密碼產生：</translation>
    </message>
    <message>
        <location filename="../src/configdialog.ui" line="282"/>
        <source>Password Length:</source>
        <translation>密碼長度：</translation>
    </message>
    <message>
        <location filename="../src/configdialog.ui" line="316"/>
        <source>Characters</source>
        <translation>字元</translation>
    </message>
    <message>
        <location filename="../src/configdialog.ui" line="344"/>
        <source>Use characters:</source>
        <translation>使用字元：</translation>
    </message>
    <message>
        <location filename="../src/configdialog.ui" line="362"/>
        <source>Select character set for password generation</source>
        <translation>選擇字元配置來產生密碼</translation>
    </message>
    <message>
        <location filename="../src/configdialog.ui" line="366"/>
        <source>All Characters</source>
        <translation>所有字元</translation>
    </message>
    <message>
        <location filename="../src/configdialog.ui" line="371"/>
        <source>Alphabetical</source>
        <translation>字母</translation>
    </message>
    <message>
        <location filename="../src/configdialog.ui" line="376"/>
        <source>Alphanumerical</source>
        <translation>字母數字混合</translation>
    </message>
    <message>
        <location filename="../src/configdialog.ui" line="381"/>
        <source>Custom</source>
        <translation>自訂</translation>
    </message>
    <message>
        <location filename="../src/configdialog.ui" line="419"/>
        <source>ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789</source>
        <translation>ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789</translation>
    </message>
    <message>
        <location filename="../src/configdialog.ui" line="453"/>
        <source>Include special symbols</source>
        <translation>包含特殊符號</translation>
    </message>
    <message>
        <location filename="../src/configdialog.ui" line="592"/>
        <source>Enable content search (pass grep)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/configdialog.ui" line="595"/>
        <source>Allow searching inside password file contents. Requires decrypting every file and can be slow on large stores.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/configdialog.ui" line="769"/>
        <source>Generate</source>
        <translation>產生</translation>
    </message>
    <message>
        <location filename="../src/configdialog.ui" line="772"/>
        <source>Generate GPG key pair</source>
        <translation>產生GPG金鑰對</translation>
    </message>
    <message>
        <location filename="../src/configdialog.ui" line="945"/>
        <source>Profile name, used to identify this configuration profile</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/configdialog.ui" line="953"/>
        <source>Path to the password store directory</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/configdialog.ui" line="958"/>
        <source>Signing Key</source>
        <translation>簽名金鑰</translation>
    </message>
    <message>
        <location filename="../src/configdialog.ui" line="961"/>
        <source>Optional: GPG key to sign .gpg-id files for integrity verification. Leave empty unless you need to protect the user list from tampering.</source>
        <translation>可選：用於完整性驗證的GPG金鑰，以簽署.gpg-id文件。除非需要保護用戶列表免受篡改，請留空。</translation>
    </message>
    <message>
        <location filename="../src/configdialog.ui" line="1001"/>
        <source>Current path</source>
        <translation>目前路徑</translation>
    </message>
    <message>
        <source>Use pwgen</source>
        <translation type="vanished">Use pwgen</translation>
    </message>
    <message>
        <location filename="../src/configdialog.ui" line="443"/>
        <source>Exclude capital letters</source>
        <translation>排除大寫字母</translation>
    </message>
    <message>
        <source>Include special symbols </source>
        <translation type="vanished">Include special symbols </translation>
    </message>
    <message>
        <location filename="../src/configdialog.ui" line="460"/>
        <source>Generate easy to memorize but less secure passwords</source>
        <translation>產生易記但較不安全的密碼</translation>
    </message>
    <message>
        <location filename="../src/configdialog.ui" line="467"/>
        <source>Exclude numbers</source>
        <translation>排除數字</translation>
    </message>
    <message>
        <location filename="../src/configdialog.ui" line="486"/>
        <source>Git:</source>
        <translation>Git:</translation>
    </message>
    <message>
        <source>Use git</source>
        <translation type="vanished">Use git</translation>
    </message>
    <message>
        <location filename="../src/configdialog.ui" line="512"/>
        <source>Automatically add .gpg-id files</source>
        <translation>自動新增.gpg-id 檔案</translation>
    </message>
    <message>
        <location filename="../src/configdialog.ui" line="519"/>
        <source>Automatically push</source>
        <translation>自動</translation>
    </message>
    <message>
        <location filename="../src/configdialog.ui" line="526"/>
        <source>Automatically pull</source>
        <translation>自動拉取</translation>
    </message>
    <message>
        <location filename="../src/configdialog.ui" line="558"/>
        <source>Extensions:</source>
        <translation>擴充功能：</translation>
    </message>
    <message>
        <source>Use pass otp extension</source>
        <translation type="vanished">Use pass otp extension</translation>
    </message>
    <message>
        <location filename="../src/configdialog.ui" line="617"/>
        <source>System:</source>
        <translation>系統：</translation>
    </message>
    <message>
        <location filename="../src/configdialog.ui" line="629"/>
        <source>Use TrayIcon</source>
        <translation>使用托盤圖標</translation>
    </message>
    <message>
        <location filename="../src/configdialog.ui" line="636"/>
        <source>Start minimized</source>
        <translation>開啟時最小化</translation>
    </message>
    <message>
        <location filename="../src/configdialog.ui" line="643"/>
        <source>Hide on close</source>
        <translation>關閉時隱藏</translation>
    </message>
    <message>
        <location filename="../src/configdialog.ui" line="650"/>
        <source>Always on top</source>
        <translation>總是在最上層</translation>
    </message>
    <message>
        <location filename="../src/configdialog.ui" line="675"/>
        <source>Programs</source>
        <translation>程式</translation>
    </message>
    <message>
        <location filename="../src/configdialog.ui" line="693"/>
        <source>Select password storage program:</source>
        <translation>選擇密碼保存程式：</translation>
    </message>
    <message>
        <source>Nati&amp;ve git/gpg</source>
        <translation type="vanished">Nati&amp;ve git/gpg</translation>
    </message>
    <message>
        <location filename="../src/configdialog.ui" line="709"/>
        <source>&amp;Use pass</source>
        <translation>&amp;使用pass</translation>
    </message>
    <message>
        <location filename="../src/configdialog.ui" line="733"/>
        <source>Native</source>
        <translation>本地</translation>
    </message>
    <message>
        <source>git</source>
        <translation type="vanished">git</translation>
    </message>
    <message>
        <source>...</source>
        <translation type="vanished">...</translation>
    </message>
    <message>
        <source>gpg</source>
        <translation type="vanished">gpg</translation>
    </message>
    <message>
        <source>pwgen</source>
        <translation type="vanished">pwgen</translation>
    </message>
    <message>
        <location filename="../src/configdialog.ui" line="809"/>
        <source>Pass</source>
        <translation>pass</translation>
    </message>
    <message>
        <location filename="../src/configdialog.ui" line="820"/>
        <source>pass</source>
        <translation>pass</translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;a href=&quot;https://www.passwordstore.org/&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0000ff;&quot;&gt;www.passwordstore.org&lt;/span&gt;&lt;/a&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="vanished">&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;a href=&quot;https://www.passwordstore.org/&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0000ff;&quot;&gt;www.passwordstore.org&lt;/span&gt;&lt;/a&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../src/configdialog.ui" line="893"/>
        <source>Profiles</source>
        <translation>簡介</translation>
    </message>
    <message>
        <location filename="../src/configdialog.ui" line="942"/>
        <source>Name</source>
        <translation>名稱</translation>
    </message>
    <message>
        <location filename="../src/configdialog.ui" line="950"/>
        <source>Path</source>
        <translation>路徑</translation>
    </message>
    <message>
        <location filename="../src/configdialog.ui" line="971"/>
        <source>Add</source>
        <translation>新增</translation>
    </message>
    <message>
        <location filename="../src/configdialog.ui" line="986"/>
        <source>Delete</source>
        <translation>刪除</translation>
    </message>
    <message>
        <source>Current password-store</source>
        <translation type="vanished">Current password-store</translation>
    </message>
    <message>
        <location filename="../src/configdialog.ui" line="1021"/>
        <source>Template</source>
        <translation>範本</translation>
    </message>
    <message>
        <source>Templates add extra fields in the password generation dialogue and in the password view.</source>
        <translation type="vanished">Templates add extra fields in the password generation dialogue and in the password view.</translation>
    </message>
    <message>
        <location filename="../src/configdialog.ui" line="1051"/>
        <source>Use template</source>
        <translation>使用範本</translation>
    </message>
    <message>
        <location filename="../src/configdialog.ui" line="1058"/>
        <source>Show all lines beginning with a word followed by a colon as fields in password fields, not only the listed ones</source>
        <translation>顯示所有以單詞後跟冒號開頭的行作為密碼字段中的字段，而不僅僅是列出的那些</translation>
    </message>
    <message>
        <location filename="../src/configdialog.ui" line="1061"/>
        <source>Show all fields templated</source>
        <translation>顯示所有範本</translation>
    </message>
    <message>
        <source>login
url
email</source>
        <translation type="vanished">login
url
email</translation>
    </message>
    <message>
        <location filename="../src/configdialog.ui" line="1088"/>
        <source>&lt;a href=&quot;https://QtPass.org/&quot;&gt;QtPass&lt;/a&gt; version </source>
        <translation>&lt;a href=&quot;https://QtPass.org/&quot;&gt;QtPass&lt;/a&gt; 版本 </translation>
    </message>
    <message>
        <location filename="../src/configdialog.cpp" line="124"/>
        <source>No Clipboard</source>
        <translation>不使用剪貼板</translation>
    </message>
    <message>
        <location filename="../src/configdialog.cpp" line="125"/>
        <source>Always copy to clipboard</source>
        <translation>總是拷貝到剪貼板</translation>
    </message>
    <message>
        <location filename="../src/configdialog.cpp" line="126"/>
        <source>On-demand copy to clipboard</source>
        <translation>按需複製到剪貼簿</translation>
    </message>
    <message>
        <location filename="../src/configdialog.cpp" line="207"/>
        <location filename="../src/configdialog.cpp" line="223"/>
        <source>This field is required</source>
        <translation>此字段是必需的</translation>
    </message>
    <message>
        <location filename="../src/configdialog.cpp" line="653"/>
        <source>Select recipients for %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/configdialog.cpp" line="671"/>
        <source>New Profile</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/configdialog.cpp" line="703"/>
        <source>No profile selected</source>
        <translation>未選擇任何個人資料</translation>
    </message>
    <message>
        <location filename="../src/configdialog.cpp" line="704"/>
        <source>No profile selected to delete</source>
        <translation>未选择要删除的配置文件</translation>
    </message>
    <message>
        <location filename="../src/configdialog.cpp" line="803"/>
        <source>GnuPG not found</source>
        <translation>無法找到GnuPG</translation>
    </message>
    <message>
        <location filename="../src/configdialog.cpp" line="817"/>
        <source>Please install GnuPG on your system.&lt;br&gt;Install &lt;strong&gt;gpg&lt;/strong&gt; using your favorite package manager&lt;br&gt;or &lt;a href=&quot;https://www.gnupg.org/download/#sec-1-2&quot;&gt;download&lt;/a&gt; it from GnuPG.org</source>
        <translation>請在您的系統上安裝 GnuPG。 &lt;br&gt;使用您喜歡的軟體包管理器安裝&lt;strong&gt;gpg&lt;/strong&gt;，&lt;br&gt;或&lt;a href=&quot;https://www.gnupg.org/download/#sec-1-2&quot;&gt;從 GnuPG.org 下載&lt;/a&gt;。</translation>
    </message>
    <message>
        <location filename="../src/configdialog.cpp" line="871"/>
        <source>Create password-store?</source>
        <translation>新增密碼儲存庫？</translation>
    </message>
    <message>
        <location filename="../src/configdialog.cpp" line="872"/>
        <source>Would you like to create a password-store at %1?</source>
        <translation>請問您想新增密碼儲存擋在 %1?</translation>
    </message>
    <message>
        <location filename="../src/configdialog.cpp" line="877"/>
        <source>Error</source>
        <translation>錯誤</translation>
    </message>
    <message>
        <location filename="../src/configdialog.cpp" line="878"/>
        <source>Failed to create password-store at: %1</source>
        <translation>在：%1 处创建密码存储失败</translation>
    </message>
    <message>
        <location filename="../src/configdialog.cpp" line="909"/>
        <source>Password store not initialised</source>
        <translation>密码存储未初始化</translation>
    </message>
    <message>
        <location filename="../src/configdialog.cpp" line="910"/>
        <source>The folder %1 doesn&apos;t seem to be a password store or is not yet initialised.</source>
        <translation>该文件夹%1似乎不是一个密码存储或尚未初始化。</translation>
    </message>
    <message>
        <location filename="../src/configdialog.ui" line="839"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;a href=&quot;https://www.passwordstore.org/&quot;&gt;&lt;span style=&quot; text-decoration: underline;&quot;&gt;www.passwordstore.org&lt;/span&gt;&lt;/a&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;a href=&quot;https://www.passwordstore.org/&quot;&gt;&lt;span style=&quot; text-decoration: underline;&quot;&gt;www.passwordstore.org&lt;/span&gt;&lt;/a&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../src/configdialog.ui" line="870"/>
        <source>Autodetect</source>
        <translation>自動偵測</translation>
    </message>
    <message>
        <location filename="../src/configdialog.cpp" line="68"/>
        <source>System tray is not available</source>
        <translation>系统托盘不可用</translation>
    </message>
    <message>
        <location filename="../src/configdialog.cpp" line="93"/>
        <source>Pass OTP extension needs to be installed</source>
        <translation>需要安装 Pass OTP 扩展</translation>
    </message>
    <message>
        <location filename="../src/configdialog.cpp" line="98"/>
        <source>qrencode needs to be installed</source>
        <translation>qrencode 需要被安裝</translation>
    </message>
    <message>
        <location filename="../src/configdialog.cpp" line="806"/>
        <source>Please install GnuPG on your system.&lt;br&gt;Install &lt;strong&gt;Ubuntu&lt;/strong&gt; from the Microsoft Store to get it.&lt;br&gt;If you already did so, make sure you started it once and&lt;br&gt;click &quot;Autodetect&quot; in the next dialog.</source>
        <translation>請安裝GnuPG到您的系統&lt;br&gt;Install &lt;strong&gt;Ubuntu&lt;/strong&gt;從 Microsoft Store 取得。&lt;br&gt;如已安裝，請確認 您已開啟它，之後&lt;br&gt;在下一個對話框點擊&quot;自動偵測&quot;。</translation>
    </message>
    <message>
        <location filename="../src/configdialog.cpp" line="811"/>
        <source>Please install GnuPG on your system.&lt;br&gt;Install &lt;strong&gt;Ubuntu&lt;/strong&gt; from the Microsoft Store&lt;br&gt;or &lt;a href=&quot;https://www.gnupg.org/download/#sec-1-2&quot;&gt;download&lt;/a&gt; it from GnuPG.org</source>
        <translation>請安裝GnuPG 到您的系統.&lt;br&gt;Install &lt;strong&gt;Ubuntu&lt;/strong&gt; 從 Microsoft Store&lt;br&gt;or &lt;a href=&quot;https://www.gnupg.org/download/#sec-1-2&quot;&gt;下載&lt;/a&gt; 從 GnuPG.org</translation>
    </message>
    <message>
        <location filename="../src/configdialog.ui" line="436"/>
        <source>Use PWGen</source>
        <translation>使用 PWGen</translation>
    </message>
    <message>
        <location filename="../src/configdialog.ui" line="498"/>
        <source>Use Git</source>
        <translation>使用 Git</translation>
    </message>
    <message>
        <location filename="../src/configdialog.ui" line="567"/>
        <source>Use QRencode</source>
        <translation>使用QRencode</translation>
    </message>
    <message>
        <location filename="../src/configdialog.ui" line="581"/>
        <source>Use pass-otp extension</source>
        <translation>使用 pass-otp 扩展</translation>
    </message>
    <message>
        <location filename="../src/configdialog.ui" line="702"/>
        <source>Nati&amp;ve Git/GPG</source>
        <translation>原生 Git/GPG</translation>
    </message>
    <message>
        <location filename="../src/configdialog.ui" line="739"/>
        <source>Git</source>
        <translation>Git</translation>
    </message>
    <message>
        <location filename="../src/configdialog.ui" line="749"/>
        <location filename="../src/configdialog.ui" line="756"/>
        <location filename="../src/configdialog.ui" line="799"/>
        <location filename="../src/configdialog.ui" line="830"/>
        <location filename="../src/configdialog.ui" line="1008"/>
        <source>…</source>
        <translation>…</translation>
    </message>
    <message>
        <location filename="../src/configdialog.ui" line="779"/>
        <source>GPG</source>
        <translation>GPG</translation>
    </message>
    <message>
        <location filename="../src/configdialog.ui" line="792"/>
        <source>PWGen</source>
        <translation>生成密码</translation>
    </message>
    <message>
        <location filename="../src/configdialog.ui" line="1042"/>
        <source>Templates add extra fields in the password generation dialogue, and in the password view.</source>
        <translation>模板添加额外字段，用于密码生成对话框和密码视图。</translation>
    </message>
    <message>
        <location filename="../src/configdialog.ui" line="1073"/>
        <source>login
URL
e-mail</source>
        <translation>登入
網址
信箱</translation>
    </message>
</context>
<context>
    <name>ImitatePass</name>
    <message>
        <location filename="../src/imitatepass.cpp" line="141"/>
        <location filename="../src/imitatepass.cpp" line="319"/>
        <location filename="../src/imitatepass.cpp" line="505"/>
        <source>Check .gpgid file signature!</source>
        <translation>檢查.gpgid檔案簽名！</translation>
    </message>
    <message>
        <location filename="../src/imitatepass.cpp" line="142"/>
        <location filename="../src/imitatepass.cpp" line="320"/>
        <location filename="../src/imitatepass.cpp" line="506"/>
        <source>Signature for %1 is invalid.</source>
        <translation>%1的簽名無效。</translation>
    </message>
    <message>
        <location filename="../src/imitatepass.cpp" line="149"/>
        <location filename="../src/imitatepass.cpp" line="598"/>
        <source>Can not edit</source>
        <translation>無法編輯</translation>
    </message>
    <message>
        <location filename="../src/imitatepass.cpp" line="150"/>
        <location filename="../src/imitatepass.cpp" line="599"/>
        <source>Could not read encryption key to use, .gpg-id file missing or invalid.</source>
        <translation>無法讀取加密鑰匙，gpg-id 檔案消失或無效。</translation>
    </message>
    <message>
        <location filename="../src/imitatepass.cpp" line="314"/>
        <source>GPG signing failed!</source>
        <translation>GPG簽名失敗！</translation>
    </message>
    <message>
        <location filename="../src/imitatepass.cpp" line="315"/>
        <source>Failed to sign %1.</source>
        <translation>無法為%1簽名。</translation>
    </message>
    <message>
        <location filename="../src/imitatepass.cpp" line="382"/>
        <source>No signing key!</source>
        <translation>沒有可用的簽名金鑰！</translation>
    </message>
    <message>
        <location filename="../src/imitatepass.cpp" line="383"/>
        <source>None of the secret signing keys is available.
You will not be able to change the user list!</source>
        <translation>所有密鑰均不可用。
您將無法更改使用者清單！</translation>
    </message>
    <message>
        <location filename="../src/imitatepass.cpp" line="260"/>
        <source>Cannot update</source>
        <translation>無法更新</translation>
    </message>
    <message>
        <location filename="../src/imitatepass.cpp" line="261"/>
        <source>Failed to open .gpg-id for writing.</source>
        <translation>無法打開.gpg-id進行寫入。</translation>
    </message>
    <message>
        <location filename="../src/imitatepass.cpp" line="274"/>
        <source>Check selected users!</source>
        <translation>檢查所選用戶！</translation>
    </message>
    <message>
        <location filename="../src/imitatepass.cpp" line="275"/>
        <source>None of the selected keys have a secret key available.
You will not be able to decrypt any newly added passwords!</source>
        <translation>所選密鑰均無私有私鑰。
您將無法解密任何新新增的密碼！</translation>
    </message>
    <message>
        <location filename="../src/imitatepass.cpp" line="662"/>
        <location filename="../src/imitatepass.cpp" line="769"/>
        <source>Re-encryption failed</source>
        <translation>重新加密失敗</translation>
    </message>
    <message>
        <location filename="../src/imitatepass.cpp" line="663"/>
        <source>Failed to replace %1. Original has been restored.</source>
        <translation>無法替換%1。原始檔案已恢復。</translation>
    </message>
    <message>
        <location filename="../src/imitatepass.cpp" line="692"/>
        <source>Creating backup commit</source>
        <translation>創建備份提交</translation>
    </message>
    <message>
        <location filename="../src/imitatepass.cpp" line="698"/>
        <location filename="../src/imitatepass.cpp" line="706"/>
        <source>Backup commit failed</source>
        <translation>備份提交失敗</translation>
    </message>
    <message>
        <location filename="../src/imitatepass.cpp" line="699"/>
        <source>Could not inspect git status. Re-encryption was aborted.</source>
        <translation>無法檢查git狀態。重新加密被中止。</translation>
    </message>
    <message>
        <location filename="../src/imitatepass.cpp" line="707"/>
        <source>Re-encryption was aborted because a git backup could not be created.</source>
        <translation>由於無法創建git備份，重新加密被中止。</translation>
    </message>
    <message>
        <location filename="../src/imitatepass.cpp" line="729"/>
        <source>Re-encrypting from folder %1</source>
        <translation>從資料夾%1重新加密</translation>
    </message>
    <message>
        <location filename="../src/imitatepass.cpp" line="732"/>
        <location filename="../src/imitatepass.cpp" line="787"/>
        <source>Updating password-store</source>
        <translation>更新密碼儲存庫</translation>
    </message>
    <message>
        <location filename="../src/imitatepass.cpp" line="757"/>
        <source>GPG ID verification failed</source>
        <translation>GPG ID驗證失敗</translation>
    </message>
    <message>
        <location filename="../src/imitatepass.cpp" line="758"/>
        <source>Could not verify .gpg-id for directory.</source>
        <translation>無法驗證目錄的.gpg-id。</translation>
    </message>
    <message>
        <location filename="../src/imitatepass.cpp" line="770"/>
        <source>Failed to re-encrypt %1</source>
        <translation>無法重新加密%1</translation>
    </message>
    <message>
        <location filename="../src/imitatepass.cpp" line="776"/>
        <source>Re-encryption completed: %1 succeeded, %2 failed</source>
        <translation>重新加密完成：%1成功，%2失敗</translation>
    </message>
    <message>
        <location filename="../src/imitatepass.cpp" line="782"/>
        <source>Re-encryption completed: %1 files re-encrypted</source>
        <translation>重新加密完成：%1個檔案已重新加密</translation>
    </message>
</context>
<context>
    <name>KeygenDialog</name>
    <message>
        <location filename="../src/keygendialog.ui" line="14"/>
        <source>Generate GnuPG keypair</source>
        <translation>產生 GnuPG 金鑰對</translation>
    </message>
    <message>
        <location filename="../src/keygendialog.ui" line="42"/>
        <source>Generate a new key pair</source>
        <translation>產生新的金鑰對</translation>
    </message>
    <message>
        <location filename="../src/keygendialog.ui" line="155"/>
        <source>Passphrase</source>
        <translation>口令</translation>
    </message>
    <message>
        <location filename="../src/keygendialog.ui" line="91"/>
        <source>Email</source>
        <translation>電子信箱</translation>
    </message>
    <message>
        <location filename="../src/keygendialog.ui" line="123"/>
        <source>Name</source>
        <translation>名稱</translation>
    </message>
    <message>
        <location filename="../src/keygendialog.ui" line="200"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;There is no limit on the length of a passphrase, and it should be carefully chosen. From the perspective of security, the passphrase to unlock the private key is one of the weakest points in GnuPG (and other public-key encryption systems as well) since it is the only protection you have if another individual gets your private key. &lt;br/&gt;Ideally, the passphrase should not use words from a dictionary and should mix the case of alphabetic characters as well as use non-alphabetic characters.&lt;br/&gt;A good passphrase is crucial to the secure use of GnuPG.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;密碼短語的長度沒有限制，但必須謹慎選擇。從安全角度來看，用於解鎖私鑰的密碼短語是 GnuPG（以及其他公鑰加密系統）中最薄弱的環節之一，因為一旦私鑰被他人獲取，它就是你唯一的保護措施。 &lt;br/&gt;理想情況下，密碼短語不應使用字典中的單詞，並且應混合大小寫字母以及非字母字元。 &lt;br/&gt;一個好的密碼短語對於安全使用 GnuPG 至關重要。 &lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../src/keygendialog.ui" line="210"/>
        <source>Repeat pass</source>
        <translation>重複口令</translation>
    </message>
    <message>
        <location filename="../src/keygendialog.ui" line="227"/>
        <source>Expert</source>
        <translation>進階</translation>
    </message>
    <message>
        <location filename="../src/keygendialog.ui" line="246"/>
        <source>Template contents will be set based on GPG version.</source>
        <translation>模板内容将根据 GPG 版本设置。</translation>
    </message>
    <message>
        <location filename="../src/keygendialog.ui" line="259"/>
        <source>For expert options check out the &lt;a href=&quot;https://www.gnupg.org/documentation/manuals/gnupg/Unattended-GPG-key-generation.html&quot;&gt;GnuPG manual&lt;/a&gt;</source>
        <translation>進階模式請看 &lt;a href=&quot;https://www.gnupg.org/documentation/manuals/gnupg/Unattended-GPG-key-generation.html&quot;&gt;GnuPG 指南&lt;/a&gt;</translation>
    </message>
    <message>
        <location filename="../src/keygendialog.cpp" line="168"/>
        <source>Invalid name</source>
        <translation>無效的名稱</translation>
    </message>
    <message>
        <location filename="../src/keygendialog.cpp" line="169"/>
        <source>Name must be at least 5 characters long.</source>
        <translation>名稱長度至少為 5 個字元。</translation>
    </message>
    <message>
        <location filename="../src/keygendialog.cpp" line="180"/>
        <source>Invalid email</source>
        <translation>無效的電子郵件</translation>
    </message>
    <message>
        <location filename="../src/keygendialog.cpp" line="181"/>
        <source>The email address you typed is not a valid email address.</source>
        <translation>您輸入的電子郵件地址不是有效的電子郵件地址。</translation>
    </message>
    <message>
        <location filename="../src/keygendialog.cpp" line="196"/>
        <source>This operation can take some minutes.&lt;br /&gt;We need to generate a lot of random bytes. It is a good idea to perform some other action (type on the keyboard, move the mouse, utilize the disks) during the prime generation; this gives the random number generator a better chance to gain enough entropy.</source>
        <translation>此操作可能需要幾分鐘。 &lt;br /&gt;我們需要產生大量的隨機位元組。在生成素數期間，最好執行一些其他操作（例如在鍵盤上輸入文字、移動滑鼠、使用磁碟）；這能讓隨機數產生器有更大的機會獲得足夠的熵。</translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../src/mainwindow.ui" line="14"/>
        <source>QtPass</source>
        <translation>QtPass</translation>
    </message>
    <message>
        <source>Add</source>
        <translation type="vanished">Add</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="398"/>
        <location filename="../src/mainwindow.ui" line="401"/>
        <location filename="../src/mainwindow.cpp" line="1199"/>
        <source>Edit</source>
        <translation>編輯</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="406"/>
        <location filename="../src/mainwindow.ui" line="409"/>
        <location filename="../src/mainwindow.cpp" line="1213"/>
        <source>Delete</source>
        <translation>刪除</translation>
    </message>
    <message>
        <source>git push</source>
        <translation type="vanished">git push</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="425"/>
        <source>Push</source>
        <translation>推送</translation>
    </message>
    <message>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Cantarell&apos;; font-size:11pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;Helvetica Neue,Helvetica,Segoe UI,Arial,freesans,sans-serif&apos;; font-size:13pt; font-weight:600; color:#333333;&quot;&gt;QtPass&lt;/span&gt;&lt;span style=&quot; font-family:&apos;Helvetica Neue,Helvetica,Segoe UI,Arial,freesans,sans-serif&apos;; font-size:13pt; color:#333333;&quot;&gt; is a GUI for &lt;/span&gt;&lt;a href=&quot;https://www.passwordstore.org/&quot;&gt;&lt;span style=&quot; font-family:&apos;Helvetica Neue,Helvetica,Segoe UI,Arial,freesans,sans-serif&apos;; font-size:13pt; text-decoration: underline; color:#4183c4; background-color:transparent;&quot;&gt;pass&lt;/span&gt;&lt;/a&gt;&lt;span style=&quot; font-family:&apos;Helvetica Neue,Helvetica,Segoe UI,Arial,freesans,sans-serif&apos;; font-size:13pt; color:#333333;&quot;&gt;, the standard unix password manager.&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;Helvetica Neue,Helvetica,Segoe UI,Arial,freesans,sans-serif&apos;; font-size:13pt; color:#333333;&quot;&gt;&lt;br /&gt;Please report any &lt;/span&gt;&lt;a href=&quot;https://github.com/IJHack/qtpass/issues&quot;&gt;&lt;span style=&quot; font-family:&apos;Helvetica Neue,Helvetica,Segoe UI,Arial,freesans,sans-serif&apos;; font-size:13pt; text-decoration: underline; color:#4183c4;&quot;&gt;issues&lt;/span&gt;&lt;/a&gt;&lt;span style=&quot; font-family:&apos;Helvetica Neue,Helvetica,Segoe UI,Arial,freesans,sans-serif&apos;; font-size:13pt; color:#333333;&quot;&gt; you might have with this software.&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;a href=&quot;https://qtpass.org/&quot;&gt;&lt;span style=&quot; font-family:&apos;Helvetica Neue,Helvetica,Segoe UI,Arial,freesans,sans-serif&apos;; font-size:13pt; text-decoration: underline; color:#4183c4; background-color:transparent;&quot;&gt;Documentation&lt;/span&gt;&lt;/a&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;a href=&quot;https://github.com/IJHack/qtpass&quot;&gt;&lt;span style=&quot; font-family:&apos;Noto Sans&apos;; font-size:12pt; text-decoration: underline; color:#4183c4;&quot;&gt;SourceCode&lt;/span&gt;&lt;/a&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="vanished">&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Cantarell&apos;; font-size:11pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;Helvetica Neue,Helvetica,Segoe UI,Arial,freesans,sans-serif&apos;; font-size:13pt; font-weight:600; color:#333333;&quot;&gt;QtPass&lt;/span&gt;&lt;span style=&quot; font-family:&apos;Helvetica Neue,Helvetica,Segoe UI,Arial,freesans,sans-serif&apos;; font-size:13pt; color:#333333;&quot;&gt; is a GUI for &lt;/span&gt;&lt;a href=&quot;https://www.passwordstore.org/&quot;&gt;&lt;span style=&quot; font-family:&apos;Helvetica Neue,Helvetica,Segoe UI,Arial,freesans,sans-serif&apos;; font-size:13pt; text-decoration: underline; color:#4183c4; background-color:transparent;&quot;&gt;pass&lt;/span&gt;&lt;/a&gt;&lt;span style=&quot; font-family:&apos;Helvetica Neue,Helvetica,Segoe UI,Arial,freesans,sans-serif&apos;; font-size:13pt; color:#333333;&quot;&gt;, the standard unix password manager.&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;Helvetica Neue,Helvetica,Segoe UI,Arial,freesans,sans-serif&apos;; font-size:13pt; color:#333333;&quot;&gt;&lt;br /&gt;Please report any &lt;/span&gt;&lt;a href=&quot;https://github.com/IJHack/qtpass/issues&quot;&gt;&lt;span style=&quot; font-family:&apos;Helvetica Neue,Helvetica,Segoe UI,Arial,freesans,sans-serif&apos;; font-size:13pt; text-decoration: underline; color:#4183c4;&quot;&gt;issues&lt;/span&gt;&lt;/a&gt;&lt;span style=&quot; font-family:&apos;Helvetica Neue,Helvetica,Segoe UI,Arial,freesans,sans-serif&apos;; font-size:13pt; color:#333333;&quot;&gt; you might have with this software.&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;a href=&quot;https://qtpass.org/&quot;&gt;&lt;span style=&quot; font-family:&apos;Helvetica Neue,Helvetica,Segoe UI,Arial,freesans,sans-serif&apos;; font-size:13pt; text-decoration: underline; color:#4183c4; background-color:transparent;&quot;&gt;Documentation&lt;/span&gt;&lt;/a&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;a href=&quot;https://github.com/IJHack/qtpass&quot;&gt;&lt;span style=&quot; font-family:&apos;Noto Sans&apos;; font-size:12pt; text-decoration: underline; color:#4183c4;&quot;&gt;SourceCode&lt;/span&gt;&lt;/a&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="385"/>
        <source>Ctrl+N</source>
        <translation>Ctrl+N</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="414"/>
        <source>OTP</source>
        <translation>OTP</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="417"/>
        <source>Generate OTP and copy to clipboard</source>
        <translation>產生 OTP 並拷貝到剪貼版</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="420"/>
        <source>Ctrl+G</source>
        <translation>Ctrl+G</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="428"/>
        <source>Git push</source>
        <translation>推送 Git 變更</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="436"/>
        <source>Git pull</source>
        <translation>從 Git 拉取</translation>
    </message>
    <message>
        <source>git pull</source>
        <translation type="vanished">git pull</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="433"/>
        <source>Update</source>
        <translation>更新</translation>
    </message>
    <message>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;.SF NS Text&apos;; font-size:13pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt; &lt;span style=&quot; font-family:&apos;Lato&apos;;&quot;&gt;QtPass&lt;/span&gt; is a GUI for &lt;a href=&quot;https://www.passwordstore.org/&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0000ff;&quot;&gt;pass&lt;/span&gt;&lt;/a&gt;, the standard unix password manager.&lt;br /&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Please report any &lt;a href=&quot;https://github.com/IJHack/qtpass/issues&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0000ff;&quot;&gt;issues&lt;/span&gt;&lt;/a&gt; you might have with this software.&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;a href=&quot;https://qtpass.org/&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0000ff;&quot;&gt;Documentation&lt;/span&gt;&lt;/a&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;a href=&quot;https://github.com/IJHack/qtpass&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0000ff;&quot;&gt;SourceCode&lt;/span&gt;&lt;/a&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="vanished">&lt;!DOCTYPE HTML&gt;&lt;html&gt;&lt;head&gt; &lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot;/&gt; &lt;style type=&quot;text/css&quot;&gt; p, li { white-space: pre-wrap; } &lt;/style&gt;&lt;/head&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot;font-family: Lato;&quot;&gt;QtPass&lt;/span&gt; is a GUI for &lt;a href=&quot;https://www.passwordstore.org/&quot;&gt;pass&lt;/a&gt;, the standard unix password manager.&lt;br/&gt;&lt;/p&gt;&lt;p&gt;Please report any &lt;a href=&quot;https://github.com/IJHack/qtpass/issues&quot;&gt;issues&lt;/a&gt; you might have with this software.&lt;/p&gt;&lt;p&gt;&lt;a href=&quot;https://qtpass.org/&quot;&gt;Documentation&lt;/a&gt;&lt;/p&gt;&lt;p&gt;&lt;a href=&quot;https://github.com/IJHack/qtpass&quot;&gt;SourceCode&lt;/a&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="444"/>
        <source>Manage who can read password in folder</source>
        <translation>管理誰能夠閱讀資料夾中的密碼</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="441"/>
        <location filename="../src/mainwindow.cpp" line="1193"/>
        <source>Users</source>
        <translation>使用者</translation>
    </message>
    <message>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;.SF NS Text&apos;; font-size:13pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;Lato&apos;;&quot;&gt;QtPass&lt;/span&gt; is a GUI for &lt;a href=&quot;https://www.passwordstore.org/&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0000ff;&quot;&gt;pass&lt;/span&gt;&lt;/a&gt;, the standard unix password manager.&lt;br /&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Please report any &lt;a href=&quot;https://github.com/IJHack/qtpass/issues&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0000ff;&quot;&gt;issues&lt;/span&gt;&lt;/a&gt; you might have with this software.&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;a href=&quot;https://qtpass.org/&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0000ff;&quot;&gt;Documentation&lt;/span&gt;&lt;/a&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;a href=&quot;https://github.com/IJHack/qtpass&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0000ff;&quot;&gt;SourceCode&lt;/span&gt;&lt;/a&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="vanished">&lt;!DOCTYPE HTML&gt;&lt;html&gt;&lt;head&gt; &lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot;/&gt; &lt;style type=&quot;text/css&quot;&gt; p, li { white-space: pre-wrap; } &lt;/style&gt;&lt;/head&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot;font-family: Lato;&quot;&gt;QtPass&lt;/span&gt; is a GUI for &lt;a href=&quot;https://www.passwordstore.org/&quot;&gt;pass&lt;/a&gt;, the standard unix password manager.&lt;br/&gt;&lt;/p&gt;&lt;p&gt;Please report any &lt;a href=&quot;https://github.com/IJHack/qtpass/issues&quot;&gt;issues&lt;/a&gt; you might have with this software.&lt;/p&gt;&lt;p&gt;&lt;a href=&quot;https://qtpass.org/&quot;&gt;Documentation&lt;/a&gt;&lt;/p&gt;&lt;p&gt;&lt;a href=&quot;https://github.com/IJHack/qtpass&quot;&gt;SourceCode&lt;/a&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="452"/>
        <source>Configuration</source>
        <translation>配置</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="449"/>
        <source>Config</source>
        <translation>配置</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="68"/>
        <source>Select profile</source>
        <translation>選擇簡介</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="127"/>
        <source>Search inside password content (pass grep)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="130"/>
        <source>⌕</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="133"/>
        <source>Content search toggle</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="136"/>
        <source>Toggle content search mode to search inside password files</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="146"/>
        <source>Case-insensitive search</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="149"/>
        <source>Aa</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="152"/>
        <source>Case-insensitive toggle</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="155"/>
        <source>Toggle case-insensitive content search</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="211"/>
        <source>Results</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="263"/>
        <source>Welcome to QtPass</source>
        <translation>歡迎來到 QtPass</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="120"/>
        <location filename="../src/mainwindow.cpp" line="536"/>
        <location filename="../src/mainwindow.cpp" line="719"/>
        <source>Search Password</source>
        <translation>搜尋密碼</translation>
    </message>
    <message>
        <source>qtpass</source>
        <translation type="vanished">qtpass</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="202"/>
        <source>Welcome to QtPass %1</source>
        <translation>歡迎來到 QtPass %1</translation>
    </message>
    <message>
        <source>Add Password</source>
        <translation type="vanished">Add Password</translation>
    </message>
    <message>
        <source>Add Folder</source>
        <translation type="vanished">Add Folder</translation>
    </message>
    <message>
        <source>Failed to connect WebDAV:
</source>
        <translation type="vanished">Failed to connect WebDAV:
</translation>
    </message>
    <message>
        <source>QtPass WebDAV password</source>
        <translation type="vanished">QtPass WebDAV password</translation>
    </message>
    <message>
        <source>Enter password to connect to WebDAV:</source>
        <translation type="vanished">Enter password to connect to WebDAV:</translation>
    </message>
    <message>
        <source>fusedav exited unexpectedly
</source>
        <translation type="vanished">fusedav exited unexpectedly
</translation>
    </message>
    <message>
        <source>Failed to start fusedav to connect WebDAV:
</source>
        <translation type="vanished">Failed to start fusedav to connect WebDAV:
</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="340"/>
        <location filename="../src/mainwindow.cpp" line="353"/>
        <source>Updating password-store</source>
        <translation>更新密碼儲存庫</translation>
    </message>
    <message>
        <source>Can not edit</source>
        <translation type="vanished">Can not edit</translation>
    </message>
    <message>
        <source>Selected password file does not exist, not able to edit</source>
        <translation type="vanished">Selected password file does not exist, not able to edit</translation>
    </message>
    <message>
        <source>Password hidden</source>
        <translation type="vanished">Password hidden</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="461"/>
        <location filename="../src/mainwindow.cpp" line="760"/>
        <source>Content hidden</source>
        <translation>隱藏內容</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="465"/>
        <location filename="../src/mainwindow.cpp" line="1432"/>
        <source>Password</source>
        <translation>密碼</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="502"/>
        <source>OTP Code</source>
        <translation>一次性密碼</translation>
    </message>
    <message>
        <source>Clipboard cleared</source>
        <translation type="vanished">Clipboard cleared</translation>
    </message>
    <message>
        <source>Clipboard not cleared</source>
        <translation type="vanished">Clipboard not cleared</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="540"/>
        <source>Password and Content hidden</source>
        <translation>隱藏密碼和內容</translation>
    </message>
    <message>
        <source>QProcess::FailedToStart</source>
        <translation type="vanished">QProcess::FailedToStart</translation>
    </message>
    <message>
        <source>QProcess::Crashed</source>
        <translation type="vanished">QProcess::Crashed</translation>
    </message>
    <message>
        <source>QProcess::Timedout</source>
        <translation type="vanished">QProcess::Timedout</translation>
    </message>
    <message>
        <source>QProcess::ReadError</source>
        <translation type="vanished">QProcess::ReadError</translation>
    </message>
    <message>
        <source>QProcess::WriteError</source>
        <translation type="vanished">QProcess::WriteError</translation>
    </message>
    <message>
        <source>QProcess::UnknownError</source>
        <translation type="vanished">QProcess::UnknownError</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="620"/>
        <source>Looking for: %1</source>
        <translation>尋找: %1</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="856"/>
        <location filename="../src/mainwindow.cpp" line="1258"/>
        <source>New file</source>
        <translation>新檔案</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="857"/>
        <source>New password file: 
(Will be placed in %1 )</source>
        <translation>新密碼檔：
（將放置在 %1 目錄下）</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="894"/>
        <source> and the whole content?</source>
        <translation> 以及整個內容？</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="904"/>
        <source> and the whole content? &lt;br&gt;&lt;strong&gt;Attention: there are unexpected files in the given folder, check them before continue.&lt;/strong&gt;</source>
        <translation> 以及整個內容？&lt;br&gt;&lt;strong&gt;注意：給定文件夾中存在意外檔案，請在繼續前檢查它們。&lt;/strong&gt;</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="914"/>
        <source>Are you sure you want to delete %1%2?</source>
        <translation>您確定要刪除 %1%2?</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="913"/>
        <source>Delete password?</source>
        <translation>刪除密碼？</translation>
    </message>
    <message>
        <source>Are you sure you want to delete %1?</source>
        <translation type="vanished">Are you sure you want to delete %1?</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="913"/>
        <source>Delete folder?</source>
        <translation>刪除資料夾？</translation>
    </message>
    <message>
        <source> and whole content</source>
        <translation type="vanished"> and whole content</translation>
    </message>
    <message>
        <source>Can not get key list</source>
        <translation type="vanished">Can not get key list</translation>
    </message>
    <message>
        <source>Unable to get list of available gpg keys</source>
        <translation type="vanished">Unable to get list of available gpg keys</translation>
    </message>
    <message>
        <source>Key not found in keyring</source>
        <translation type="vanished">Key not found in keyring</translation>
    </message>
    <message>
        <source>Generating GPG key pair</source>
        <translation type="vanished">Generating GPG key pair</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1062"/>
        <source>Profile changed to %1</source>
        <translation>配置文件已更改为 %1</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1190"/>
        <source>Open folder with file manager</source>
        <translation>使用檔案總管開啟資料夾</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="390"/>
        <location filename="../src/mainwindow.ui" line="393"/>
        <location filename="../src/mainwindow.cpp" line="1191"/>
        <source>Add folder</source>
        <translation>新增資料夾</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="379"/>
        <location filename="../src/mainwindow.ui" line="382"/>
        <location filename="../src/mainwindow.cpp" line="1192"/>
        <source>Add password</source>
        <translation>新增密碼</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1259"/>
        <source>New Folder: 
(Will be placed in %1 )</source>
        <translation>新資料夾r: 
(會被放置在 %1 )</translation>
    </message>
    <message>
        <source>Copied to clipboard</source>
        <translation type="vanished">copied to clipboard</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="504"/>
        <source>OTP code copied to clipboard</source>
        <translation>一次性密碼已複製到剪貼簿</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="506"/>
        <source>No OTP code found in this password entry</source>
        <translation>此密碼條目中未找到一次性密碼</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="670"/>
        <source>Searching…</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="701"/>
        <source>Search content (regex)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="747"/>
        <source>No matches found.</source>
        <translation type="unfinished"></translation>
    </message>
    <message numerus="yes">
        <location filename="../src/mainwindow.cpp" line="770"/>
        <source>Found %n match(es) in %1 entr(ies).</source>
        <translation type="unfinished">
            <numerusform></numerusform>
        </translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="934"/>
        <source>No password selected for OTP generation</source>
        <translation>未為產生一次性密碼選擇密碼</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1205"/>
        <source>Rename folder</source>
        <translation>重新命名資料夾</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1209"/>
        <source>Rename password</source>
        <translation>重新命名密碼</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1218"/>
        <source>Re-encrypt</source>
        <translation>重新加密</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1269"/>
        <location filename="../src/mainwindow.cpp" line="1278"/>
        <location filename="../src/mainwindow.cpp" line="1487"/>
        <source>Error</source>
        <translation>錯誤</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1270"/>
        <source>Failed to create folder: %1</source>
        <translation>無法創建文件夾：%1</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1279"/>
        <source>Failed to create .gpg-id file in: %1</source>
        <translation>無法在：%1 創建 .gpg-id 檔案</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1301"/>
        <location filename="../src/mainwindow.cpp" line="1337"/>
        <source>Rename file</source>
        <translation>重新命名檔案</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1301"/>
        <source>Rename Folder To: </source>
        <translation>重新命名資料夾： </translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1337"/>
        <source>Rename File To: </source>
        <translation>重新命名檔案： </translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1488"/>
        <source>Directory does not exist: %1</source>
        <translation>目錄不存在：%1</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1493"/>
        <source>Re-encrypt passwords</source>
        <translation>重新加密密碼</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1494"/>
        <source>Re-encrypt all passwords in %1?

This will re-encrypt ALL password files in this folder using the current recipients defined in .gpg-id.

This may rewrite many files and cannot be undone easily.

Continue?</source>
        <translation>是否重新加密 %1 中的所有密碼？

這將使用當前定義在 .gpg-id 檔案中的收件人重新加密此文件夾中所有密碼檔案。

這可能會重寫許多檔案，並且無法輕鬆撤銷。

繼續？</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="322"/>
        <source>&lt;p&gt;QtPass is a GUI for &lt;a href=&quot;https://www.passwordstore.org/&quot;&gt;pass&lt;/a&gt;, the standard unix password manager.&lt;/p&gt;
&lt;p&gt;Please report any &lt;a href=&quot;https://github.com/IJHack/qtpass/issues&quot;&gt;issues&lt;/a&gt; you might have with this software.&lt;/p&gt;
&lt;p&gt;&lt;a href=&quot;https://qtpass.org/&quot;&gt;Documentation&lt;/a&gt;&lt;/p&gt;
&lt;p&gt;&lt;a href=&quot;https://github.com/IJHack/qtpass&quot;&gt;SourceCode&lt;/a&gt;&lt;/p&gt;</source>
        <translation>&lt;p&gt;QtPass 是個圖像介面&lt;a href=&quot;https://www.passwordstore.org/&quot;&gt;pass&lt;/a&gt;，標準的unix系統密碼管理程式。&lt;/p&gt;
&lt;p&gt;請回報任何 &lt;a href=&quot;https://github.com/IJHack/qtpass/issues&quot;&gt;問題&lt;/a&gt; 當你在使用這個軟體時。&lt;/p&gt;
&lt;p&gt;&lt;a href=&quot;https://qtpass.org/&quot;&gt;說明書&lt;/a&gt;&lt;/p&gt;
&lt;p&gt;&lt;a href=&quot;https://github.com/IJHack/qtpass&quot;&gt;S程式碼&lt;/a&gt;&lt;/p&gt;</translation>
    </message>
</context>
<context>
    <name>Pass</name>
    <message>
        <location filename="../src/pass.cpp" line="142"/>
        <source>Invalid password length</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/pass.cpp" line="143"/>
        <source>Can&apos;t generate password with zero length.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/pass.cpp" line="186"/>
        <source>No characters chosen</source>
        <translation>無字元被選取</translation>
    </message>
    <message>
        <location filename="../src/pass.cpp" line="187"/>
        <source>Can&apos;t generate password, there are no characters to choose from set in the configuration!</source>
        <translation>在配置中未設置可供選擇的字元，因此無法產生密碼！</translation>
    </message>
    <message>
        <location filename="../src/pass.cpp" line="514"/>
        <location filename="../src/pass.cpp" line="533"/>
        <source>Encryption failed: GPG key has expired. Please renew or replace it.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/pass.cpp" line="519"/>
        <location filename="../src/pass.cpp" line="538"/>
        <source>Encryption failed: GPG key has been revoked.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/pass.cpp" line="523"/>
        <location filename="../src/pass.cpp" line="543"/>
        <source>Encryption failed: recipient GPG key not found or invalid. Check that the key ID in .gpg-id is correct and imported.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/pass.cpp" line="527"/>
        <location filename="../src/pass.cpp" line="547"/>
        <source>Encryption failed. Check that your GPG key is valid.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>PasswordDialog</name>
    <message>
        <location filename="../src/passworddialog.ui" line="14"/>
        <location filename="../src/passworddialog.ui" line="65"/>
        <source>Password</source>
        <translation>密碼</translation>
    </message>
    <message>
        <location filename="../src/passworddialog.ui" line="75"/>
        <source>Generate</source>
        <translation>產生</translation>
    </message>
    <message>
        <location filename="../src/passworddialog.ui" line="86"/>
        <source>Show password</source>
        <translation>顯示密碼</translation>
    </message>
    <message>
        <location filename="../src/passworddialog.ui" line="106"/>
        <source>Character Set:</source>
        <translation>字元設定：</translation>
    </message>
    <message>
        <location filename="../src/passworddialog.ui" line="114"/>
        <source>All Characters</source>
        <translation>全部字元</translation>
    </message>
    <message>
        <location filename="../src/passworddialog.ui" line="119"/>
        <source>Alphabetical</source>
        <translation>字母</translation>
    </message>
    <message>
        <location filename="../src/passworddialog.ui" line="124"/>
        <source>Alphanumerical</source>
        <translation>字母數字混合</translation>
    </message>
    <message>
        <location filename="../src/passworddialog.ui" line="129"/>
        <source>Custom</source>
        <translation>自訂</translation>
    </message>
    <message>
        <location filename="../src/passworddialog.ui" line="143"/>
        <source>Length:</source>
        <translation>長度：</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../main/main.cpp" line="155"/>
        <location filename="../main/main.cpp" line="159"/>
        <source>LTR</source>
        <translation>LTR</translation>
    </message>
</context>
<context>
    <name>QtPass</name>
    <message>
        <location filename="../src/qtpass.cpp" line="160"/>
        <source>Generating GPG key pair</source>
        <translation>產生GPG</translation>
    </message>
    <message>
        <location filename="../src/qtpass.cpp" line="223"/>
        <source>Failed to connect WebDAV:
</source>
        <translation>未能連結到 WebDAV:
</translation>
    </message>
    <message>
        <location filename="../src/qtpass.cpp" line="240"/>
        <source>QtPass WebDAV password</source>
        <translation>QtPass WebDAV 密碼</translation>
    </message>
    <message>
        <location filename="../src/qtpass.cpp" line="241"/>
        <source>Enter password to connect to WebDAV:</source>
        <translation>輸入密碼來連結到WebDAV:</translation>
    </message>
    <message>
        <location filename="../src/qtpass.cpp" line="258"/>
        <source>fusedav exited unexpectedly
</source>
        <translation>fusedav意外退出
</translation>
    </message>
    <message>
        <location filename="../src/qtpass.cpp" line="262"/>
        <source>Failed to start fusedav to connect WebDAV:
</source>
        <translation>啟動 fusedav 連線 WebDAV 失敗：
</translation>
    </message>
    <message>
        <location filename="../src/qtpass.cpp" line="275"/>
        <source>QProcess::FailedToStart</source>
        <translation>QProcess::未能啟動</translation>
    </message>
    <message>
        <location filename="../src/qtpass.cpp" line="278"/>
        <source>QProcess::Crashed</source>
        <translation>QProcess::當機</translation>
    </message>
    <message>
        <location filename="../src/qtpass.cpp" line="281"/>
        <source>QProcess::Timedout</source>
        <translation>QProcess::Timedout</translation>
    </message>
    <message>
        <location filename="../src/qtpass.cpp" line="284"/>
        <source>QProcess::ReadError</source>
        <translation>QProcess::讀取錯誤</translation>
    </message>
    <message>
        <location filename="../src/qtpass.cpp" line="287"/>
        <source>QProcess::WriteError</source>
        <translation>QProcess::寫入錯誤</translation>
    </message>
    <message>
        <location filename="../src/qtpass.cpp" line="290"/>
        <source>QProcess::UnknownError</source>
        <translation>QProcess::UnknownError</translation>
    </message>
    <message>
        <location filename="../src/qtpass.cpp" line="306"/>
        <source>GPG key pair generation failed</source>
        <translation>GPG金鑰對產生失敗</translation>
    </message>
    <message>
        <location filename="../src/qtpass.cpp" line="380"/>
        <source>GPG key pair generated successfully</source>
        <translation>GPG金鑰對產生成功</translation>
    </message>
    <message>
        <location filename="../src/qtpass.cpp" line="465"/>
        <source>Clipboard cleared</source>
        <translation>剪貼板清空</translation>
    </message>
    <message>
        <location filename="../src/qtpass.cpp" line="467"/>
        <source>Clipboard not cleared</source>
        <translation>剪貼板尚未清空</translation>
    </message>
    <message>
        <location filename="../src/qtpass.cpp" line="512"/>
        <source>Copied to clipboard</source>
        <translation>複製到剪貼板</translation>
    </message>
</context>
<context>
    <name>StoreModel</name>
    <message>
        <source>force overwrite?</source>
        <translation type="vanished">強制覆蓋？</translation>
    </message>
    <message>
        <location filename="../src/storemodel.cpp" line="411"/>
        <source>Force overwrite?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/storemodel.cpp" line="412"/>
        <source>overwrite %1 with %2?</source>
        <translation>用 %2 覆蓋 %1？</translation>
    </message>
</context>
<context>
    <name>TrayIcon</name>
    <message>
        <location filename="../src/trayicon.cpp" line="67"/>
        <source>&amp;Show</source>
        <translation>%顯示</translation>
    </message>
    <message>
        <location filename="../src/trayicon.cpp" line="69"/>
        <source>&amp;Hide</source>
        <translation>&amp;隱藏</translation>
    </message>
    <message>
        <location filename="../src/trayicon.cpp" line="72"/>
        <source>Mi&amp;nimize</source>
        <translation>最小化(&amp;N)</translation>
    </message>
    <message>
        <location filename="../src/trayicon.cpp" line="75"/>
        <source>Ma&amp;ximize</source>
        <translation>最大化(&amp;X)</translation>
    </message>
    <message>
        <location filename="../src/trayicon.cpp" line="78"/>
        <source>&amp;Restore</source>
        <translation>&amp;恢復</translation>
    </message>
    <message>
        <location filename="../src/trayicon.cpp" line="81"/>
        <source>&amp;Quit</source>
        <translation>&amp;退出</translation>
    </message>
</context>
<context>
    <name>UsersDialog</name>
    <message>
        <location filename="../src/usersdialog.ui" line="20"/>
        <source>Read access users</source>
        <translation>具有讀取訪問權限的用戶</translation>
    </message>
    <message>
        <location filename="../src/usersdialog.ui" line="45"/>
        <source>Select which users should be able to decrypt passwords stored in this folder.
Note: Existing files will not be modified, and retain the old permissions until you edit them.
Blue entries have a secret key available, select one of these to be able to decrypt.
Black entries have an encryption key available and it is trusted, select one of these to allow other people to decrypt.
Red entries are not valid, you will not be able to encrypt to these.</source>
        <translation>選擇哪些使用者可以解密儲存在此資料夾中的密碼。
注意：現有文件不會被修改，並且會保留原有權限，直到您對其進行編輯。
藍色條目包含可用的金鑰，選擇其中一個即可解密。
黑色條目包含可用的加密金鑰，並且該金鑰已被信任，選擇其中一個即可允許其他人解密。
紅色條目無效，您將無法使用它們進行加密。</translation>
    </message>
    <message>
        <location filename="../src/usersdialog.ui" line="70"/>
        <source>Search for users</source>
        <translation>搜尋使用者</translation>
    </message>
    <message>
        <source>Select which users should be able to decrypt passwords stored in this folder.
Note: Existing files will not be modified and retain the old permissions until you edit them.
Blue entries have a secret key available, select one of these to be able to decrypt.
Red entries are not valid, you will not be able to encrypt to these.</source>
        <translation type="vanished">Select which users should be able to decrypt passwords stored in this folder.
Note: Existing files will not be modified and retain the old permissions until you edit them.
Blue entries have a secret key available, select one of these to be able to decrypt.
Red entries are not valid, you will not be able to encrypt to these.</translation>
    </message>
    <message>
        <source>Search Users</source>
        <translation type="vanished">显示无效的键</translation>
    </message>
    <message>
        <location filename="../src/usersdialog.ui" line="77"/>
        <source>Show unusable keys</source>
        <translation>顯示不可用的按鍵</translation>
    </message>
    <message>
        <source>Can not get key list</source>
        <translation type="vanished">Can not get key list</translation>
    </message>
    <message>
        <source>Unable to get list of available gpg keys</source>
        <translation type="vanished">金鑰列表缺失</translation>
    </message>
    <message>
        <location filename="../src/usersdialog.cpp" line="71"/>
        <source>Keylist missing</source>
        <translation>密鑰列表缺失</translation>
    </message>
    <message>
        <location filename="../src/usersdialog.cpp" line="72"/>
        <source>Could not fetch list of available GPG keys</source>
        <translation>無法取得可用的 GPG 密鑰列表</translation>
    </message>
    <message>
        <location filename="../src/usersdialog.cpp" line="148"/>
        <source>Key not found in keyring</source>
        <translation>鑰匙圈中找不到鑰匙</translation>
    </message>
    <message>
        <location filename="../src/usersdialog.cpp" line="301"/>
        <source>created</source>
        <translation>新增</translation>
    </message>
    <message>
        <location filename="../src/usersdialog.cpp" line="305"/>
        <source>expires</source>
        <translation>過期於</translation>
    </message>
    <message>
        <location filename="../src/usersdialog.cpp" line="328"/>
        <source>[INVALID] </source>
        <translation>[無效] </translation>
    </message>
    <message>
        <location filename="../src/usersdialog.cpp" line="331"/>
        <source>[EXPIRED] </source>
        <translation>[已過期] </translation>
    </message>
    <message>
        <location filename="../src/usersdialog.cpp" line="335"/>
        <source>[PARTIAL] </source>
        <translation>[部分] </translation>
    </message>
</context>
</TS>
